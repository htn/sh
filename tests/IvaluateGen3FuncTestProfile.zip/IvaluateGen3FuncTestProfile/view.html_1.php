<!-- layout se duoc dua du lieu vao -->
<?php $view->extend('GcsAdminBundle::admin.layout.html.php') ?>
<!--  Title c?a Page -->
<?php $view['slots']->start('title') ?>
<?php echo $GLOBALS['prefixTitle']; ?> - Functional Test Settings
<?php $view['slots']->stop() ?>
<?php $view['slots']->start('header') ?>

<small></small>
<?php $view['slots']->stop() ?>
<!-- JS can them vao -->
<?php $view['slots']->start('js') ?>
<script type="text/javascript" src="/web/admin/assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker1.min.js"></script>
<script src="/web/admin/assets/plugins/multipleselect/optimize.select.js"></script>
<script src="/web/admin/assets/plugins/multipleselect/optimize.js"></script>
<script src="/web/admin/assets/plugins/filterbox.js"></script>
<script src="/web/admin/assets/plugins/Chart.bundle.min.js"></script>
<!--<script src="/web/admin/assets/plugins/plotly-latest.min.js"></script>-->
<script>
    var infoCusLoc = JSON.parse('<?= $infoCusLoc ?>');
    var infoLocMac = JSON.parse('<?= $infoLocMac ?>');
    var searchCookie = '';
    var gridView = 'listData';
    var formView = 'formSearch';
    var formData = 'formSetting';
    var isAdmin = '<?= $isadmin; ?>';
    var customerID = '<?= $customerid; ?>';
    var click_search_profile = false;
    var obj_score = {};
    var grade_format = {};
    var calgrade = false;
    var tmp_value = "";
    var tmp_value_flag = false;
    var option_none = '<option value="-1">None</option>';
    var arr_d = {}; //default detail
    arr_d['scratches'] = 'Scratches';
    arr_d['chips'] = 'Chips';
    arr_d['cracks'] = 'Cracks';
    arr_d['dents'] = 'Dents';
    /* Begin thông tin và các thông số cần có của chart */
    // Thông số vẽ hình
    var axis_x = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000];
    var axis_y = ['E', 'D', 'C', 'B', 'A'];
    var val_chart = [
        {'label': 'A', 'from': 0, 'to': 0},
        {'label': 'B', 'from': 0, 'to': 0},
        {'label': 'C', 'from': 0, 'to': 0},
        {'label': 'D', 'from': 0, 'to': 0},
        {'label': 'E', 'from': 0, 'to': 0}
    ];
    window.chartColors = {
        colora: 'rgb(0, 144, 188)',
        colorb: 'rgb(227, 0, 6)',
        colorc: 'rgb(0, 166, 81)',
        colord: 'rgb(146, 39, 143)',
        colore: 'rgb(255, 136, 0)'};
    var sub_width = 5; //độ rộng của thanh keo hai bên
    var obj_subwidth = {}; //mang 2 khoi nho
    var half_width_label = 19;
    // Thông số resize
    var isResizing = false;
    var lastDownX = 0;
    var eleResizeID = '';
    var subIDs = '';
    var subID = '';
    var eleResizenumberID = '';
    var eleResizeWidth = 0;
    var eleResizeLeft = 0;
    var label_val = '';
    /*END thông tin và các thông số cần có của chart*/
    /*Bent/Lift*/
    var chart_scatter = {"A": "", "B": "", "C": "", "D": "", "E": ""};
    var arr_tile_bent_lift = [];
    arr_tile_bent_lift['distance_top'] = 'Top';
    arr_tile_bent_lift['distance_bottom'] = 'Bottom';
    arr_tile_bent_lift['distance_left'] = 'Left';
    arr_tile_bent_lift['distance_right'] = 'Right';
    var arr_bent_lift = [];
    arr_bent_lift['bent_config'] = 'Bent (mm)';
    arr_bent_lift['lift_config'] = 'Lift LCD (mm)';
    /*ENd Bent/Lift*/

    /* Huy khia báo 1 số biến hỗ trợ việc tính toán chart */
    var obj_multiplier_surface = {}; // Trọng số của mặt {"front":10,"top":3,"bottom":3,"left":3,"right":3,"back":3}
    var obj_defect_multiplier = {}; // Trọng số của loại lỗi {"scratches":1,"chips":2,"cracks":4,"dents":5,"discoloration":6,"peeling":7}
    var obj_defect_minus = {}; // Tiểm trừ max theo loại lỗi {"scratches":5000,"chips":1000,"cracks":1000,"dents":1000,"discoloration":1000,"peeling":1000}
    var arr_size_multiplier = []; // Trọng số của kích thước lỗi [{"from":0,"to":1,"multiplier":1},{"from":1,"to":2,"multiplier":5},{"from":2,"to":3,"multiplier":8},{"from":3,"to":4,"multiplier":10},{"from":4,"to":5,"multiplier":14},{"from":5,"to":6,"multiplier":18},{"from":6,"to":7,"multiplier":25},{"from":7,"to":10,"multiplier":30}]
    var grade_brief = {}; // Rút gọn lại grade để dễ tính toán {"a":{"front":{"scratches":[[1,10,1],[2,6,5],[3,4,8],[4,2,10],[5,1,14]]},"back":{"scratches":[[1,7,1],[2,5,5],[4,1,10],[5,2,14]]},"top":{"scratches":[[1,2,1],[2,1,5]]},"bottom":{"scratches":[[2,2,5],[3,1,8]]},"left":{"scratches":[[1,3,1],[2,2,5]]},"right":{"scratches":[[1,3,1],[2,1,5]]}}}
    var obj_surface_score = {}; // Điểm theo mặt, tính toán dựa vào datachart {"front":400,"back":650,"top":900,"bottom":300,"left":600,"right":900}
    var total_score = 0; // Tổng điểm của các điểm theo mặt bên trên
    var obj_grade_score = {}; // Điểm của grade ex: {"a":[100,200]}
    /* End */

    $(document).ready(function () {
        // gọi hàm khởi tạo form
        Optimize.initFormControl();
        // Rằng buộc chỉ cho nhập số trên 1 số class
        only_number('.max_unlimited_defect_type_1,.point_defect_type_2,.score_from,.score_from_real,.score_to,.maxs', true);
        // Mỗi lần nhả phím kiểm tra xem số nhập vào có số 0 ở đầu ko
        $(document).on('keyup', '.max_unlimited_defect_type_1,.point_defect_type_2,.score_from,.score_to,.maxs', function () {
            var vals = parseInt($(this).val());
            vals = RemovedZeroInt(vals);
            $(this).val(vals);
        });
        // Chỉ cho phép nhập số trên 1 số class bên dưới
        var ex = /^[0-9]+\.?[0-9]*$/;
        $(document).on('keyup', '.multiplier_size,.multiplier_defect_type_1,.maxsizes,.multiplier_surface,.from_size,.to_size,.bent_lift', function () {
            var vals = $(this).val();
            if (ex.test($(this).val()) === false) {
                var _vals = vals.substring(0, vals.length - 1);
                vals = _vals;
                $(this).val(_vals);
            }
        });
        // Sự kiện click nút thêm dòng
        $(document).on('click', '.addmore', function () {
            var keytr = $(this).attr('id');
            var ids = $(this).attr('ids');
            addmore_tr(keytr, ids);
        });
        // Sự kiện click nút xóa 1 dòng
        $(document).on('click', '.delete_constraints', function () {
            var ids = $(this).attr('ids');
            $(this).closest("tr").remove();
            var index = 1;
            $(".addmore" + ids).each(function (e) {
                $(".index" + ids).eq(e).html(index);
                index++;
            });
            return false;
        });
		//xoa grade
		$(document).on('click', '.delete_grade', function () {
			var index = $('.delete_grade').index($(this));
			$(this).closest("tr").remove();
			var obj_grage = obj_score['grade'];	
			console.log(index);
			console.log(obj_score['grade'].hasOwnProperty(index));
			console.log(JSON.stringify(obj_score['grade']));
			delete obj_score['grade'][index];
			//xoa bot chart
			delete val_chart[index];
			console.log(JSON.stringify(obj_score['grade']));
			console.log('===============');
			//set_object_score('grade', obj_grage);
			//kiểm tra nếu còn 1 grade thì không cho xóa
			var i=0;
			$(".delete_grade").each(function (e) {	
				i++;
            });
			if(i<2){
				$('.delete_grade').removeClass('delete_grade').attr("src","/web/img/delete_disable_constraints.png");//.css('background-image', 'url(/web/img/delete_disable_constraints.png)');
			}
			console.log(obj_score);
			loadchart();
            loadchartScatter(false, '');
			return false;
			//xoa grade trong object chinh
		})
        // sự kiện click nút update profile
        $('#updateprofile').click(function () {
            if ($(this).hasClass('disabled')) {
                return false;
            }
            var check1 = check_grade_from_to();
            var check2 = check_size();
            if (check1 > 0 || check2 > 0) {
                showMessage('Message', 'Invalid values. Please check again!');
                return false;
            }
            var profile = $("#profile").multipleSelect('getSelects');
            if (typeof profile === 'object' || profile.indexOf(',') !== -1) {
                showMessage('Message', 'Please select one profile in "Profile list"!');
            } else {
                getAllScore();
                if (typeof obj_score !== 'object') {
                    showMessage('Message', obj_score);
                    return false;
                }
                loadingForm(true);
                $.ajax({
                    type: "POST",
                    url: 'update-profile',
                    data: {
                        profile: profile,
                        functional_tests: JSON.stringify(obj_score)
                    }
                }).done(function (r) {
                    if (r === 'success') {
                        showMessage('Message', 'Updated profile successfully!');
                    } else {
                        showMessage('Message', 'Update profile error!');
                    }
                    loadingForm(false);
                }).fail(function (x) {
                    showMessage('Message', 'Update profile failed!');
                    loadingForm(false);
                });
            }
        });
        // Sự kiện nhấn nút xóa profile
        $('#delete').click(function () {
            if ($(this).hasClass('disabled')) {
                return false;
            }
            var id_profile = $('#profile').multipleSelect('getSelects');
            var name_profile = $('#profile').multipleSelect('getSelects', 'text');
            if (typeof id_profile === 'object') {
                showMessage('Message', 'Please select "Profile list" before clicking delete button!');
                return false;
            }
            var stationIDs = $('#stationid').multipleSelect('getSelects');
            if (typeof stationIDs === 'object') {
                stationIDs = '';
            }
            var customerIDs = $('#user_name').multipleSelect('getSelects');
            if (typeof customerIDs === 'object') {
                customerIDs = '';
            }
            //console.log('stationIDs: ' + stationIDs);
            delete_profile(id_profile, name_profile, customerIDs, stationIDs);
        });
        // Sự kiện nhấn nút reset
        $('#reset').click(function () {
            myReset();
        });
        // bôi đen text khi focus vào ô
        $(document).on('click', '.input-sm', function () {
            $(this).select();
        });
        // Nhấn vào detail để xem chi tiết detail
        $(document).on('click', '.detail_grade', function () {
            var label_grade = $(this).attr('label_grade');
            $("#loadlabelgrade").html(label_grade);
            load_detail_grade(label_grade);
        });
        // nhấn vào checkbox check all
        $(document).on('click', '#ckalfts', function (e) {
            if ($(this).prop('checked')) {
                $('.iafts').prop('checked', true);
            } else {
                $('.iafts').prop('checked', false);
            }
        });
        // sự kiện nhấn vào check box kiểm tra checkbox all
        $(document).on('click', '.iafts', function (e) {
            check_check_all();
        });
        // Sự kiện nhấn nút search
        $("#search").click(function () {
            if ($(this).hasClass('disabled')) {
                return false;
            }
            searchCookie = '';
            var customserid = $("#user_name").multipleSelect('getSelects');
            var stationid = $("#stationid").multipleSelect('getSelects');
            var profileid = $("#profile").multipleSelect('getSelects');
            // Nếu station được chọn thì search theo station
            if (typeof stationid !== 'object') {
                if (stationid.indexOf(',') !== -1) { // Nếu chọn nhiều máy
                    search_profile(stationid, true);
                    click_search_profile = false;
                } else { // Nếu chỉ chọn 1 máy
                    loadInfo(stationid); //search profile
                }
                return false;
            }
            // Nếu profile list được chọn thì search theo profile
            if (typeof profileid !== 'object') {
                if (profileid.indexOf(',') === -1) {
                    click_search_profile = true;
                    detail_profile(profileid);
                    filter_button();
                } else {
                    showMessage('Message', 'Please select one profile in "Profile list" to search!');
                }
                return false;
            }
            // Nếu customer được chọn thì search theo customer
            if (typeof customserid !== 'object') {
                click_search_profile = false;
                find_profile(customserid, true);
                return false;
            }
            showMessage('Message', 'Please select Customer or S/N or one profile in "Profile list" to search.');
        });
        // Khởi tạo multiselect cho profile running
        $("#profile_running").multipleSelect({
            filter: true,
            single: true,
            placeholder: "-- Select running profile --",
            onClick: function (view) {
                detail_profile(view.value);
                filter_button();
            }
        });
        // Khởi tạo multiselect cho profile và đăng ký sự kiện
        $("#profile").multipleSelect({
            filter: true,
            single: false,
            placeholder: "-- Select profile --",
            onClick: function (view) {
                filter_button();
            },
            onCheckAll: function () {
                filter_button();
            },
            onUncheckAll: function () {
                filter_button();
            }
        });
        // Click lên nút save detail
        $(document).on('click', '#savedetail', function () {
            var checksavedetails = check_save_detail();
            if (checksavedetails > 0) {
                showMessage('Message', 'Invalid values. Please check again!');
            } else {
                getAllScore();
                var label_grade = $("#loadlabelgrade").html();
                get_detail_grade(label_grade);
                calculater_grade(label_grade);
                $.fancybox.close();
            }
        });
        //kiem tra so 
        $('.input-sm').on('keypress', function (e) {
            return e.metaKey || // cmd/ctrl
                    e.which <= 0 || // arrow keys
                    e.which === 8 || // delete key
                    /[0-9]/.test(String.fromCharCode(e.which)); // numbers  
        });
        $(".input-sm").bind("input", function (e) {
            var id = e.currentTarget.id;
            var val = $("#" + id).val();
            if (!isNumeric(val)) {
                $("#" + id).val('');
                $("#" + id).blur();
                $("#" + id).focus();
            }
        });
		// Sự kiện click label name grade
		$(document).on('click', '.name_grade', function (e) {
			var index = $('.name_grade').index($(this));
			$('.lablel_name_grade').eq(index).hide();
			$('.txt_name_grade').eq(index).show();
			$('.txt_name_grade').eq(index).select();
		});
		// Sự kiện focusout hoặc mouseout khỏi ô nhập text name grade
		$(document).on('focusout mouseout', '.txt_name_grade', function () {
			var index = $('.txt_name_grade').index($(this));
			var tmp = $(this).val();
			var name_grade_old = $('.lablel_name_grade').eq(index).html();
			//kiem tra trung voi ten những grade khác dã có tra ve ten grade ban dau
			$(".lablel_name_grade").each(function (e) {	
				if(e!==index){					
					if(tmp.toLowerCase()===$(this).html().toLowerCase()){
						$('.txt_name_grade').eq(index).val(name_grade_old);	
						return false;
					}
				}
            });
			$('.lablel_name_grade').eq(index).show();
			$('.txt_name_grade').eq(index).hide();	
			
			$('.lablel_name_grade').eq(index).html($(this).val());
			//thay doi label grade trong doi tuong			
			if(name_grade_old.toLowerCase()!==$(this).val().toLowerCase()){
				var obj_grage = obj_score['grade'];
				val_chart = [];
				for (var key in obj_grage) {
					var name_grade = obj_grage[key]['name_grade'];				
					if (name_grade_old.toLowerCase() === name_grade.toLowerCase()) {
						obj_grage[key]['name_grade'] = $(this).val();
						
					}
					var score_from = obj_grage[key]['score_from'];
					var score_to = obj_grage[key]['score_to'];
					var tmp_c = {'label': 'A', 'from': 0, 'to': 0}
					tmp_c.label = name_grade;
					tmp_c.from = score_from;
					tmp_c.to = score_to;
					val_chart.push(tmp_c);
				}
				set_object_score('grade', obj_grage);
				//load chart
				loadchart();
                loadchartScatter(false, '');
			}
			
			
		});
		$(document).on('keyup keypress mouseup', '.calgrade', function (e) {
            calgrade = true;
            //console.log('keyup keypress mouseup calgrade');
        });
        $(document).on('keyup mouseup', '.maxsizes', function (e) {
            $(this).removeClass('rederror');
        });
        // khi nhấn chuột vào ô score thì bật cờ báo có thay đổi và lưu giá trị này
        $(document).on('focusin', '.score_to, .score_from_real', function (e) {
            tmp_value_flag = true;
            tmp_value = parseFloat($(this).val());
            //console.log('.score_to .score_from keyup keypress mouseup: ' + tmp_value);
        });
        // Sự kiện focusout hoặc mouseout khỏi ô nhập điểm from
        $(document).on('focusout mouseout', '.score_from_real', function (e) {
            var index_score_from = $('.score_from_real').index($(this)); // lấy index của ô này
            var val = parseFloat($(this).val()); // lấy value của ô này
            //console.log('.....focusout mouseout .score_from v:' + tmp_value + ' f: ' + tmp_value_flag + ' n:' + val);
            if (tmp_value_flag && tmp_value !== val) {
                tmp_value_flag = false;
                var name_grade = $('.score_from').eq(index_score_from).attr('label_grade');
                var val_grade = parseFloat($('.score_from').eq(index_score_from).val());
                if (val_grade < 0) {
                    val_grade = val - val_grade;
                } else {
                    val_grade = val;
                }
                $('.score_from').eq(index_score_from).val(val_grade);
                fill_grade_from(name_grade, val_grade, 'textfrom');
                loadchart();
                loadchartScatter(false, '');
            }
        });
        $(document).on('focusout mouseout', '.score_to', function (e) {
            var val = parseInt($(this).val());
            //console.log('.....focusout mouseout .score_to v:' + tmp_value + ' f: ' + tmp_value_flag + ' n:' + val);
            if (tmp_value_flag && tmp_value !== val) {
                tmp_value_flag = false;
                var name_grade = $(this).attr('label_grade');
                $(this).val(val);
                fill_grade_to(name_grade, val);
                loadchart();
                loadchartScatter(false, '');
            }
        });
        $(document).on('keyup keypress mouseup', '.from_size', function (e) {
            console.log('.....keyup keypress mouseup .from_size');
        });
        $(document).on('keyup keypress mouseup', '.to_size', function (e) {
            console.log('.....keyup keypress mouseup .to_size');
        });
        $(document).on('click', '#apply', function (e) {
            var check1 = check_grade_from_to();
            var check2 = check_size();
            if (check1 > 0 || check2 > 0) {
                showMessage('Message', 'Invalid values. Please check again!');
            } else {
                getAllScore();
                init_multiplier_surface(obj_score);
                ui_update_surface2();
                reorganize_scoreDetail();
            }
        });
        // Nhấn nút save profile
        $('#syncprofile').click(function () {
            if ($(this).hasClass('disabled')) {
                return false;
            }
            var profile_list = $("#profile").multipleSelect('getSelects');
            var profile_running = $("#profile_running").multipleSelect('getSelects');
            if (typeof profile_list === 'object' && typeof profile_running === 'object') {
                showMessage('Message', 'Please select "Profile list" or "Profile running" before click "Save" button');
                return false;
            }
            if (typeof profile_list !== 'object' && typeof profile_running !== 'object') {
                // Xác nhận việc sync and assign
                var stationid = $("#stationid").multipleSelect('getSelects');
                var title = 'Sync profile list and profile running to machine';
                getAllScore();
                $.msgBox({
                    title: 'Message',
                    content: 'Are you sure you want to change the setting?',
                    type: "mT",
                    buttons: [{value: "Yes"}, {value: "No"}],
                    success: function (result) {
                        if (result === 'Yes') {
                            loadingForm(true);
                            $.ajax({
                                type: 'POST',
                                url: "sync-profile-profile-running",
                                data: {
                                    profile_running: profile_running,
                                    station_id: stationid,
                                    profile_id: profile_list,
                                    none_ft: JSON.stringify(obj_score)
                                }
                            }).done(function (r) {
                                loadingForm(false);
                                if (r === "success") {
                                    showMessage('Message', title + ' successfully.');
                                } else if (r === 'invalid') {
                                    showMessage('Message', 'The profile has not synced to machine, please sync it to machine before configurating!');
                                } else {
                                    showMessage('Message', title + ' failed!');
                                }
                            }).fail(function (x) {
                                loadingForm(false);
                            });
                        }
                    }
                });
                return false;
            }
            // Đồng bộ danh sách profile cho máy
            if (typeof profile_list !== 'object') {
                var stationid = $("#stationid").multipleSelect('getSelects');
                // Nếu S/N chưa được chọn
                if (typeof stationid === 'object') {
                    showMessage('Message', 'Please select PhoneBot S/N!');
                    return false;
                }
                // Xác nhận việc asign profile list
                var title = 'Sync profile list to machine';
                $.msgBox({
                    title: 'Message',
                    content: 'Are you sure you want to sync profile list?',
                    type: "mT",
                    buttons: [{value: "Yes"}, {value: "No"}],
                    success: function (result) {
                        if (result === 'Yes') {
                            loadingForm(true);
                            $.ajax({
                                type: 'POST',
                                url: "sync-profile-list",
                                data: {
                                    station_id: stationid,
                                    profile_id: profile_list

                                }
                            }).done(function (r) {
                                loadingForm(false);
                                if (r === "success") {
                                    showMessage('Message', title + ' successfully.');
                                } else {
                                    showMessage('Message', title + ' failed!');
                                }
                            }).fail(function (x) {
                                loadingForm(false);
                            });
                        }
                    }
                });
                return false;
            }
            // Assign profile running cho máy
            if (typeof profile_running !== 'object') {
                var stationid = $("#stationid").multipleSelect('getSelects');
                // Xác nhận việc sync
                var title = 'Sync profile running to machine';
                getAllScore();
                $.msgBox({
                    title: 'Message',
                    content: 'Are you sure you want to change the setting?',
                    type: "mT",
                    buttons: [{value: "Yes"}, {value: "No"}],
                    success: function (result) {
                        if (result === 'Yes') {
                            loadingForm(true);
                            $.ajax({
                                type: 'POST',
                                url: "sync-profile-running",
                                data: {
                                    station_id: stationid,
                                    profile_running: profile_running,
                                    none_ft: JSON.stringify(obj_score)
                                }
                            }).done(function (r) {
                                loadingForm(false);
                                if (r === "success") {
                                    showMessage('Message', title + ' successfully.');
                                } else if (r === 'invalid') {
                                    showMessage('Message', 'The profile has not synced to machine, please sync it to machine before configurating!');
                                } else {
                                    showMessage('Message', title + ' failed!');
                                }
                            }).fail(function (x) {
                                loadingForm(false);
                            });
                        }
                    }
                });
                return false;
            }
        });
        check_check_all();
        myReset();
    });
    /*
     * Bat dau ham xu ly data
     */
    function get_surface_testing() {
        var obj = {};
        $(".surface_testing").each(function (index) {
            var key = $(this).attr('id');
            var val = false;
            if ($(this).is(':checked')) {
                val = true;
            }
            obj[key] = val;
        });
        set_object_score('surface_testing', obj);
        return obj;
    }
    function get_surface() {
        var arr = [];
        $(".surface").each(function (index) {
            var key = $('.key').eq(index).attr('ids');
            var name_surfaces = $('.name_surface').eq(index).html();
            var multiplier_surfaces = $('.multiplier_surface').eq(index).val();
            var objsub = {};
            objsub.id = parseInt(key);
            objsub.multiplier = parseFloat(multiplier_surfaces);
            objsub.name = name_surfaces;
            arr.push(objsub);
        });
        //console.log('get_surface:');console.log(arr);return false;
        set_object_score('surface', arr);
        return arr;
    }
    function get_defect() {
        var obj = obj_score['defect'];
        //bent_lift_config
        obj_bent_lift_config = obj.bent_lift_config;
        for (var keyr in arr_bent_lift) {
            for (var keyc in arr_tile_bent_lift) {
                var vl = $('#' + keyr + '_' + keyc).val();
                obj_bent_lift_config[keyr][keyc] = parseFloat(vl);
            }
        }
        //console.log('bent_lift_config:');console.log(obj_bent_lift_config);return false;
        obj.bent_lift_config = obj_bent_lift_config;
        //defect_type_1
        arr_defect_type_1 = [];
        $(".defect_type_1").each(function (index) {
            var key = $('.key_defect_type_1').eq(index).attr('ids');
            var names = $('.name_defect_type_1').eq(index).html();
            var multipliers = $('.multiplier_defect_type_1').eq(index).val();
            var max_unlimiteds = $('.max_unlimited_defect_type_1').eq(index).val();
            var objsub = {};
            objsub.id = parseInt(key);
            objsub.name = names;
            objsub.multiplier = parseInt(multipliers);
            objsub.max_unlimited = parseInt(max_unlimiteds);
            arr_defect_type_1.push(objsub);
        }); //console.log(arr_defect_type_1)
        obj.defect_type_1 = arr_defect_type_1;
        //defect_type_2
        arr_defect_type_2 = [];
        $(".defect_type_2").each(function (index) {
            var key = $('.key_defect_type_2').eq(index).attr('ids');
            var names = $('.name_defect_type_2').eq(index).html();
            var points = $('.point_defect_type_2').eq(index).val();
            var objsub = {};
            objsub.id = parseInt(key);
            objsub.name = names;
            objsub.point = parseInt(points);
            arr_defect_type_2.push(objsub);
        }); //console.log(arr_defect_type_1)
        obj.defect_type_2 = arr_defect_type_2; //console.log(obj);
        set_object_score('defect', obj);
        return obj;
    }
    function get_size() {
        var arr = [];
        $(".size").each(function (index) {
            var key = $('.key_size').eq(index).attr('ids');
            var from_sizes = $('.from_size').eq(index).val();
            var to_sizes = $('.to_size').eq(index).val();
            var multiplier_sizes = $('.multiplier_size').eq(index).val();
            var objsub = {};
            objsub.id = parseInt(key);
            objsub.from = parseFloat(from_sizes);
            objsub.to = parseFloat(to_sizes);
            objsub.multiplier = parseFloat(multiplier_sizes);
            arr.push(objsub);
        });
        //console.log('get_size:');console.log(arr);return false;
        set_object_score('size', arr);
        return arr;
    }
    function get_detail_grade(label_grade) {
        var bent = $('#bent').multipleSelect('getSelects');
        var lci = $('#lci').multipleSelect('getSelects');
        var lift = $('#lift').multipleSelect('getSelects');
        if (bent == 'No') {
            bent = true;
        } else {
            bent = false;
        }

        if (lci == 'No') {
            lci = true;
        } else {
            lci = false;
        }
        if (lift == 'No') {
            lift = true;
        } else {
            lift = false;
        }
        var arr_settings = []; //mang settings
        $(".settings").each(function (index) {
            var obj_settings_sub = {};
            var key_id = $(this).attr('ids');
            var name_surface = $(this).attr('label');
            var arr_list_defect = [];
            var name_surface_lower = name_surface.toLowerCase();
            //$( ".list_defect").each(function( indexs ) {
            $("#tbody_" + name_surface_lower + " > tr").each(function (indexs) {
                var obj_list_defects = {};
                var thiss = $(this);
                $(".maxs", thiss).each(function (i) {
                    var maxs = $(this).val();
                    var labelmaxs = $(this).attr('label');
                    obj_list_defects[labelmaxs] = parseFloat(maxs);
                });
                $(".maxsizes", thiss).each(function (i) {
                    var maxsizes = $(this).val();
                    var labelmaxsizes = $(this).attr('label');
                    obj_list_defects[labelmaxsizes] = parseFloat(maxsizes);
                });
                arr_list_defect.push(obj_list_defects);
            });
            obj_settings_sub.id = key_id;
            obj_settings_sub.list_defect = arr_list_defect;
            obj_settings_sub.name_surface = name_surface;
            arr_settings.push(obj_settings_sub);
        });
        //console.log('arr_settings set');
        //console.log(arr_settings);
        //set grade
        //console.log(obj_score);
        var obj_grade = obj_score['grade'];
        for (var key in obj_grade) {
            var name_grade = obj_grade[key]['name_grade'].toLowerCase();
            if (label_grade.toLowerCase() == name_grade) {
                obj_grade[key]['bent'] = bent;
                obj_grade[key]['lci'] = lci;
                obj_grade[key]['lift'] = lift;
                obj_grade[key]['settings'] = arr_settings;
                break;
            }
        }
        set_object_score('grade', obj_grade); //console.log(obj_score);console.log('----')


    }
    function set_object_score(key, ob) {
        obj_score[key] = ob;
    }
    function calculater_grade(nameinput) {
        console.log('Gọi hàm calculater_grade với tên ' + nameinput);
        var obj_grade = obj_score['grade'];
        var totalloadchart = 0;
        for (var key in obj_grade) {
            //for tung grade
            var name_grade = obj_grade[key]['name_grade'];
            if (typeof nameinput !== 'undefined') {
                if (name_grade == nameinput) {
                    var tmp = SetFromGrade(key, obj_grade);
                    totalloadchart += tmp;
                    break;
                }
            } else {
                var tmp = SetFromGrade(key, obj_grade);
                totalloadchart += tmp;
            }
        }
        //gán lai grade
        set_object_score('grade', obj_grade);
        if (totalloadchart > 0) {
            loadchart();
            loadchartScatter(false, '');
        }
    }
    function SetFromGrade(key, obj_grade) {
        console.log('Gọi hàm SetFromGrade để cập nhập lại điểm from');
        var obj_setting = obj_grade[key]['settings'];
        var name_grade = obj_grade[key]['name_grade'];
        var totals = 0;
        var totalloadchart = 0;
        for (var keys in obj_setting) {//for tung mat của 1 Grade				
            //get surface
            var name_surface = obj_setting[keys]['name_surface'];
            var multiplier_surface = parseFloat(get_multiplier_surface(name_surface)); //console.log('multiplier_surface:'+multiplier_surface);	
            if (multiplier_surface > 0) {
                arr_list_defect = obj_setting[keys]['list_defect'];
                for (name in arr_d) {
                    var sub_total1 = 0;
                    var multiplier_defects = get_multiplier_defects(name);
                    if (multiplier_defects[0] > 0) {
                        for (var index in arr_list_defect) {
                            var sl = parseFloat(arr_list_defect[index]['max_' + name]);
                            //console.log('sl:' + sl);
                            var slsize = parseFloat(arr_list_defect[index]['maxsize_' + name]);
                            //console.log('slsize:' + slsize);
                            var multiplier = get_multiplier_size(slsize);
                            //console.log('multiplier:' + multiplier);
                            sub_total1 += sl * multiplier; //*multiplier_surface;
                            //console.log('sub_total1:' + sub_total1);
                        }
                        //sub_total1 = sub_total1*multiplier_surface;
                        sub_total1 *= multiplier_surface * multiplier_defects[0];
                        if (sub_total1 > multiplier_defects[1]) {
                            sub_total1 = parseFloat(multiplier_defects[1]);
                        }
                        totals += sub_total1;
                    }
                }
            }
        }
        //tinh LCI/LiFT/BEnt
        var bent = obj_grade[key]['bent'];
        var lci = obj_grade[key]['lci'];
        var lift = obj_grade[key]['lift'];
        var multiplier_score_defects = get_multiplier_score_defects('bent', 'lci', 'lift');
        var sub_total2 = 0;
        console.log('bent: ' + bent);
        console.log('lci: ' + lci);
        console.log('lift: ' + lift);
        if (!bent) {
            sub_total2 += parseFloat(multiplier_score_defects[0]);
            console.log('bents: ' + parseFloat(multiplier_score_defects[0]));
        }
        if (!lci) {
            sub_total2 += parseFloat(multiplier_score_defects[1]);
            console.log('lcis: ' + parseFloat(multiplier_score_defects[1]));
        }
        if (!lift) {
            sub_total2 += parseFloat(multiplier_score_defects[2]);
            console.log('lifts: ' + parseFloat(multiplier_score_defects[2]));
        }
        totals += sub_total2;
        if (totals > 0) {
            totals = 8000 - totals;
            obj_grade[key]['score_from'] = totals;
            fill_grade_from(name_grade, totals, 'detail');
            //set gia tri cho chart
            //$.each( val_chart, function( keys, itemchart ) {
            for (var keys in val_chart) {
                var itemchart = val_chart[keys];
                labels = itemchart['label'];
                if (labels === name_grade.toUpperCase()) {
                    val_chart[keys]['from'] = Math.floor(totals);
                    break;
                }
            }
            totalloadchart += totals;
        }
        return totalloadchart;
    }
    function get_multiplier_score_defects(bent, lci, lift) {
        var defect_type_2 = obj_score['defect']['defect_type_2'];
        var point_bent = 0;
        var point_lci = 0;
        var point_lift = 0;
        bent = bent.toLowerCase();
        lci = lci.toLowerCase();
        lift = lift.toLowerCase();
        for (var index in defect_type_2) {
            if (0 === parseInt(defect_type_2[index]['id'])) {	//ss key cua bent			
                point_bent = parseFloat(defect_type_2[index]['point']);
            }
            if (1 === parseInt(defect_type_2[index]['id'])) {		//ss key cua lci		
                point_lci = parseFloat(defect_type_2[index]['point']);
            }
            if (3 === parseInt(defect_type_2[index]['id'])) {		//ss key cua lift		
                point_lift = parseFloat(defect_type_2[index]['point']);
            }
        }
        return [point_bent, point_lci, point_lift];
    }
    function get_multiplier_defects(name) {
        var defect_type_1 = obj_score['defect']['defect_type_1'];
        var max_unlimited = 0;
        var multiplier = 0;
        name = name.toLowerCase();
        for (var index in defect_type_1) {
            if (name == defect_type_1[index]['name'].toLowerCase()) {
                multiplier = defect_type_1[index]['multiplier'];
                max_unlimited = defect_type_1[index]['max_unlimited'];
                break;
            }
        }

        return [parseFloat(multiplier), parseFloat(max_unlimited)];
    }
    function get_multiplier_surface(name_surface) {//str.toLowerCase();
        var surface = obj_score['surface']; //console.log('name_surface:'+name_surface);
        var multiplier = 0;
        name_surface = name_surface.toLowerCase();
        for (var index in surface) {
            if (name_surface === surface[index]['name'].toLowerCase()) {
                multiplier = surface[index]['multiplier'];
                break;
            }
        }
        return multiplier;
    }
    function get_multiplier_size(slsize) {
        var size = obj_score['size'];
        var multiplier = 0;
        for (var index in size) {
            if (slsize > parseFloat(size[index]['from']) && slsize <= parseFloat(size[index]['to'])) {
                multiplier = size[index]['multiplier'];
                break;
            }
        }
        return parseFloat(multiplier);
    }
    function processDataLearn(phoneid) {
        console.log('phoneid: ' + phoneid);
        loadingForm(true);
        $.ajax({
            type: "POST",
            url: 'data-learn',
            data: {
                phoneid: phoneid
            }
        }).done(function (r) {
            loadingForm(false);
            console.log(arr_size_multiplier);
            var obj = JSON.parse(r);
            var o = {};
            for (var key in obj) {
                if (!o.hasOwnProperty(key)) {
                    o[key] = {};
                }
                for (var i in arr_size_multiplier) {
                    var key_size = arr_size_multiplier[i]['to'];
                    if (!o[key].hasOwnProperty(key_size)) {
                        o[key][key_size] = [];
                    }
                    for (var j in obj[key]) {
                        var val = parseFloat(obj[key][j]);
                        if (val > arr_size_multiplier[i]['from'] && val <= arr_size_multiplier[i]['to']) {
                            o[key][key_size].push(val);
                        }
                    }
                }
            }
            console.log(o);
        }).fail(function (x) {
            loadingForm(false);
        });
    }
    function getAllScore() {
        get_surface_testing();
        get_surface();
        get_defect();
        get_size();
        if (calgrade) { //tinh lai grade;
            calculater_grade();
            calgrade = false;
        }
    }
    function default_data() {
        var obj_default = {};
        obj_default['surface_testing'] = {"isFront": false, "isTop": false, "isLeft": false, "isLCI": false, "isBack": false, "isBottom": false, "isRight": false};
        obj_default['surface'] = [{"data": [], "id": 0, "multiplier": 0, "name": "Front"}, {"data": [], "id": 1, "multiplier": 0, "name": "Top"}, {"data": [], "id": 2, "multiplier": 0, "name": "Bottom"}, {"data": [], "id": 3, "multiplier": 0, "name": "Left"}, {"data": [], "id": 4, "multiplier": 0, "name": "Right"}, {"data": [], "id": 5, "multiplier": 0, "name": "Back"}];
        obj_default['defect'] = {"bent_lift_config": {"bent_config": {"distance_bottom": 0, "distance_left": 0, "distance_right": 0, "distance_top": 0}, "lift_config": {"distance_bottom": 0, "distance_left": 0, "distance_right": 0, "distance_top": 0}}, "defect_type_1": [{"id": 0, "max_unlimited": 0, "multiplier": 0, "name": "Scratches"}, {"id": 1, "max_unlimited": 0, "multiplier": 0, "name": "Chips"}, {"id": 2, "max_unlimited": 0, "multiplier": 0, "name": "Cracks"}, {"id": 3, "max_unlimited": 0, "multiplier": 0, "name": "Pitting/Ding/Dents"}, {"id": 4, "max_unlimited": 0, "multiplier": 0, "name": "Discoloration"}, {"id": 5, "max_unlimited": 0, "multiplier": 0, "name": "Paint peeling"}], "defect_type_2": [{"id": 0, "name": "Bent", "point": 0}, {"id": 1, "name": "LCI", "point": 0}, {"id": 2, "name": "LCD Damage", "point": 0}, {"id": 3, "name": "Lift LCD", "point": 0}, {"id": 4, "name": "Missing Mute Switch", "point": 0}, {"id": 5, "name": "Missing Volume buttons", "point": 0}, {"id": 6, "name": "Missing Power button", "point": 0}, {"id": 7, "name": "Missing Home button", "point": 0}, {"id": 8, "name": "Missing iSight camera", "point": 0}]};
        obj_default['grade'] = [{"bent": true, "id": 0, "lci": true, "lift": true, "name_grade": "A", "score_from": 0, "score_to": 0, "settings": [{"id": 0, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Front"}, {"id": 1, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Top"}, {"id": 2, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Bottom"}, {"id": 3, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Left"}, {"id": 4, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Right"}, {"id": 5, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Back"}]}, {"bent": true, "id": 1, "lci": true, "lift": true, "name_grade": "B", "score_from": 0, "score_to": 0, "settings": [{"id": 0, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Front"}, {"id": 1, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Top"}, {"id": 2, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Bottom"}, {"id": 3, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Left"}, {"id": 4, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Right"}, {"id": 5, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Back"}]}, {"bent": true, "id": 2, "lci": true, "lift": true, "name_grade": "C", "score_from": 0, "score_to": 0, "settings": [{"id": 0, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Front"}, {"id": 1, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Top"}, {"id": 2, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Bottom"}, {"id": 3, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Left"}, {"id": 4, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Right"}, {"id": 5, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Back"}]}, {"bent": true, "id": 3, "lci": true, "lift": true, "name_grade": "D", "score_from": 0, "score_to": 0, "settings": [{"id": 0, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Front"}, {"id": 1, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Top"}, {"id": 2, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Bottom"}, {"id": 3, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Left"}, {"id": 4, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Right"}, {"id": 5, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Back"}]}, {"bent": true, "id": 4, "lci": true, "lift": true, "name_grade": "E", "score_from": 0, "score_to": 0, "settings": [{"id": 0, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Front"}, {"id": 1, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Top"}, {"id": 2, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Bottom"}, {"id": 3, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Left"}, {"id": 4, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Right"}, {"id": 5, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Back"}]}];
        obj_default['size'] = [{"from": 0, "id": 0, "multiplier": 0, "to": 0}, {"from": 0, "id": 1, "multiplier": 0, "to": 0}, {"from": 0, "id": 2, "multiplier": 0, "to": 0}, {"from": 0, "id": 3, "multiplier": 0, "to": 0}, {"from": 0, "id": 4, "multiplier": 0, "to": 0}, {"from": 0, "id": 5, "multiplier": 0, "to": 0}, {"from": 0, "id": 6, "multiplier": 0, "to": 0}, {"from": 0, "id": 7, "multiplier": 0, "to": 0}];
        obj_default['datachart'] = {"data": [{"score": 1000, "quantity": 5}, {"score": 1200, "quantity": 10}, {"score": 1050, "quantity": 7}, {"score": 7500, "quantity": 5}, {"score": 7050, "quantity": 11}, {"score": 7500, "quantity": 5}, {"score": 7600, "quantity": 2}, {"score": 7650, "quantity": 1}, {"score": 7742, "quantity": 1}, {"score": 6000, "quantity": 20}, {"score": 6134, "quantity": 25}, {"score": 4225, "quantity": 15}, {"score": 3344, "quantity": 16}, {"score": 1296, "quantity": 9}, {"score": 1584, "quantity": 15}, {"score": 5345, "quantity": 30}, {"score": 6245, "quantity": 23}, {"score": 6798, "quantity": 35}, {"score": 7167, "quantity": 30}, {"score": 4012, "quantity": 20}, {"score": 4153, "quantity": 20}, {"score": 3451, "quantity": 15}], "step": 50};
        return obj_default;
    }
    function defaul_settings() {
        var settings = [{"id": 0, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Front"}, {"id": 1, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Top"}, {"id": 2, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Bottom"}, {"id": 3, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Left"}, {"id": 4, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Right"}, {"id": 5, "list_defect": [{"max_chips": 0, "max_cracks": 0, "max_dents": 0, "max_scratches": 0, "maxsize_chips": 0, "maxsize_cracks": 0, "maxsize_dents": 0, "maxsize_scratches": 0}], "name_surface": "Back"}];
        return settings;
    }
    function ui_update_test_setting(obj) {
        console.log('==> UI ui_update_test_setting functional test settings');
        if (obj.hasOwnProperty('surface_testing')) {
            for (var key1 in obj['surface_testing']) {
                if (obj['surface_testing'][key1]) {
                    $("#" + key1).prop('checked', true);
                } else {
                    $("#" + key1).prop('checked', false);
                }
            }
        } else {
            $(".iafts").prop('checked', false);
            console.log('NOT FOUND KEY surface_testing');
        }
        check_check_all();
    }
    function ui_update_surface(obj) {
        console.log('==> UI ui_update_surface update surface');
        if (obj.hasOwnProperty('surface')) {
            var objsurface = obj['surface'];
            $.each(objsurface, function (key, item) {
                var id = item['id'];
                var multiplier = item['multiplier'];
                $("#multiplier_" + id).val(multiplier);
            });
        } else {
            console.log('NOT FOUND KEY surface')
        }
    }
    function ui_update_defect(obj) {
        console.log('==> UI ui_update_defect update defect/minus score/bent-lift');
        if (obj.hasOwnProperty('defect')) {
            var obj_defect = obj['defect'];
            //defect_type_1
            if (obj_defect.hasOwnProperty('defect_type_1')) {
                var objdefecttype1 = obj_defect['defect_type_1'];
                $.each(objdefecttype1, function (key, itemtype1) {
                    var id = itemtype1['id'];
                    var max_unlimited = itemtype1['max_unlimited'];
                    var multiplier = itemtype1['multiplier'];
                    $("#multiplier_defect_type_1_" + id).val(multiplier);
                    $("#max_unlimited_defect_type_1_" + id).val(max_unlimited);
                });
            } else {
                console.log('NOT FOUND KEY defect_type_1');
            }
            //defect_type_2
            if (obj_defect.hasOwnProperty('defect_type_2')) {
                var objdefecttype2 = obj_defect['defect_type_2'];
                var i = 1;
                $.each(objdefecttype2, function (key, itemtype2) {
                    var id = itemtype2['id'];
                    var point = itemtype2['point'];
                    $("#point_defect_type_2_" + id).val(point);
                });
            } else {
                console.log('NOT FOUND KEY defect_type_2');
            }
            //BentLift level
            if (obj_defect.hasOwnProperty('bent_lift_config')) {
                var bent_lift = obj_defect['bent_lift_config'];
                for (var keyr in bent_lift) {
                    for (var keyc in bent_lift[keyr]) {
                        $("#" + keyr + '_' + keyc).val(bent_lift[keyr][keyc]);
                    }
                }
            } else {
                console.log('NOT FOUND KEY bent_lift_config');
            }
        } else {
            console.log('NOT FOUND KEY defect');
        }
    }
    function ui_update_size(obj) {
        console.log('==> UI ui_update_size update size');
        if (obj.hasOwnProperty('size')) {
            var objsize = obj['size'];
            $.each(objsize, function (key, itemsize) {
                var id = itemsize['id'];
                var multiplier = itemsize['multiplier'];
                var froms = itemsize['from'];
                var to = itemsize['to'];
                $("#from_size_" + id).val(froms);
                $("#to_size_" + id).val(to);
                $("#multiplier_size_" + id).val(multiplier);
            });
        } else {
            console.log('NOT FOUND KEY size');
        }
    }
    function ui_update_grade(obj) {
        console.log('==> UI ui_update_grade update grade');
        if (obj.hasOwnProperty('grade')) {
            var objgrade = obj['grade'];
            var totals = 0;
			val_chart = [];
            $.each(objgrade, function (key, itemgrade) {
                var name_grade = itemgrade['name_grade'];
                var score_from = itemgrade['score_from'];
                var score_to = itemgrade['score_to'];
                $("#score_from_" + name_grade).val(score_from);
                $("#score_from_" + name_grade + "_real").val(score_from < 0 ? 0 : score_from);
                $("#score_to_" + name_grade).val(score_to);
                totals += parseInt(score_from);
                totals += parseInt(score_to);
                /*$.each(val_chart, function (keys, itemchart) {
                    labels = itemchart['label'];
                    if (labels === name_grade) {
                        val_chart[keys]['from'] = score_from;
                        val_chart[keys]['to'] = score_to;
                    }
                });*/
				var tmp_c = {'label': 'A', 'from': 0, 'to': 0}
				tmp_c.label = name_grade;
				tmp_c.from = score_from;
				tmp_c.to = score_to;
				val_chart.push(tmp_c);
                if (!itemgrade.hasOwnProperty('settings')) {
                    console.log('Grade không có key settings => lấy mặc định');
                    obj_score['grade'][key]['settings'] = defaul_settings();
                }
            });
        } else {
            console.log('NOT FOUND KEY grade');
        }
    }
    function ui_update_surface2() {
        $.each(obj_multiplier_surface, function (k, v) {
            $("#mul" + k).html(v);
        });
    }
    function ui_update_all(obj) {
        console.log('UI gọi hàm ui_update_all');
        // Gán vào biến toàn cục
        obj_score = obj;
        // Khởi tạo 1 số biến
        init_multiplier_surface(obj_score);
        init_defect_surface(obj_score);
        init_size_multiplier(obj_score);
        init_grade_brief(obj_score, '');
        // gán = 0 truoc khi gan gia tri
        $(".input-sm").val(0);
        $(".mulsfview").html('0');
        // update giao diện bên dưới chart 1 để xem cho trực quan
        ui_update_surface2();
        // update giao diện functional test setting
        ui_update_test_setting(obj_score);
        // Cập nhập giao diện Surface
        ui_update_surface(obj_score);
        // Cập nhập giao diện Defect
        ui_update_defect(obj_score);
        // Cập nhập giao diện Multiplier of size
        ui_update_size(obj_score);
        // Cập nhập giao diện Grade
        ui_update_grade(obj_score);
        // Load chart 1
        loadchart();
        // Load chart 2
        loadchartScatter(true, '');
    }

    /*
     * Hàm cập nhập điểm cho giao diện Grade Score
     */
    function ui_score() {
        console.log('UI gọi hàm ui_score để load lại giao diện score');
        var objgrade = obj_score['grade'];
		val_chart =[];
        $.each(objgrade, function (key, itemgrade) {
            var name_grade = itemgrade['name_grade'];
            var score_from = itemgrade['score_from'];
            var score_to = itemgrade['score_to'];
            $("#score_from_" + name_grade).val(score_from);
            $("#score_from_" + name_grade + "_real").val(score_from < 0 ? 0 : score_from);
            $("#score_to_" + name_grade).val(score_to);
           /* $.each(val_chart, function (keys, itemchart) {
                labels = itemchart['label'];
                if (labels === name_grade) {
                    val_chart[keys]['from'] = score_from;
                    val_chart[keys]['to'] = score_to;
                    console.log('from: ' + score_from + ' to: ' + score_to);
                }
            });*/
			var tmp_c = {'label': 'A', 'from': 0, 'to': 0}
			tmp_c.label = name_grade;
			tmp_c.from = score_from;
			tmp_c.to = score_to;
			val_chart.push(tmp_c);
            if (!itemgrade.hasOwnProperty('settings')) {
                console.log('Grade không có key settings => lấy mặc định');
                obj_score['grade'][key]['settings'] = defaul_settings();
            }
        });
    }

    function loadchartScatter(first, grade_name) {
        console.log('Gọi hàm loadchartScatter(' + first + ',' + grade_name + ')');
        console.log(JSON.stringify(obj_grade_score));
        console.log(JSON.stringify(val_chart));
        console.log(grade_name);
        var max_y_chart = 0;
        var used = {};
        if (obj_score.hasOwnProperty('datachart')) {
            var datachart = obj_score.datachart;
            if (datachart.hasOwnProperty('data')) {
                var datas = datachart.data;
                // Cập nhập lại grade cho datachart
                if (!first && grade_name !== '') {
                    // Tìm xem vùng nào nằm ra ngoài vùng from-top                
                    $.each(datas, function (index, value) {
                        var from_to = obj_grade_score[grade_name];
                        console.log('from_to ' + JSON.stringify(from_to));
                        if (grade_name.toUpperCase() === value['grade']) {
                            var score = parseInt(value['score']);
                            if (score < from_to[0]) {
                                var flag = false;
                                console.log('điểm nằm ngoài left: ' + JSON.stringify(value));
                                $.each(obj_grade_score, function (grn, ftv) {
                                    if (score >= ftv[0] && score <= ftv[1]) {
                                        value['grade'] = grn.toUpperCase();
                                        console.log('Cập nhập tới grade mới left là: ' + JSON.stringify(value));
                                        flag = true;
                                        return true;
                                    }
                                });
                                if (!flag) {
                                    used[score] = value['quantity'];
                                }
                            } else if (score > from_to[1]) {
                                var flag = false;
                                console.log('điểm nằm ngoài right: ' + JSON.stringify(value));
                                $.each(obj_grade_score, function (grn, ftv) {
                                    if (score >= ftv[0] && score <= ftv[1]) {
                                        value['grade'] = grn.toUpperCase();
                                        console.log('Cập nhập tới grade mới right là: ' + JSON.stringify(value));
                                        flag = true;
                                        return true;
                                    }
                                });
                                if (!flag) {
                                    used[score] = value['quantity'];
                                }
                            }
                        }
                    });
                }
                console.log('used: ' + JSON.stringify(used));
                $.each(val_chart, function (key, itemchart) {
                    labels = itemchart['label'];
                    var from = parseInt(itemchart['from']);
                    var to = parseInt(itemchart['to']);
                    var tmps = [];
                    var tmps1 = [];
                    var tmps2 = {};
                    $.each(datas, function (key1, item) {
                        //if (first) {
                        if (itemchart['label'] === item['grade'] && !used.hasOwnProperty(item.score)) {
                            var score = parseInt(item.score);
                            var quantity = parseInt(item.quantity);
                            if (score <= to && score >= from) {
                                tmps1.push(score);
                                tmps2[score] = quantity;
                            }
                        }
                    });
                    // Sắp xếp lại                   
                    tmps1.sort(function (a, b) {
                        return a - b;
                    });
                    // Gán lại key để tạo mảng tọa độ
                    $.each(tmps1, function (k1, it1) {
                        tmps.push({x: it1, y: tmps2[it1]});
                        if (max_y_chart < parseInt(tmps2[it1])) {
                            max_y_chart = parseInt(tmps2[it1]);
                        }
                    });
                    if (tmps1.length > 0) {
                        // Thêm tọa độ cuối
                        if (tmps1[tmps1.length - 1] < to) {
                            tmps.push({x: to, y: 0});
                        }
                        // Thêm tọa độ đầu
                        if (tmps1[0] > from) {
                            tmps.unshift({x: (from < 0 ? 0 : from), y: 0});
                        }
                    }
                    chart_scatter[labels] = tmps;
                });
            }
        }
        if (max_y_chart > 0) {
            var tmpsplit = max_y_chart % 5;
            if (tmpsplit > 0) {
                max_y_chart = Math.floor(max_y_chart / 5) * 5 + 5;
            }
        } else {
            max_y_chart = 30;
        }
        console.log(chart_scatter);
        chartScatter(max_y_chart);
    }
    function load_ui() {
        var obj = default_data();
        obj_score = obj;
        // Giao dien cho Function test settings
        var obj_surface_testing = obj['surface_testing'];
        console.log(obj_surface_testing);
        var htmlsurface_testing = '';
        for (var keys in obj_surface_testing) {
            console.log(obj_surface_testing[keys]);
            var checked = ''
            if (obj_surface_testing[keys]) {
                checked = 'checked';
            }
            var testx = keys.substring(2);
            htmlsurface_testing += '<div class="col-md-3">';
            htmlsurface_testing += '<div><input type="checkbox" ' + checked + ' class="surface_testing iafts" autocomplete="off" name="' + keys + '" id="' + keys + '">';
            htmlsurface_testing += ' <label class="applyfor" for="enable_stop_first_fail_function">' + testx + '</label></div>';
            htmlsurface_testing += '</div>';
        }
        $('#htmlsurface_testing').html(htmlsurface_testing);
        check_check_all();
        // Giao dien Multiplier of surface
        var htmlsurface = '';
        var i = 1;
        var objsurface = obj['surface'];
        $.each(objsurface, function (key, item) {
            var id = item['id'];
            var multiplier = item['multiplier'];
            var name = item['name'];
            htmlsurface += '<tr class="surface">';
            htmlsurface += '<td style="text-align:center" class="key" ids ="' + id + '">' + i + '</td>';
            htmlsurface += '<td style="text-align:center" class="name_surface">' + name + '</td>';
            htmlsurface += '<td style="text-align:center">';
            htmlsurface += '<input style="width:100%;text-align:center" id="multiplier_' + id + '" class="form-control input-sm diin calgrade multiplier_surface" value="' + multiplier + '"  autocomplete="off" min="0" max="100" step="0.01" type="number">';
            htmlsurface += '</td>';
            htmlsurface += '</tr>';
            i++;
        });
        $('#htmlsurface').html(htmlsurface);
        //defect_type_1
        var obj_defect = obj['defect'];
        var objdefecttype1 = obj_defect['defect_type_1'];
        var htmldefecttype1 = "";
        var i = 1;
        $.each(objdefecttype1, function (key, itemtype1) {
            var id = itemtype1['id'];
            var max_unlimited = itemtype1['max_unlimited'];
            var multiplier = itemtype1['multiplier'];
            var name = itemtype1['name'];
            htmldefecttype1 += '<tr class="defect_type_1">';
            htmldefecttype1 += '<td style="text-align:center" class="key_defect_type_1" ids ="' + id + '">' + i + '</td>';
            htmldefecttype1 += '<td style="text-align:center" class="name_defect_type_1">' + name + '</td>';
            htmldefecttype1 += '<td style="text-align:center">';
            htmldefecttype1 += '<input style="width:100%;text-align:center" id="multiplier_defect_type_1_' + id + '" class="form-control input-sm diin calgrade multiplier_defect_type_1" value="' + multiplier + '" autocomplete="off" min="0" max="100" step="0.01" type="number">';
            htmldefecttype1 += '</td>';
            htmldefecttype1 += '<td style="text-align:center">';
            htmldefecttype1 += '<input style="width:100%;text-align:center" id="max_unlimited_defect_type_1_' + id + '" class="form-control input-sm diin calgrade max_unlimited_defect_type_1" value="' + max_unlimited + '" autocomplete="off" min="0" max="8000" type="number">';
            htmldefecttype1 += '</td>';
            htmldefecttype1 += '</tr>';
            i++;
        });
        $('#htmldefecttype1').html(htmldefecttype1);
        //defect_type_2
        var objdefecttype2 = obj_defect['defect_type_2'];
        var htmldefecttype2 = "";
        var i = 1;
        $.each(objdefecttype2, function (key, itemtype2) {
            var id = itemtype2['id'];
            var point = itemtype2['point'];
            var name = itemtype2['name'];
            htmldefecttype2 += '<tr class="defect_type_2">';
            htmldefecttype2 += '<td style="text-align:center" class="key_defect_type_2" ids ="' + id + '">' + i + '</td>';
            htmldefecttype2 += '<td style="text-align:center" class="name_defect_type_2">' + name + '</td>';
            htmldefecttype2 += '<td style="text-align:center">';
            htmldefecttype2 += '<input style="width:100%;text-align:center" id="point_defect_type_2_' + id + '" class="form-control input-sm diin calgrade point_defect_type_2" value="' + point + '" autocomplete="off" min="0" max="8000" type="number">';
            htmldefecttype2 += '</td>';
            htmldefecttype2 += '</tr>';
            i++;
        });
        $('#htmldefecttype2').html(htmldefecttype2);
        //BentLift level		
        var bent_lift = obj_defect['bent_lift_config'];
        var htmlbent_lift = "";
        var i = 1;
        for (var keyr in arr_bent_lift) {
            htmlbent_lift += '<tr class="bent_lift_config">';
            htmlbent_lift += '<td style="text-align:center">' + arr_bent_lift[keyr] + '</td>';
            for (var keyc in arr_tile_bent_lift) {
                var vl = 0;
                if (bent_lift.hasOwnProperty(keyr)) {
                    if (bent_lift[keyr].hasOwnProperty(keyc)) {
                        var vl = bent_lift[keyr][keyc];
                    }
                }
                if ('bent_config' == keyr) {
                    htmlbent_lift += '<td style="text-align:center">';
                    htmlbent_lift += '<input style="width:100%;text-align:center" class="form-control input-sm diin bent_lifts" id="' + keyr + '_' + keyc + '" value="' + vl + '" autocomplete="off" min="0" max="10" step="0.01"  type="number">';
                    htmlbent_lift += '</td>';
                } else {
                    //console.log(vl);return false;
                    htmlbent_lift += '<td style="text-align:center">';
                    htmlbent_lift += '<input style="width:100%;text-align:center" class="form-control input-sm diin bent_lifts" id="' + keyr + '_' + keyc + '" value="' + vl + '" autocomplete="off" min="0" max="10" step="0.01" type="number">';
                    htmlbent_lift += '</td>';
                }
            }
            htmlbent_lift += '</tr>';
        }
        $('#htmlbent_lift').html(htmlbent_lift);
        //Multiplier of size
        var objsize = obj['size'];
        var htmlsize = "";
        var i = 1;
        $.each(objsize, function (key, itemsize) {
            var id = itemsize['id'];
            var multiplier = itemsize['multiplier'];
            var froms = itemsize['from'];
            var to = itemsize['to'];
            var disableds = 's';
            if (i == 1) {
                disableds = 'disabled';
            }
            htmlsize += '<tr class="size">';
            htmlsize += '<td style="text-align:center" class="key_size" ids ="' + id + '">' + i + '</td>';
            htmlsize += '<td style="text-align:center">'
            htmlsize += '<input style="width:30%;text-align:center" id="from_size_' + id + '" class="form-control input-sm diin calgrade from_size" ' + disableds + ' value="' + froms + '" autocomplete="off" min="0" max="200" step="0.1" type="number">';
            htmlsize += '  < Size ≤  ';
            htmlsize += '<input style="width:30%;text-align:center" id="to_size_' + id + '" class="form-control input-sm diin calgrade to_size" value="' + to + '" autocomplete="off" min="0" max="200" step="0.1" type="number">';
            htmlsize += '</td>';
            htmlsize += '<td style="text-align:center">';
            htmlsize += '<input style="width:100%;text-align:center" id="multiplier_size_' + id + '" class="form-control input-sm diin calgrade multiplier_size" value="' + multiplier + '" autocomplete="off" min="0" max="100" step="0.01" type="number">';
            htmlsize += '</td>';
            htmlsize += '</tr>';
            i++;
        });
        $('#htmlsize').html(htmlsize);
        //Grade
        var objgrade = obj['grade'];
        var htmlgrade = '';
        var i = 1;
        //var grade_format ='';
		val_chart = [];
        $.each(objgrade, function (key, itemgrade) {
            var name_grade = itemgrade['name_grade'];
            var score_from = itemgrade['score_from'];
            var score_to = itemgrade['score_to'];
            $.each(val_chart, function (keys, itemchart) {
                labels = itemchart['label'];
                if (labels === name_grade) {
                    val_chart[keys]['from'] = score_from;
                    val_chart[keys]['to'] = score_to;
                }
            });
            //grade_format
            htmlgrade += '<tr>';
            htmlgrade += '<td style="text-align:center" class="name_grade"><span class="lablel_name_grade">' + name_grade + '</span><input type="text" value="'+name_grade+'" class="form-control input-sm diin txt_name_grade" style="display:none" id="txt_'+name_grade+'"/></td>';
            htmlgrade += '<td style="text-align:center">';
            htmlgrade += '<input type="hidden" id="score_from_' + name_grade + '" class="form-control input-sm diin score_from" label_grade="' + name_grade + '" value="' + score_from + '" autocomplete="off" min="0" max="8000">';
            htmlgrade += '<input type="number" id="score_from_' + name_grade + '_real" class="form-control input-sm score_from_real" value="' + (score_from < 0 ? 0 : score_from) + '" autocomplete="off" min="0" max="8000" style="width: 100%; text-align: center">';
            htmlgrade += '</td>';
            htmlgrade += '<td style="text-align:center">';
            htmlgrade += '<input style="width:100%;text-align:center" id="score_to_' + name_grade + '" class="form-control input-sm diin score_to" label_grade="' + name_grade + '" value="' + score_to + '" autocomplete="off" min="0" max="8000" type="number">';
            htmlgrade += '</td>';
            htmlgrade += '<td style="text-align:center" >';
            var lower_name = name_grade.toLowerCase();
            htmlgrade += '<a id="detail_grade_' + lower_name + '" label_grade="' + name_grade + '" class="various fancybox detail_grade" title="Detail" href="#stepInfoContainer">Detail</a>';
            htmlgrade += '</td>';
			htmlgrade += '<td style="text-align:center" >';
			htmlgrade += '<a class="btn_delete_grade" href=""><img class="delete_grade" src="/web/img/delete_constraints.png" style="height:13px;weight:13px;" alt="delete"></a>';
            htmlgrade += '</td>';
			htmlgrade += '</tr>';
            i++;
			///set gia tri cho chart
			var tmp_c = {'label': 'A', 'from': 0, 'to': 0}
			tmp_c.label = name_grade;
			tmp_c.from = score_from;
			tmp_c.to = score_to;
			val_chart.push(tmp_c);
			
        });
        $('#htmlgrade').html(htmlgrade);
        loadchart();
        loadchartScatter(true, '');
    }
    function defaulhtml_detail() {
        var arrs = ["Front", "Top", "Bottom", "Left", "Right", "Back"];
        return arrs;
    }
    function load_detail_grade(label_grade) {
        var obj_grade = obj_score['grade'];
        for (var key in obj_grade) {
            var name_grade = obj_grade[key]['name_grade'].toLowerCase();
            if (label_grade.toLowerCase() == name_grade) {
                var bent = obj_grade[key]['bent'];
                var bents = 'Yes';
                if (bent) {
                    bents = 'No';
                }
                var lci = obj_grade[key]['lci'];
                var lcis = 'Yes';
                if (lci) {
                    lcis = 'No';
                }
                var lift = obj_grade[key]['lift'];
                lifts = 'Yes';
                if (lift) {
                    lifts = 'No';
                }//console.log('seelct bent:'+bents);
                $('#bent').multipleSelect('setSelects', [bents]);
                $('#lci').multipleSelect('setSelects', [lcis]);
                $('#lift').multipleSelect('setSelects', [lifts]);
                var settings_all = obj_grade[key]['settings'];
                var htmlsettings = '';
                var arr_html = defaulhtml_detail();
                for (var keyhtml in arr_html) {
                    var namehtml = arr_html[keyhtml];
                    var name_surface = namehtml;
                    var key_settings = '';
                    for (var keysetting in settings_all) {
                        settings = settings_all[keysetting];
                        //$.each( settings_all, function( keysetting, settings ) {
                        var name_surfaces = settings['name_surface'];
                        if (namehtml.toLowerCase() === name_surfaces.toLowerCase()) {
                            key_settings = settings['id'];
                            htmlsettings += '<div class="row settings" label="' + name_surface + '" ids="' + key_settings + '">';
                            htmlsettings += '<label class="control-label name_surface" ><b>Surface: </b>' + name_surface + '</label>';
                            htmlsettings += '<table class="table table-bordered table-striped">';
                            htmlsettings += '<thead>';
                            htmlsettings += '<tr>';
                            htmlsettings += '<th style="text-align:center" rowspan="2">No.</th>';
                            //for
                            var title2 = ''; //console.log(arr_d)	;return false;	
                            for (var key in arr_d) {
                                htmlsettings += '<th style="text-align:center;" colspan="2">' + arr_d[key] + '</th>'

                                title2 += '<th style="text-align:center;">Quantity</th>';
                                title2 += '<th style="text-align:center;">Size (mm)</th>';
                            }
                            //delete
                            htmlsettings += '<th style="text-align:center" rowspan="2">Delete</th>';
                            htmlsettings += '</tr>';
                            htmlsettings += '<tr>';
                            htmlsettings += title2;
                            htmlsettings += '</tr>';
                            htmlsettings += '</thead>';
                            //for tung tr
                            var ik = 1;
                            lowername_surface = name_surface.toLowerCase();
                            htmlsettings += '<tbody id="tbody_' + lowername_surface + '">';
                            $.each(settings['list_defect'], function (keylist, vallist) {
                                var classs = 'addmore' + lowername_surface;
                                if (ik == 1) {
                                    classs += ' ' + lowername_surface + 'end';
                                } //console.log(classs);
                                htmlsettings += '<tr class="' + classs + ' list_defect">';
                                htmlsettings += '<td style="text-align:center" class="index' + lowername_surface + '">' + ik + '</td>';
                                for (var keys in arr_d) {
                                    //"max_chips":0,"maxsize_chips":0,
                                    var valmax = vallist['max_' + keys];
                                    var valmaxsize = vallist['maxsize_' + keys];
                                    htmlsettings += '<td style="text-align:center">';
                                    htmlsettings += '<input style="width:100%;text-align:center" class="form-control input-sm diin maxs max_' + keys + '" label = "max_' + keys + '" value="' + valmax + '" autocomplete="off" min="0" max="100" type="number">';
                                    htmlsettings += '</td>';
                                    htmlsettings += '<td style="text-align:center">';
                                    htmlsettings += '<input style="width:100%;text-align:center" class="form-control input-sm diin maxsizes maxsize_' + keys + '_' + lowername_surface + ' maxsize_' + keys + '" label = "maxsize_' + keys + '" value="' + valmaxsize + '" autocomplete="off" step="0.1" min="0" max="200" type="number">';
                                    htmlsettings += '</td>';
                                }
                                htmlsettings += '<td style="text-align:center">';
                                htmlsettings += '<a class="btn_delete_constraints various fancybox disabled"href=""><img class="delete_constraints" ids="' + lowername_surface + '" src="/web/img/delete_constraints.png" style="height:13px;weight:13px;" alt="delete"></a>';
                                htmlsettings += '</td>';
                                htmlsettings += '</tr>';
                                ik++;
                            });
                            htmlsettings += '</tbody>';
                            htmlsettings += '<tr>';
                            htmlsettings += '<td colspan="10">';
                            htmlsettings += '<a id="addmore' + lowername_surface + '" ids="' + lowername_surface + '" class="addmore" title="Add more" href="#">';
                            htmlsettings += 'Add more...';
                            htmlsettings += '</a>';
                            htmlsettings += '</td>';
                            htmlsettings += '</tr>';
                            htmlsettings += '</table>';
                            htmlsettings += '</div>';
                            break;
                        }
                    }
                }
                $('#htmlsettings').html(htmlsettings);
            }
        }
    }
    function fill_grade_from(label_grade, score_from, text) {
        console.log('Gọi hàm fill_grade_from');
        var up_down = '';
        var dis_sx = '';
        if (text === 'chartmove' || text === 'detail') {//keo tu chart
            $("#htmlgrade > tr").each(function (i) {
                var _label = $(".score_from").eq(i).attr('label_grade');
                _label = _label.toLowerCase();
                if (label_grade.toLowerCase() === _label) {
                    var tmp = $(".score_from").eq(i).val();
                    if (parseInt(tmp) > parseInt(score_from)) {
                        up_down = 'down';
                        dis_sx = parseInt(tmp) - parseInt(score_from);
                    } else {
                        up_down = 'up';
                        dis_sx = parseInt(score_from) - parseInt(tmp)
                    }
                    $(".score_from").eq(i).val(score_from);
                }
            });
        } else {//from
            for (var keys in val_chart) {
                var itemchart = val_chart[keys];
                labels = itemchart['label'];
                if (labels === label_grade) {
                    var tmp = val_chart[keys]['from'];
                    if (parseInt(tmp) > parseInt(score_from)) {
                        up_down = 'down';
                        dis_sx = parseInt(tmp) - parseInt(score_from);
                    } else {
                        up_down = 'up';
                        dis_sx = parseInt(score_from) - parseInt(tmp)
                    }
                    val_chart[keys]['from'] = score_from;
                    break;
                }
            }
        }
        if (text !== 'detail') {
            //console.log(obj_score['grade']);	//console.log('------------');		
            var obj_grage = obj_score['grade'];
            for (var key in obj_grage) {//console.log(key+'------------');	
                var name_grade = obj_grage[key]['name_grade'].toLowerCase();
                if (label_grade.toLowerCase() === name_grade) {
                    obj_grage[key]['score_from'] = score_from;
                }
            }
            if (dis_sx > 0) {
                console.log(+dis_sx + '---' + up_down);
                console.log(obj_grage);
                set_object_score('grade', obj_grage);
                //console.log(obj_grage);
                getAllScore();
                console.log('*************************START***************************');
                graphToData(obj_score, label_grade.toLowerCase(), dis_sx, up_down); //down
                console.log('**************************END***************************');
                ui_update_surface(obj_score); //gan lai surface
                ui_score(); // Update lại giá trị grade
            }
        }
        return false;
    }
    function fill_grade_to(label_grade, score_to, chartmove) {
        if (typeof chartmove !== 'undefined') {//keo tu chart
            $("#htmlgrade > tr").each(function (i) {
                var _label = $(".score_to").eq(i).attr('label_grade');
                _label = _label.toLowerCase();
                if (label_grade.toLowerCase() == _label) {
                    $(".score_to").eq(i).val(score_to);
                }
            });
        } else {
            $.each(val_chart, function (keys, itemchart) {
                labels = itemchart['label'];
                if (labels === label_grade) {
                    val_chart[keys]['to'] = score_to;
                }
            });
        }
        var obj_grage = obj_score['grade'];
        for (var key in obj_grage) {
            var name_grade = obj_grage[key]['name_grade'].toLowerCase();
            obj_grade_score[name_grade] = [obj_grage[key]['score_from'], obj_grage[key]['score_to']];
            if (label_grade.toLowerCase() === name_grade) {
                obj_grage[key]['score_to'] = score_to;
                obj_grade_score[name_grade] = [obj_grage[key]['score_from'], score_to];
            }
        }
        set_object_score('grade', obj_grage);
    }
    var valresize = false;
    function loadchart() {
        console.log('call to loadchart..........');
        $('#mychart').html('');
        var w = $('#mychart').width(); //console.log('w:'+w);
        $(tick_y).css('bottom', distance + 'px');
        var h = $('#mychart').height(); ///console.log('h:'+h);
        var segment_x = Math.floor(w / axis_x.length); //giá trị 1 khoảng của trục x tính ra px
        //tính lại width
        w = segment_x * axis_x.length + 2; //console.log();
        $('#mychart').css('width', w + 'px');
        $(tick_y).css('bottom', distance + 'px');
        var segment_y = Math.floor(h / axis_y.length); //giá trị 1 khoảng của trục y tính ra px
        var scale_x = segment_x / axis_x[0]; //tỉ lệ xich
        // Tạo các label, đường kéo dài  trên trục y
        var tick_y = '<div class="tick_y"></div>';
        var tick_y_h = '<div class="tick_y_h"></div>';
        var map_y = {};
        for (var i in axis_y) {
            var distance = (parseInt(i) + 1) * segment_y;
            map_y[axis_y[i]] = distance;
            //label y
            var tick_y_label = '<div class="tick_y_label">' + axis_y[i] + '</div>';
            var tmp = $(tick_y).css('bottom', distance + 'px');
            var tmp_label = $(tick_y_label).css('bottom', (distance - 10) + 'px');
            //duong keo dai
            var tmp_h = $(tick_y_h).css({"bottom": distance + "px", "width": w + "px"});
            $('#mychart').append(tmp).append(tmp_label).append(tmp_h);
        }
        // chu Grade
        //distance = distance+5
        var grade = '<div class="tick_y_label" style="margin-left:14px;bottom:' + (h + 10) + 'px;font-size:16px;color:#767676">Grade</div>';
        $('#mychart').append(grade);
        // Tạo các label trên trục x
        var tick_x = '<div class="tick_x"></div>';
        var distance_final = segment_x; //độ dài khoảng cách của truc x
        var tick_x_h = '<div class="tick_x_h"></div>'; //duong keo dai của trục x
        var tick_x_y = '<div class="tick_x_label" style="margin-left:-5px">0</div>';
        $('#mychart').append(tick_x_y);
        for (var i in axis_x) {
            var distance = (parseInt(i) + 1) * segment_x;
            var tick_x_label = '<div class="tick_x_label">' + axis_x[i] + '</div>';
            var tmp = $(tick_x).css('left', distance + 'px');
            var tmp_label = $(tick_x_label).css('left', (distance - 15) + 'px');
            distance_final = distance;
            $('#mychart').append(tmp).append(tmp_label);
            //ve duong keo dai của trục x
            //lay chieu cao lon nhat trong mang cac label
            var height_max = 0;
            for (var i in val_chart) {
                var label = val_chart[i].label;
                var heights = map_y[label] - half_width_label;
                var start = val_chart[i].from * scale_x;
                var width = (val_chart[i].to - val_chart[i].from) * scale_x;
                if (height_max < heights && distance > start && distance < (start + width)) {                     //lay do cao lớn nhất mà có khối label nằm trong khoảng này (không xét trường hợp = vì trường hợp = đã vẽ đường cho từng khối riêng bên dưới)
                    height_max = heights;
                }
            }
            var tmp_tick_x_h = $(tick_x_h).css({"left": distance + "px", "height": height_max + "px"});
            $('#mychart').append(tmp_tick_x_h);
        }
        //chu Score
        var mxleft = w + 10;
        var score = '<div class="tick_x_label" style="margin-left:' + mxleft + 'px;font-size:16px;bottom:-9px;color:#767676">Score</div>';
        $('#mychart').append(score);
        // Tạo ra chart
        for (var i in val_chart) {
            var label = val_chart[i].label;
            var bottom = map_y[label] - half_width_label;
            var start = val_chart[i].from * scale_x;
            var width = (val_chart[i].to - val_chart[i].from) * scale_x;
            if (start < 0) {
                start = 0;
                width = (val_chart[i].to - 0) * scale_x;
            }
            if (width > 0) {
                if (width < 10) {
                    sub_width = Math.floor(width / 2);
                } else {
                    sub_width = 5;
                }
                obj_subwidth['cluster_' + label] = sub_width;
                var element = $('<div id="cluster_' + label + '" class="cluster"></div>').css({"left": start + "px", "bottom": bottom + "px", "width": width + "px"});
                $('#mychart').append(element);
                //Tạo hai thẻ div nhỏ 2 bên khối để mouse chuột kéo đi
                var sub_element_l = $('<div id="left_sub_cluster_' + label + '" idlabel="cluster_' + label + '" idnumber="tick_x_number_' + label + '" class="sub_cluster" ></div>').css({"left": start + "px", "bottom": bottom + "px", "width": sub_width + "px"});
                var ds = start + width - sub_width;
                var sub_element_r = $('<div id="right_sub_cluster_' + label + '" idlabel="cluster_' + label + '" idnumber="tick_x_number_' + label + '" class="sub_cluster"></div>').css({"left": ds + "px", "bottom": bottom + "px", "width": sub_width + "px"});
                $('#mychart').append(sub_element_l).append(sub_element_r);
                //Tạo số màu vàng trên khối					
                var bottoms = map_y[label] + half_width_label + 3;
                var number_label = '<div class="tick_x_number" id="tick_x_number_' + label + '"><span id="txn_left_' + label + '" style=float:left>' + (val_chart[i].from < 0 ? 0 : val_chart[i].from) + '</span><span id="txn_right_' + label + '" style=float:right>' + val_chart[i].to + '</span></div>';
                var css_number_label = $(number_label).css({"left": start + "px", "bottom": bottoms + "px", "width": width + "px"});
                $('#mychart').append(css_number_label);
                //đường phụ trục dài trục x theo label					
                var tmp_tick_x_h1 = $(tick_x_h).css({"left": start + "px", "height": bottom + "px"});
                var starts = start + width;
                var tmp_tick_x_h2 = $(tick_x_h).css({"left": starts + "px", "height": bottom + "px"});
                $('#mychart').append(tmp_tick_x_h1).append(tmp_tick_x_h2);
            }
        }
        // Xử lý việc resize
        valresize = true;
        $('#mychart>.sub_cluster').on('mousedown', function (e) {
            isResizing = true; // bật cờ báo resize có thể resize
            lastDownX = e.clientX; // lấy tọa độ ngang       
            eleResizeID = $(this).attr('idlabel');
            eleResizenumberID = $(this).attr('idnumber');
            eleResizeWidth = $('#' + eleResizeID).width();
            eleResizeLeft = parseFloat($('#' + eleResizeID).css('left'));
            label_val = eleResizeID.split('_')[1];
            subID = $(this).attr('id');
            subIDs = subID.split('_')[0];
            sub_width = obj_subwidth[eleResizeID];
            move_x_tmp = 0;
            // console.log('1 mousedown isResizing: ' + isResizing);
        });
        $('#mychart').on('mousemove', function (e) {
            // console.log('2 mousemove isResizing: ' + isResizing);
            if (!isResizing) // nếu cờ cho phép resize chưa bật thì ko làm gì cả
                return;
            var offsetRight = e.clientX;
            if (subIDs === 'left') {//kéo đầu bên trái của label, tăng from của grade
                var new_left = eleResizeLeft; //truong hop = lastDownX==offsetRight
                if (lastDownX < offsetRight) { // resize về phải
                    var move_x = (offsetRight - lastDownX);
                    move_x_tmp = move_x;
                    var new_width = eleResizeWidth - move_x;
                    new_left = eleResizeLeft + move_x;
                    var limit = eleResizeWidth + eleResizeLeft;
                    //giới hạn việc di chuyển
                    var limit = eleResizeWidth + eleResizeLeft;
                    if (new_left > limit || new_left === limit) {
                        return false;
                    }
                } else if (lastDownX > offsetRight) { //resize về trái                     
                    var move_x = (lastDownX - offsetRight);
                    move_x_tmp = move_x;
                    var new_width = eleResizeWidth + move_x;
                    new_left = eleResizeLeft - move_x;
                    //gioi hạn việc di chuyển
                    if (new_left < 0) {
                        return false;
                    }
                }
                // cập nhập vào mảng giá trị              
                for (var i in val_chart) {
                    if (label_val === val_chart[i].label) {
                        val_chart[i].from = Math.floor(new_left / scale_x);
                        $('#txn_' + subIDs + '_' + label_val).html(val_chart[i].from); //gán giá trị cho số nằm trên khối                    
                        break;
                    }
                }
                $('#' + subID).css('left', new_left + 'px'); // cập nhập giao diện							
                $('#' + eleResizeID).css({"left": new_left + "px", "width": new_width + "px"}); // cập nhập giao diện
                $('#' + eleResizenumberID).css({"left": new_left + "px", "width": new_width + "px"}); // cập nhập giao diện
            } else {//kéo đầu bên phải của label va gan to
                var new_width = eleResizeWidth; //truong hop = lastDownX==offsetRight
                if (lastDownX < offsetRight) { // resize về phải
                    var move_x = (offsetRight - lastDownX);
                    move_x_tmp = move_x;
                    new_width = eleResizeWidth + move_x;
                    var new_leftsub = eleResizeLeft + new_width - sub_width;
                    //gioi hạng việc di chuyển														
                    if (new_leftsub > (distance_final - sub_width)) {
                        return false;
                    }
                } else if (lastDownX > offsetRight) { // resize về trái
                    var move_x = (lastDownX - offsetRight);
                    move_x_tmp = move_x;
                    new_width = eleResizeWidth - move_x;
                    var new_leftsub = eleResizeLeft + new_width - sub_width;
                    //giới hạn việc di chuyển														
                    if (new_leftsub < eleResizeLeft || new_leftsub === eleResizeLeft) {
                        return false;
                    }
                }

                for (var i in val_chart) {
                    if (label_val === val_chart[i].label) {
                        val_chart[i].to = Math.floor((eleResizeLeft + new_width) / scale_x);
                        $('#txn_' + subIDs + '_' + label_val).html(val_chart[i].to); //gán giá trị cho số nằm trên khối
                        break;
                    }
                }
                $('#' + subID).css("left", new_leftsub + "px"); // cập nhập giao diện	canh trái cho thanh kéo					
                $('#' + eleResizeID).css("width", new_width + "px"); // cập nhập giao diện độ rộng cho khối
                $('#' + eleResizenumberID).css("width", new_width + "px"); // cập nhập giao diện độ rộng cho thẻ chứa số trên khối
            }
        }).on('mouseup mouseleave', function (e) {
            // stop resizing khi buông chuột
            if (isResizing) {
                isResizing = false;
                $(".tick_x_h").remove();
                var tick_x_h = '<div class="tick_x_h"></div>';
                //ve lai duong row phu
                for (var i in val_chart) {
                    var label = val_chart[i].label;
                    var bottom = map_y[label] - half_width_label;
                    var start = val_chart[i].from * scale_x;
                    var width = (val_chart[i].to - val_chart[i].from) * scale_x;
                    //đường phụ trục dài trục x theo label					
                    var tmp_tick_x_h1 = $(tick_x_h).css({"left": start + "px", "height": bottom + "px"});
                    var starts = start + width;
                    var tmp_tick_x_h2 = $(tick_x_h).css({"left": starts + "px", "height": bottom + "px"});
                    $('#mychart').append(tmp_tick_x_h1).append(tmp_tick_x_h2);
                    //set gia tri cho ô cot from or to
                    if (label_val === val_chart[i].label) {
                        if (move_x_tmp > 0) {
                            if (subIDs === 'left') {
                                fill_grade_from(label_val, val_chart[i].from, 'chartmove');
                            } else {
                                fill_grade_to(label_val, val_chart[i].to, 1);
                            }
                            loadchartScatter(false, label_val.toLowerCase());
                        }
                    }
                }
                //ve lai duong row chính
                for (var i in axis_x) {
                    var distance = (parseInt(i) + 1) * segment_x;
                    //ve duong keo dai của trục x
                    //lay chieu cao lon nhat trong mang cac label
                    var height_max = 0;
                    for (var i in val_chart) {
                        var label = val_chart[i].label;
                        var heights = map_y[label] - half_width_label;
                        var start = val_chart[i].from * scale_x;
                        var width = (val_chart[i].to - val_chart[i].from) * scale_x;
                        if (height_max < heights && distance > start && distance < (start + width)) {                             //lay do cao lớn nhất mà có khối label nằm trong khoảng này (không xét trường hợp = vì trường hợp = đã vẽ đường cho từng khối riêng bên dưới)
                            height_max = heights;
                        }
                    }
                    var tmp_tick_x_h = $(tick_x_h).css({"left": distance + "px", "height": height_max + "px"});
                    $('#mychart').append(tmp_tick_x_h);
                }
                console.log('gọi loadchart trong loadchart');
                loadchart();
                ui_update_surface2();
                reorganize_scoreDetail();
                processDataLearn('28062018104031');
            }
        });
    }
    function chartScatter(max_y_chart) {
        Chart.plugins.register({
            afterDatasetsDraw: function (chart, easing) {
                // To only draw at the end of animation, check for easing === 1
                var ctx = chart.ctx;
                chart.data.datasets.forEach(function (dataset, i) {
                    var meta = chart.getDatasetMeta(i);
                    if (!meta.hidden) {
                        meta.data.forEach(function (element, index) {
                            // Draw the text in black, with the specified font
                            ctx.fillStyle = 'rgb(0, 0, 0)';
                            var fontSize = 15;
                            var fontStyle = 'normal';
                            var fontFamily = 'Helvetica Neue';
                            ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);
                            // Make sure alignment settings are correct
                            ctx.textAlign = 'center';
                            ctx.textBaseline = 'middle';
                            var padding = 5;
                            var position = element.tooltipPosition();
                            ctx.fillText(dataset.data[index].y, position.x, position.y - (fontSize / 2) - padding);
                        });
                    }
                });
            }
        });
        Chart.pluginService.register({
            beforeRender: function (chart) {
                if (chart.config.options.showAllTooltips) {
                    // create an array of tooltips
                    // we can't use the chart tooltip because there is only one tooltip per chart
                    chart.pluginTooltips = [];
                    chart.config.data.datasets.forEach(function (dataset, i) {
                        chart.getDatasetMeta(i).data.forEach(function (sector, j) {
                            chart.pluginTooltips.push(new Chart.Tooltip({
                                _chart: chart.chart,
                                _chartInstance: chart,
                                _data: chart.data,
                                _options: chart.options.tooltips,
                                _active: [sector]
                            }, chart));
                        });
                    });
                    // turn off normal tooltips
                    chart.options.tooltips.enabled = false;
                }
            },
            afterDraw: function (chart, easing) {
                if (chart.config.options.showAllTooltips) {
                    // we don't want the permanent tooltips to animate, so don't do anything till the animation runs atleast once
                    if (!chart.allTooltipsOnce) {
                        if (easing !== 1)
                            return;
                        chart.allTooltipsOnce = true;
                    }

                    // turn on tooltips
                    chart.options.tooltips.enabled = true;
                    Chart.helpers.each(chart.pluginTooltips, function (tooltip) {
                        tooltip.initialize();
                        tooltip.update();
                        // we don't actually need this since we are not animating tooltips
                        tooltip.pivot();
                        tooltip.transition(easing).draw();
                    });
                    chart.options.tooltips.enabled = false;
                }
            }
        });
        var config = {
            type: 'line',
            data: {
                // labels: ["", "1000", "2000", "3000", "4000", "5000", "6000", "7000", "8000"],
                datasets: [{
                        label: 'Grade A',
                        fill: false,
                        lineTension: 0,
                        backgroundColor: window.chartColors.colora,
                        borderColor: window.chartColors.colora,
                        borderWidth: 2,
                        pointRadius: 2,
                        pointHoverRadius: 3,
                        data: chart_scatter.A
                    }, {
                        label: 'Grade B',
                        fill: false,
                        lineTension: 0,
                        backgroundColor: window.chartColors.colorb,
                        borderColor: window.chartColors.colorb,
                        borderWidth: 2,
                        pointRadius: 2,
                        pointHoverRadius: 3,
                        data: chart_scatter.B
                    }, {
                        label: 'Grade C',
                        fill: false,
                        lineTension: 0,
                        backgroundColor: window.chartColors.colorc,
                        borderColor: window.chartColors.colorc,
                        borderWidth: 2,
                        pointRadius: 2,
                        pointHoverRadius: 3,
                        data: chart_scatter.C
                    }, {
                        label: 'Grade D',
                        fill: false,
                        lineTension: 0,
                        backgroundColor: window.chartColors.colord,
                        borderColor: window.chartColors.colord,
                        borderWidth: 2,
                        pointRadius: 2,
                        pointHoverRadius: 3,
                        data: chart_scatter.D
                    }, {
                        label: 'Grade E',
                        fill: false,
                        lineTension: 0,
                        backgroundColor: window.chartColors.colore,
                        borderColor: window.chartColors.colore,
                        borderWidth: 2,
                        pointRadius: 2,
                        pointHoverRadius: 3,
                        data: chart_scatter.E
                    }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                // showAllTooltips: true,
                onAnimationComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = this.scale.font;
                    ctx.fillStyle = this.scale.textColor;
                    ctx.textAlign = "center";
                    ctx.textBaseline = "bottom";
                    this.datasets.forEach(function (dataset) {
                        dataset.bars.forEach(function (bar) {
                            ctx.fillText(JSON.stringift(bar));
                        });
                    });
                },
                legend: {
                    fontSize: 10,
                    display: false,
                    itemWidth: 150,
                    position: 'bottom',
                    fullWidth: false,
                    labels: {
                        fontColor: '#1d1d1d',
                        boxWidth: 20,
                        padding: 15
                    }
                },
                scales: {
                    xAxes: [{
                            type: 'linear',
                            ticks: {
                                beginAtZero: false,
                                min: 0,
                                max: 8000,
                                fontColor: "#1d1d1d",
                                fontSize: 13,
                                fontStyle: "bold",
                                padding: 15
                            },
                            pointLabels: {
                                fontColor: "#1d1d1d",
                                fontSize: 13,
                                fontStyle: "bold"
                            },
                            gridLines: {
                                color: "#e3e3e3",
                                lineWidth: 1,
                                tickMarkLength: -7,
                                drawOnChartArea: false,
                                zeroLineColor: 'transparent'
                            }
                        }],
                    yAxes: [{
                            type: 'linear',
                            ticks: {
                                beginAtZero: true,
                                min: 0,
                                max: max_y_chart,
                                stepSize: 5, //khoang cach tung gach
                                fontColor: "#1d1d1d",
                                fontSize: 13,
                                fontStyle: "bold",
                                zeroLineColor: 'transparent',
                                callback: function (value, index) {
                                    if (value !== 0) {

                                    } else {
                                        value = '';
                                    }
                                    return value;
                                },
                                padding: 10
                            },
                            pointLabels: {
                                fontColor: "#1d1d1d",
                                fontSize: 13,
                                fontWeight: 600
                            },
                            gridLines: {
                                //display: false,
                                color: "#e3e3e3",
                                lineWidth: 1,
                                tickMarkLength: 0,
                                //zeroLineColor: '#727272',
                            }
                        }]
                }
            }
        };
        $("canvas#canvas").remove();
        $("#chart2").append('<canvas id="canvas"></canvas>');
        var ctx = document.getElementById('canvas'); //.getContext('2d');
        ctx.height = 423;
        window.myLine = new Chart(ctx, config);
    }
    // dòng default lúc add more	
    function defaultrow(lowername_surface) {
        var htmlrow = '';
        htmlrow += '<td style="text-align:center" class="index' + lowername_surface + '">1</td>';
        for (var keys in arr_d) {
            //"max_chips":0,"maxsize_chips":0,
            var valmax = 0;
            var valmaxsize = 0;
            htmlrow += '<td style="text-align:center">';
            htmlrow += '<input style="width:100%;text-align:center" class="form-control input-sm diin maxs max_' + keys + '" label = "max_' + keys + '" value="' + valmax + '" autocomplete="off" min="0" max="100" type="number">';
            htmlrow += '</td>';
            htmlrow += '<td style="text-align:center">';
            htmlrow += '<input style="width:100%;text-align:center" class="form-control input-sm diin maxsizes maxsize_' + keys + '_' + lowername_surface + ' maxsize_' + keys + '" label = "maxsize_' + keys + '" value="' + valmaxsize + '" autocomplete="off" step="0.1" min="0" max="200" type="number">';
            htmlrow += '</td>';
        }
        ;
        htmlrow += '<td style="text-align:center">';
        htmlrow += '<a class="btn_delete_constraints various fancybox disabled"href=""><img class="delete_constraints" ids="' + lowername_surface + '" src="/web/img/delete_constraints.png" style="height:13px;weight:13px;" alt="delete"></a>';
        htmlrow += '</td>';
        //htmlsettings+=			'</tr>';
        return htmlrow;
    }
    function addmore_tr(keytr, ids) {
        var htmlrow = defaultrow(ids);
        $("#tbody_" + ids).append("<tr class='" + keytr + " " + ids + "end'>" + htmlrow + "</tr>");
        //gan so thu tu
        var index = 1;
        $(".addmore" + ids).each(function (e) {
            $(".index" + ids).eq(e).html(index);
            index++;
        });
    }
    // load chi tiết thông tin của 1 máy cụ thể
    function loadInfo(machine) {//search profile
        console.log('Gọi hàm loadInfo');
        loadingForm(true);
        $.ajax({
            type: 'POST',
            url: "search",
            data: {machine: machine}}).done(function (r) {
            loadingForm(false);
            var data = JSON.parse(r);
            // hiển thị danh sách profile, profile running của máy này
            var arr = data.option;
            var option = '';
            if (arr !== '') {
                for (var pid in arr) {
                    option += '<option value="' + pid + '">' + arr[pid] + '</option>';
                }
            }
            $('#profile').html(option).multipleSelect('refresh').multipleSelect('uncheckAll');
            $('#profile_running').html(option_none + option).multipleSelect('refresh').multipleSelect('uncheckAll');
            // load chi tiết profile running
            if (data.profile_running !== '' && data.profile_running != 0) {
                console.log('loadInfo oad profile running');
                $('#profile_running').multipleSelect('setSelects', [data.profile_running]);
                objrun = data.run_functional_tests;
                ui_update_all(objrun);
            } else {
                console.log('loadInfo load giao diện mặc định');
                var objsx = default_data();
                ui_update_all(objsx);
            }
            filter_button();
            check_check_all();
        }).fail(function (x) {
            loadingForm(false);
        });
    }
    // Hàm tìm profile theo sn
    function search_profile(stationid, showMsg) {
        loadingForm(true);
        $.ajax({
            type: "POST",
            url: 'search-profile',
            data: {
                stationIDs: stationid
            }
        }).done(function (r) {
            loadingForm(false);
            if (r === 'empty') {
                $('#profile').html('').multipleSelect('refresh').multipleSelect('uncheckAll');
                $('#profile_running').html(option_none).multipleSelect('refresh').multipleSelect('uncheckAll');
                if (showMsg) {
                    showMessage('Message', 'No matches found!');
                }
                return false;
            }
            var obj = JSON.parse(r);
            if (obj.status === 'success') {
                var arr = obj.option;
                var option = '';
                for (var pid in arr) {
                    option += '<option value="' + pid + '">' + arr[pid] + '</option>';
                }
                $('#profile').html(option).multipleSelect('refresh').multipleSelect('uncheckAll');
                $('#profile_running').html(option_none + option).multipleSelect('refresh').multipleSelect('uncheckAll');
                var objsx = default_data();
                ui_update_all(objsx);
            }
        }).fail(function (x) {
            showMessage('Message', 'Search profile failed!');
            loadingForm(false);
        });
    }
    // Hàm thêm mới profile
    function addProfile(title) {
        console.log('Gọi hàm addProfile để thêm mới profile');
        var elFS = jQuery("#formSearch");
        App.blockUI({target: elFS, iconOnly: false});
        var customserid = $("#user_name").multipleSelect('getSelects');
        var profilename = $("#profilename").val().trim();
        if (profilename === '') {
            showMessage('Message', 'Please enter profile name.');
            return false;
        }
        if (existSpecialCharacter(profilename)) {
            showMessage('Message', 'Profile name contains only letters and numbers.');
            return false;
        }
        var check1 = check_grade_from_to();
        var check2 = check_size();
        if (check1 > 0 || check2 > 0) {
            showMessage('Message', 'Invalid values. Please check again!');
            return false;
        }
        var searchs = getSearch(); //console.log(obj_score);
        getAllScore(); //?tinh lai grade hay ko?
        searchs = searchs.replace(/'/g, '');
        functional_tests = JSON.stringify(obj_score);
        $.ajax({
            type: "POST",
            url: 'add-profile',
            data: {searchs: searchs, profilename: profilename, functional_tests: functional_tests}, success: function (data) {
                loadingForm(false);
                if (data == 1) {
                    showMessage('Message', title + ' successfully.');
                    $("#profilename").val('');
                    find_profile(customserid, true);
                    $.fancybox.close();
                } else if (data == 0) {
                    showMessage('Message', title + ' failed. Profile name exist!');
                } else {
                    showMessage('Message', title + ' failed.');
                }

            },
            error: function () {
                loadingForm(false);
                showMessage('Message', title + ' failed.');
            }
            //$("#profilename").val('');
        });
        return true;
    }
    // Tìm profile theo customer
    function find_profile(customerIDs, showMsg) {
        console.log('Gọi hàm find_profile để tìm profile theo customer');
        loadingForm(true);
        $.ajax({
            type: "POST",
            url: 'find-profile',
            data: {
                customerIDs: customerIDs
            }
        }).done(function (r) {
            loadingForm(false);
            if (r === 'empty') {
                $('#profile').html('').multipleSelect('refresh').multipleSelect('uncheckAll');
                $('#profile_running').html(option_none).multipleSelect('refresh').multipleSelect('uncheckAll');
                console.log(showMsg + 'showMsg find_profile')
                if (showMsg) {
                    showMessage('Message', 'No matches found');
                }
                return false;
            }
            var obj = JSON.parse(r);
            if (obj.status === 'success') {
                var arr = obj.option;
                var option = '';
                for (var pid in arr) {
                    option += '<option value="' + pid + '">' + arr[pid] + '</option>';
                }
                $('#profile').html(option).multipleSelect('refresh').multipleSelect('uncheckAll');
                $('#profile_running').html(option_none + option).multipleSelect('refresh').multipleSelect('uncheckAll');
            }
        }).fail(function (x) {
            showMessage('Message', 'Search profile failed!');
            loadingForm(false);
        });
    }
    // Load profile chi tiết
    function detail_profile(profile_id) {
        console.log('Gọi hàm profile_id để load chi tiết profile');
        var search = getSearch();
        loadingForm(true);
        $.ajax({
            type: "POST",
            url: 'detail-profile',
            data: {
                search: search,
                profile: profile_id
            }
        }).done(function (r) {
            if (r !== '') {
                var obj = JSON.parse(r);
                reset_variable();
                $('#mychart').html('');
                ui_update_all(obj.functional_tests);
            }
            loadingForm(false);
        }).fail(function (x) {
            showMessage('Message', 'Load profile failed');
            loadingForm(false);
        });
    }
    // Hàm kiểm tra có phải là số không
    function isNumeric(s) {
        return !isNaN(s - parseFloat(s));
    }
    /*
     * Hàm delete/remove profile
     */
    function delete_profile(id, name, customerIDs, stationIDs) {
        console.log('Gọi hàm delete_profile để delete/remove profile');
        var msg = 'Are you sure you want to delete profile: ' + name.join(', ') + '?';
        var msg_rs = 'Deleted';
        if (stationIDs.length !== 0) {
            msg = 'Are you sure you want to remove profile: ' + name.join(', ') + '?';
            msg_rs = 'Removed';
        }
        $.msgBox({
            title: 'Message',
            content: msg,
            type: "alert",
            buttons: [{value: "Yes"}, {value: "No"}],
            success: function (result) {
                if (result === 'Yes') {
                    loadingForm(true);
                    $.ajax({
                        type: 'POST',
                        url: "delete-profile",
                        data: {
                            id: id,
                            station_id: stationIDs,
                            customer_id: customerIDs
                        }
                    }).done(function (r) {
                        if (r === "1") {
                            showMessage('Message', msg_rs + ' successfully.');
                            if (stationIDs.length !== 0) { // Nếu station có máy thì load profile của máy đó
                                search_profile(stationIDs, false);
                            } else if (customerIDs.length !== 0) { // Customer có chọn thì load profile của customer
                                find_profile(customerIDs, false);
                            } else {
                                $('#profile').html('').multipleSelect('refresh').multipleSelect('uncheckAll');
                                $('#profile_running').html(option_none).multipleSelect('refresh').multipleSelect('uncheckAll');
                            }
                            var objsx = default_data();
                            ui_update_all(objsx);
                        } else if (r === "2") {
                            showMessage('Message', 'Profile is in use, can not delete.');
                        } else {
                            showMessage('Message', msg_rs + ' error!');
                        }
                        loadingForm(false);
                    }).fail(function (x) {
                        showMessage('Message', msg_rs + ' failed!');
                        loadingForm(false);
                    });
                }
            }
        });
    }
    /*
     * Kiểm tra xem detail có hợp lệ không
     */
    function check_save_detail() {
        console.log('Gọi hàm check_save_detail để kiểm tra detail có hợp lệ không');
        var check = 0;
        $('.maxsizes').each(function (e) {
            var index_td = $(this).closest('td').index();
            var tbody = $(this).closest('tbody');
            var counts = {};
            $('tr', tbody).each(function (k) {
                vals = ($(this).find('td:eq(' + index_td + ') input').val());
                if (parseFloat(vals) !== 0) {
                    if (counts[vals] === undefined) {
                        counts[vals] = 1;
                    } else {
                        counts[vals] = counts[vals] + 1;
                    }
                }
            });
            $('tr', tbody).each(function (k) {
                vals = ($(this).find('td:eq(' + index_td + ') input').val());
                if (counts[vals] !== undefined) {
                    var tmp = parseInt(counts[vals]);
                    if (tmp > 1) {
                        $(this).find('td:eq(' + index_td + ') input').addClass('rederror');
                        check++;
                    }
                }
            });
        });
        return check;
    }
    /*
     * Hàm kiểm tra size có hợp lệ không
     */
    function check_size() {
        console.log('Gọi hàm check_size để kiểm tra size có hợp lệ không');
        var toss = 0;
        var i = 0;
        var check = 0;
        $('.size').each(function (e) {
            $('.from_size').eq(e).removeClass('rederror');
            $('.to_size').eq(e).removeClass('rederror');
            var from_size = parseFloat($('.from_size').eq(e).val());
            var to_size = parseFloat($('.to_size').eq(e).val());
            if (i > 0) {
                if (from_size !== 0 || to_size !== 0) {//1 trong 2 gia tri khac 0 moi bat dau kiem tra
                    if (toss !== from_size) {
                        $('.from_size').eq(e).addClass('rederror');
                        check++;
                    }
                    if (from_size >= to_size) {
                        $('.from_size').eq(e).addClass('rederror');
                        $('.to_size').eq(e).addClass('rederror');
                        check++;
                    }
                }
            } else {
                if (to_size === 0) {
                    $('.to_size').eq(e).addClass('rederror');
                    check++;
                }
            }

            toss = to_size;
            i++;
        });
        return check;
    }
    /*
     * Kiểm tra xem điểm from có nhỏ hơn điểm to ko
     */
    function check_grade_from_to() {
        console.log('Gọi hàm check_grade_from_to để kiểm tra điểm from/to có hợp lệ không');
        var check = 0;
        $("#htmlgrade > tr").each(function (e) {
            //score_from,score_to
            $('.score_from').eq(e).removeClass('rederror');
            $('.score_to').eq(e).removeClass('rederror');
            var score_from = parseInt($('.score_from').eq(e).val());
            var score_to = parseInt($('.score_to').eq(e).val());
            if (score_to > 8000) {
                $('.score_to').eq(e).addClass('rederror');
                check++;
            }
            if (score_from > score_to) {
                $('.score_from').eq(e).addClass('rederror');
                check++;
            }
        });
        return check;
    }
    // Hàm lọc bỏ số 0 đầu tiên trong chuỗi số
    function RemovedZeroInt(vals) {
        if (vals.length > 1) {
            var tmp = vals.slice(0, 1);
            if (parseInt(tmp) === 0) {
                vals = vals.slice(1);
                RemovedZeroInt(vals);
            } else {
                return vals;
            }
        } else {
            return vals;
        }
    }
    /*
     * Hàm tính toán lại trọng số mới của mặt
     */
    function graphToData(data, grade_name_input, change_score, direct) {
        if (!data.hasOwnProperty('datachart')) {
            console.log('NOT FOUND datachart key');
            return false;
        }
        if (!data['datachart'].hasOwnProperty('scoreDetail')) {
            console.log('NOT FOUND scoreDetail key in datachart');
            return false;
        }
        if (jQuery.isEmptyObject(data['datachart']['scoreDetail'])) {
            console.log('scoreDetail IS EMPTY');
            return false;
        }
        init_surface_score(data, grade_name_input);
        console.log('- Score ' + grade_name_input + ': ' + change_score);
        console.log('- Danh sách bề mặt và trọng số');
        console.log(JSON.stringify(obj_multiplier_surface));
        console.log('- Danh sách loại lỗi và trọng số');
        console.log(JSON.stringify(obj_defect_multiplier));
        console.log('- Danh sách loại lỗi và điểm trừ');
        console.log(JSON.stringify(obj_defect_minus));
        console.log('Danh sách kích thước lỗi và trọng số');
        console.log(JSON.stringify(arr_size_multiplier));
        console.log('- Danh sách mảng đã map theo Grade/surface/defect/[size/num/mul]');
        console.log(JSON.stringify(grade_brief));
        console.log('- Danh sách điểm theo mặt');
        console.log(JSON.stringify(obj_surface_score));
        console.log('total_score: ' + total_score);
        var obj_multiplier_surface_old = jQuery.extend({}, obj_multiplier_surface);
        var score_reminder = -1;
        var score_limit = 50;
        var number_loop = 1;
        // Lặp lại tới khi thỏa điều kiện là số điểm lùi dần về giới hạn
        while (change_score > score_limit && change_score !== score_reminder && score_reminder !== 0 && number_loop < 10) {
            if (score_reminder !== -1) {
                change_score = score_reminder;
            }
            ////console.log('*** Lần lặp thứ: ' + number_loop + '-----------------------------------------------------------------------()');
            ////console.log('***** Số điểm truyền vào: ' + change_score);
            score_reminder = 0;
            // Duyệt qua từng bề mặt
            for (var surface_name in grade_brief[grade_name_input]) {
                var defects = grade_brief[grade_name_input][surface_name];
                ////console.log('***** 1. bắt đầu tính điểm mặt: ' + surface_name);
                var score_surface = 0; // Biến chứa tổng điểm của bề mặt
                // Duyệt qua từng loại lỗi của mặt
                if (obj_multiplier_surface[surface_name] === 0 || !obj_surface_score.hasOwnProperty(surface_name)) {
                    continue;
                }
                $.each(defects, function (defect, details) {
                    ////console.log('******** 1.1 lỗi: ' + defect);
                    var score_defect = 0; // Biến chứa tổng điểm của bề mặt
                    // Duyệt qua từng size của lỗi
                    $.each(details, function (index, detail) {
                        // Điểm của lỗi bằng cộng dồn tích của số lượng lỗi và trọng số của size lỗi đó
                        score_defect += detail[1] * detail[2];
                        ////console.log('*********** 1.1.' + index + ' tích (qty*mul) lỗi cộng dồn : ' + score_defect + ' += ' + detail[1] + '*' + detail[2]);
                    });
                    // Điểm của lỗi cuối cùng = tích điểm lỗi và trọng số loại lỗi và trọng số bề mặt                    
                    ////console.log('******** 1.2 tổng điểm của lỗi ' + defect + ' = ' + (score_defect * obj_defect_multiplier[defect] * obj_multiplier_surface[surface_name]) + ' = ' + score_defect + '*' + obj_defect_multiplier[defect] + '*' + obj_multiplier_surface[surface_name]);
                    var score_defect = score_defect * obj_defect_multiplier[defect] * obj_multiplier_surface[surface_name];
                    // Nếu điểm cuối cùng của loại lỗi mà lớn hơn giới hạn thì gán lại bằng điểm giới hạn
                    if (score_defect > obj_defect_minus[defect]) {
                        // Tạm thời tắt hàm này đi.
                        // score_defect = obj_defect_minus[defect];
                    }
                    ////console.log('******** 1.3 tổng điểm của lỗi sau khi so với max minus ' + defect + ' = ' + score_defect + ' điểm max = ' + obj_defect_minus[defect]);
                    // Cộng dồn điểm của loại lỗi vào điểm của bề mặt
                    score_surface += score_defect;
                });
                ////console.log('***** 2. Điểm hiện tại của mặt ' + surface_name + ' = ' + score_surface); // 500
                // Hằng số điểm là
                var const_score = score_surface / obj_multiplier_surface[surface_name];
                ////console.log('***** 3. Hằng số theo bề mặt ' + const_score + ' = ' + score_surface + ' : ' + obj_multiplier_surface[surface_name]); // 500
                // Tính số điểm của mặt có được khi thay đổi
                var tmp_score = change_score * (obj_surface_score[surface_name] / total_score); // 700
                ////console.log('***** 4. Điểm thay đổi của mặt ' + surface_name + ' = ' + tmp_score + '=' + change_score + "*(" + obj_surface_score[surface_name] + "/" + total_score + ")");
                if (direct === 'up') {
                    // Nếu điểm tạm lớn hơn điểm hiện tại
                    if (tmp_score > score_surface) {
                        ////console.log('******** 4.1 Điểm thay đổi lớn hơn điểm hiện tại ' + tmp_score + ' > ' + score_surface);
                        // điểm dư sẽ bằng hiệu điểm tạm với điểm hiện tại -1 ex: (201 = 700 - (500-1))
                        score_reminder += tmp_score - (score_surface - 1);
                        // điểm tạm mới dùng để tính là giảm 1 đơn vị so với hiện tại ex: (500-1)
                        tmp_score = score_surface - 1;
                        ////console.log('******** 4.2 Gán lại điểm tạm = ' + tmp_score + ' điểm dư = ' + score_reminder);
                    }
                    // Tính toán trọng số mới
                    ////console.log('******** 4.n Tính lại hệ số với công thức  ' + obj_multiplier_surface[surface_name] + ' - ' + '(' + tmp_score + '/ ' + const_score + ')');
                    obj_multiplier_surface[surface_name] = obj_multiplier_surface[surface_name] - (tmp_score / const_score);
                } else {
                    // Tính toán trọng số mới
                    obj_multiplier_surface[surface_name] = obj_multiplier_surface[surface_name] + (tmp_score / const_score);
                }
                ////console.log('***** 5. Hệ số mới của mặt ' + surface_name + ' = ' + obj_multiplier_surface[surface_name] + '(' + obj_multiplier_surface_old[surface_name] + ')');
                ////console.log('');
            }
            number_loop++; // số lần lặp, mục đích để dừng vòng lặp khi rơi vào vô tận
            ////console.log('***** 6. điểm còn dư: ' + score_reminder);
            ////console.log('');
        }
        for (var k in obj_multiplier_surface) {
            obj_multiplier_surface[k] = Math.round(obj_multiplier_surface[k] * 100) / 100;
        }
        console.log('======================== KQ cuối cùng, trọng số mới ========================');
        console.log(obj_multiplier_surface);
        // Cập nhập lại trọng số cho từng mặt
        for (var i in data['surface']) {
            if (data['surface'][i].hasOwnProperty('name') && data['surface'][i].hasOwnProperty('multiplier')) {
                var sfn = data['surface'][i]['name'].toLowerCase();
                if (obj_multiplier_surface.hasOwnProperty(sfn)) {
                    data['surface'][i]['multiplier'] = obj_multiplier_surface[sfn];
                }
            }
        }
        // Tính toán lại điểm của các grade
        calculate_score(data, grade_name_input);
        ////console.log(obj_grade_score);
        // Sắp xếp lại scoreDetail
        reorganize_scoreDetail();
    }
    /*
     * Những function dùng chung, phổ biến
     */
    function change_customer() {
        $.filterbox.filter_children('#user_name', '#location_id', infoCusLoc);
        $.filterbox.filter_children('#location_id', '#stationid', infoLocMac);
        filter_button();
    }
    function change_location() {
        $.filterbox.checked_parent('#location_id', '#user_name', infoCusLoc);
        $.filterbox.filter_children('#location_id', '#stationid', infoLocMac);
    }
    function change_machine() {
        $.filterbox.checked_parent('#stationid', '#location_id', infoLocMac);
        $.filterbox.checked_parent('#location_id', '#user_name', infoCusLoc);
        filter_button();
    }
    function showMessage(title, content) {
        $.msgBox({
            title: title,
            content: content,
            type: "alert",
            buttons: [{value: "OK"}],
            success: function (result) {
            }
        });
    }
    function getSearch() {
        var customer = $("#user_name").multipleSelect('getSelects');
        if (typeof customer === 'object') {
            customer = '';
        }
        var locationid = $("#location_id").multipleSelect('getSelects');
        if (typeof locationid === 'object') {
            locationid = '';
        }
        var machine = $("#stationid").multipleSelect('getSelects');
        if (typeof machine === 'object') {
            machine = '';
        }
        var search = {
            'customer': customer,
            'locationid': locationid,
            'machine': machine
        };
        var searchs = JSON.stringify(search);
        return searchs;
    }
    function loadingForm(s) {
        var el = jQuery("#" + gridView);
        var elFS = jQuery("#" + formView);
        var elDT = jQuery("#" + formData);
        if (s === true) {
            App.blockUI({target: el, iconOnly: true});
            App.blockUI({target: elFS, iconOnly: false});
            App.blockUI({target: elDT, iconOnly: false});
        } else {
            App.unblockUI($('.ccontent'));
            App.initAjax();
            App.unblockUI(el);
            App.unblockUI(elFS);
            App.unblockUI(elDT);
        }
    }
    function reset_variable() {
        val_chart = [
            {'label': 'A', 'from': 0, 'to': 0},
            {'label': 'B', 'from': 0, 'to': 0},
            {'label': 'C', 'from': 0, 'to': 0},
            {'label': 'D', 'from': 0, 'to': 0},
            {'label': 'E', 'from': 0, 'to': 0}
        ];
        obj_score = {};
        obj_multiplier_surface = {};
        obj_defect_multiplier = {};
        obj_defect_minus = {};
        arr_size_multiplier = [];
        grade_brief = {};
        obj_surface_score = {};
        total_score = 0;
        obj_grade_score = {};
    }
    function myReset() {
        reset_variable();
        load_ui();
        // reset multiselect box
        if (isAdmin === '0') {
            $("#user_name").multipleSelect('setSelects', [customerID]);
            change_customer();
            $('#location_id').multipleSelect('uncheckAll');
            $('#stationid').multipleSelect('uncheckAll');
        } else {
            $('#user_name').multipleSelect('uncheckAll');
            change_customer();
        }
        //reset profile
        if (isAdmin === '0') {
            find_profile(customerID);
        } else {
            var option = '';
            $('#profile').html(option).multipleSelect('refresh').multipleSelect('uncheckAll');
            $('#profile_running').html(option_none + option).multipleSelect('refresh').multipleSelect('uncheckAll');
        }
        // reset value class search
        $(".search").each(function () {
            var tag = $(this).prop("tagName");
            if (tag === 'INPUT') {
                $(this).val('');
            }
        });
        searchCookie = '';
        // reset button
        filter_button();
    }
    // check all of functionn test settings
    function check_check_all() {
        if ($('input.iafts:checked').length === $('input.iafts').length) {
            $('#ckalfts').prop('checked', true);
        } else {
            $('#ckalfts').prop('checked', false);
        }
    }
    // Chuyển chữ cái đầu thành chữ hoa
    function jsUcfirst(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    // Hàm giới hạn việc nhập textbox chỉ là số
    function only_number(selector, sn) {
        var temp = 0;
        $(document).on("keydown", selector, function (e) {
            if (sn === true) {
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 || (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
                    return;
                }
            } else {
                if ((e.keyCode == 188 || e.keyCode == 190) && temp == e.keyCode) {
                    e.preventDefault();
                }
                temp = e.keyCode;
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190, 188]) !== -1 || (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
                    return;
                }
            }
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                e.preventDefault();
            }
        });
    }
    // Hiện/ẩn các button theo điều kiện giao diện
    function filter_button() {
        var customer = $("#user_name").multipleSelect('getSelects');
        var station = $("#stationid").multipleSelect('getSelects');
        var profile_list = $('#profile').multipleSelect('getSelects');
        var profile_running = $('#profile_running').multipleSelect('getSelects');
        if (typeof customer === 'object') {
            $('#addprofile').addClass('disabled').css('background-image', 'url(/web/img/add_disable_v1.png)');
        } else {
            $('#addprofile').removeClass('disabled').css('background-image', 'url(/web/img/add_v1.png)');
        }
        if (typeof profile_list !== 'object') {
            $('#delete').removeClass('disabled').css('background-image', 'url(/web/img/delete_v1.png)');
            if (click_search_profile) {
                $('#updateprofile').removeClass('disabled').css('background-image', 'url(/web/img/update_v1.png)');
            } else {
                $('#updateprofile').addClass('disabled').css('background-image', 'url(/web/img/update_disable_v1.png)');
            }
        } else {
            $('#updateprofile').addClass('disabled').css('background-image', 'url(/web/img/update_disable_v1.png)');
            $('#delete').addClass('disabled').css('background-image', 'url(/web/img/delete_disable_v1.png)');
        }
        if (typeof station === 'object') {
            $('#syncprofile').addClass('disabled').css('background-image', 'url(/web/img/save_disable_v1.png)');
        } else if (typeof profile_list !== 'object' || typeof profile_running !== 'object') {
            $('#syncprofile').removeClass('disabled').css('background-image', 'url(/web/img/save_v1.png)');
        } else {
            $('#syncprofile').addClass('disabled').css('background-image', 'url(/web/img/save_disable_v1.png)');
        }
    }
    // Kiểm tra xem chuỗi có chứa ký tự đặc biệt không
    function existSpecialCharacter(string) {
        var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        if (format.test(string)) {
            return true;
        } else {
            return false;
        }
    }
    /* Huy khai báo 1 số hàm hỗ trợ việc tính toán chart */
    // Lấy dữ liệu bề mặt và trọng số
    // Dữ liệu trả về ex: {"front":10,"top":3,"bottom":3,"left":3,"right":3,"back":3}
    function init_multiplier_surface(data) {
        if (data.hasOwnProperty('surface')) {
            for (var i in data['surface']) {
                if (data['surface'][i].hasOwnProperty('name') && data['surface'][i].hasOwnProperty('multiplier')) {
                    obj_multiplier_surface[data['surface'][i]['name'].toLowerCase()] = parseFloat(data['surface'][i]['multiplier']);
                }
            }
        }
    }
    // Lấy dữ liệu loại lỗi và trọng số, dữ liệu loại lỗi và max điểm trừ
    // obj_defect_multiplier ex: {"scratches":1,"chips":2,"cracks":4,"dents":5,"discoloration":6,"peeling":7}
    // obj_defect_minus ex: {"scratches":5000,"chips":1000,"cracks":1000,"dents":1000,"discoloration":1000,"peeling":1000}
    function init_defect_surface(data) {
        if (data.hasOwnProperty('defect')) {
            if (data['defect'].hasOwnProperty('defect_type_1')) {
                var defect_type_1 = data['defect']['defect_type_1'];
                for (var i in defect_type_1) {
                    if (defect_type_1[i].hasOwnProperty('name') && defect_type_1[i].hasOwnProperty('multiplier')) {
                        var defect_name = defect_type_1[i]['name'].toLowerCase();
                        if (defect_name.indexOf('dent') !== -1) {
                            defect_name = 'dents';
                        } else if (defect_name.indexOf('peeling') !== -1) {
                            defect_name = 'peeling';
                        }
                        obj_defect_multiplier[defect_name] = parseFloat(defect_type_1[i]['multiplier']);
                        obj_defect_minus[defect_name] = parseFloat(defect_type_1[i]['max_unlimited']);
                    }
                }
            }
        }
    }
    // Lấy dữ liệu về trọng số theo size lỗi
    // Ex; [{"from":0,"to":1,"multiplier":1},{"from":1,"to":2,"multiplier":5},{"from":2,"to":3,"multiplier":8},{"from":3,"to":4,"multiplier":10},{"from":4,"to":5,"multiplier":14},{"from":5,"to":6,"multiplier":18},{"from":6,"to":7,"multiplier":25},{"from":7,"to":10,"multiplier":30}]
    function init_size_multiplier(data) {
        if (data.hasOwnProperty('size')) {
            var tmp = {};
            for (var size in data['size']) {
                tmp = {'from': parseFloat(data['size'][size]['from']), 'to': parseFloat(data['size'][size]['to']), 'multiplier': parseFloat(data['size'][size]['multiplier'])}
                arr_size_multiplier.push(tmp);
            }
        }
    }
    // Khởi tạo tóm tắt lại grade/surface/defect ex: {"a":{"front":{"scratches":[[1,10,1],[2,6,5],[3,4,8],[4,2,10],[5,1,14]]},"back"......
    function init_grade_brief(data, grade_name_input) {
        if (data.hasOwnProperty('grade')) {
            for (var i in data['grade']) {
                var grade_i = data['grade'][i];
                var grade_name = grade_i['name_grade'].toLowerCase();
                // if (grade_name === grade_name_input) {
                var grade_i_setting = grade_i['settings'];
                grade_brief[grade_name] = {};
                for (var j in grade_i_setting) {
                    var surface_j = grade_i_setting[j];
                    var name_surface_j = grade_i_setting[j]['name_surface'].toLowerCase();
                    var tmp = {};
                    for (var i_ld in surface_j['list_defect']) {
                        var list_defect_i = surface_j['list_defect'][i_ld];
                        for (var key in obj_defect_multiplier) {
                            var quantity = 'max_' + key;
                            if (list_defect_i.hasOwnProperty(quantity)) {
                                var mutiplier = 0;
                                var size_defect = parseFloat(list_defect_i['maxsize_' + key]);
                                for (var size_i in arr_size_multiplier) {
                                    if (size_defect > arr_size_multiplier[size_i]['from'] && size_defect <= arr_size_multiplier[size_i]['to']) {
                                        mutiplier = arr_size_multiplier[size_i]['multiplier'];
                                        break;
                                    }
                                }
                                // Chỉ lấy những lỗi có size và trọng số
                                if (parseFloat(size_defect) !== 0 && parseFloat(mutiplier) !== 0) {
                                    if (typeof tmp[key] === 'undefined') {
                                        tmp[key] = [];
                                    }
                                    tmp[key].push([size_defect, list_defect_i[quantity], mutiplier]);
                                }
                            }
                        }
                    }
                    // Chỉ lấy những mặt có lỗi
                    if (!jQuery.isEmptyObject(tmp)) {
                        grade_brief[grade_name][name_surface_j] = tmp;
                    }
                }
                // }
            }
        }
    }
    // Tính điểm theo mặt dựa vào dữ liệu trong key datachart ex: {"front":400,"back":650,"top":900,"bottom":300,"left":600,"right":900}
    function init_surface_score(data, grade_name_input) {
        $.each(data['datachart']['scoreDetail'][grade_name_input.toUpperCase()], function (index, details) {
            $.each(grade_brief[grade_name_input], function (surface_name, defects) {
                var fkey = 'score' + jsUcfirst(surface_name);
                if (details.hasOwnProperty(fkey)) {
                    if (!obj_surface_score.hasOwnProperty(surface_name)) {
                        obj_surface_score[surface_name] = 0;
                    }
                    obj_surface_score[surface_name] += details[fkey];
                    total_score += details[fkey];
                }
            });
        });
    }
    // Sắp xếp lại item trong scoreDetail trong datachart
    function reorganize_scoreDetail() {
        // return false;
        var scoreDetailTmp = {}; // chứa các phần tử được sắp xếp lại
        var scoreBackup = jQuery.extend({}, obj_score['datachart']['scoreDetail']);// chứa các phần tử còn lại sau remove
        // Duyệt qua từng item của scoreDetail
        //console.log(obj_score['datachart']['scoreDetail']);
        $.each(obj_score['datachart']['scoreDetail'], function (grade_name, details) {
            var grade_name_to_lower = grade_name.toLowerCase();
            if (typeof details === 'undefined') {
                //console.log('grade_name ' + grade_name + ' details: ' + details);
                return true;
            }
            $.each(details, function (index, score) {
                //console.log(score);
                var scoreTotal = parseFloat(score['scoreTotal']);
                $.each(obj_grade_score, function (grade_name_lower, arr_score) {
                    // nếu điểm thỏa 1 khoảng nào đó và khoảng đó khác grade hiện tại của điểm
                    if (scoreTotal >= arr_score[0] && scoreTotal <= arr_score[1] && grade_name_to_lower !== grade_name_lower) {
                        if (!scoreDetailTmp.hasOwnProperty(grade_name_lower.toUpperCase())) {
                            scoreDetailTmp[grade_name_lower.toUpperCase()] = [];
                        }
                        scoreDetailTmp[grade_name_lower.toUpperCase()].push(score); // đưa phần tử vào mảng tạm
                        delete scoreBackup[grade_name][index]; // remove phần tử khỏi mảng backup
                        return false;
                    }
                });
            });
        });
        // Duyệt qua mảng backup
        var scoreDetail = {};
        $.each(scoreBackup, function (grade_name_upper, score) {
            if (!scoreDetail.hasOwnProperty(grade_name_upper)) {
                scoreDetail[grade_name_upper] = [];
            }
            $.each(score, function (index, item) {
                if (typeof item !== 'undefined') {
                    scoreDetail[grade_name_upper].push(item);
                }
            });
            // Duyệt qua mảng chứa phần tử sắp xếp lại
            if (scoreDetailTmp.hasOwnProperty(grade_name_upper)) {
                $.each(scoreDetailTmp[grade_name_upper], function (index, item) {
                    scoreDetail[grade_name_upper].push(item);
                });
            }
        });
        // Cập nhập lại vào scoreDetail
        obj_score['datachart']['scoreDetail'] = scoreDetail;
    }
    // Tính toán lại số điểm của mặt theo trọng số mới
    function calculate_score(data, grade_name_input) {
        var multiplier_score_defects = get_multiplier_score_defects('bent', 'lci', 'lift');
        $.each(data['grade'], function (index_grade, obj_grade) {
            var grade_name = obj_grade['name_grade'].toLowerCase();
            if (grade_name_input === grade_name) {
                //obj_grade_score[grade_name] = [obj_grade['score_from'], obj_grade['score_to']];
                //return true;
            }
            obj_grade_score[grade_name] = [obj_grade['score_from'], obj_grade['score_to']];
            var settings = obj_grade['settings'];
            var sum1 = 0;
            for (var index_setting in settings) {
                var setting = settings[index_setting];
                var surface_name = setting['name_surface'].toLowerCase();
                var defects = grade_brief[grade_name][surface_name];
                var score_surface = 0; // Biến chứa tổng điểm của từng mặt
                // Duyệt qua từng loại lỗi của mặt
                if (obj_multiplier_surface[surface_name] === 0 || !obj_surface_score.hasOwnProperty(surface_name)) {
                    continue;
                }
                $.each(defects, function (defect, details) {
                    var score_defect = 0; // Biến chứa tổng điểm của bề mặt                       
                    $.each(details, function (index_defect, detail) {
                        score_defect += detail[1] * detail[2]; // Điểm của lỗi bằng cộng dồn tích của số lượng lỗi và trọng số của size lỗi đó
                    });
                    var score_defect = score_defect * obj_defect_multiplier[defect] * obj_multiplier_surface[surface_name];
                    if (score_defect > obj_defect_minus[defect]) {// Nếu điểm cuối cùng của loại lỗi mà lớn hơn giới hạn thì gán lại bằng điểm giới hạn
                        score_defect = obj_defect_minus[defect];
                    }
                    // Cộng dồn điểm của loại lỗi vào điểm của bề mặt
                    score_surface += score_defect;
                });
                sum1 += score_surface;
            }
            var bent = obj_grade['bent'];
            var lci = obj_grade['lci'];
            var lift = obj_grade['lift'];
            var sum2 = 0;
            if (!bent) {
                sum2 += parseFloat(multiplier_score_defects[0]);
            }
            if (!lci) {
                sum2 += parseFloat(multiplier_score_defects[1]);
            }
            if (!lift) {
                sum2 += parseFloat(multiplier_score_defects[2]);
            }
            var sum = sum1 + sum2;
            if (sum > 0) {
                var score = Math.round(8000 - sum);
                if (score > parseInt(obj_grade['score_to'])) {
                    score = parseInt(obj_grade['score_to']) - 10;
                }
                console.log(obj_grade['score_from'] + ' <> ' + score);
                obj_grade['score_from'] = score;
                obj_grade_score[grade_name] = [score, obj_grade['score_to']];
            }
        });
    }
</script>

<?php $view['slots']->stop() ?>
<!-- CSS can them vao -->
<?php $view['slots']->start('css') ?>


<link rel="stylesheet" type="text/css" href="/web/admin/assets/css/plugins.css"/>
<link rel="stylesheet" type="text/css" href="/web/admin/assets/plugins/uniform/css/uniform.default.css"/>
<link rel="stylesheet" type="text/css" href="/web/admin/assets/plugins/multipleselect/multiple-select.css"/>
<link rel="stylesheet" type="text/css" href="/web/admin/css/jquery-ui-1.8.22.custom.css"/>
<link rel="stylesheet" type="text/css" href="/web/admin/assets/css/style-metronic.css" />
<link rel="stylesheet" type="text/css" href="/web/admin/css/chart_ivaluategen3.css" />
<style>
    .multiple {
        width: auto;
        min-width: 100%;
    }
    .ms-drop input[type="checkbox"] {
        vertical-align: top;
    }

    .ms-parent {
        background: #fff;
        color: #000;
    }
    ::-webkit-input-placeholder {
        font-style: italic;
    }

    :-moz-placeholder { /* Firefox 18- */
        font-style: italic;
    }

    ::-moz-placeholder {  /* Firefox 19+ */
        font-style: italic;
    }

    :-ms-input-placeholder {
        font-style: italic;
    }

    .diin{
        display: inline;
        width: 70px;
        height: 26px;
        padding: 2px;
    }   

    /* fieldset */
    .fieldset_l2 {
        padding-top: 0px !important;
        padding-left: 15px !important;
        padding-right: 15px !important;
        padding-bottom: 15px !important;
        margin-top: -15px !important;
    }
    .fieldset_l2>legend>h4>b {
        font-size: 17px;
        padding-left: 10px;
        padding-right: 10px;
    }
    .fieldset_l2 .form-group {
        margin-bottom: 0 !important;
    }	


    .btn.blues{
        background-color:#006ead!important;
    }
    .popup {
        background-color:#F9F9F9
    }
    .popup .row {
        margin-left: -15px!important;
        margin-right: -15px!important;
    }
    .control-label{
        text-align:left!important;
    }
    .closes{
        background-image: url("/web/final/img/portlet-remove-icon.png")!important;
    }
    .btn_func {
        display: inline-block;
        height: 35px;
        margin-left: 10px;
        width: 35px;
    }
    #mychart {
        -webkit-user-select: none !important; /* Safari 3.1+ */
        -moz-user-select: none !important; /* Firefox 2+ */
        -ms-user-select: none !important; /* IE 10+ */
        user-select: none !important; /* Standard syntax */
    }
    #mychart div{
        -webkit-user-select: none !important; /* Safari 3.1+ */
        -moz-user-select: none !important; /* Firefox 2+ */
        -ms-user-select: none !important; /* IE 10+ */
        user-select: none !important; /* Standard syntax */
    }
</style>
<?php $view['slots']->stop() ?>
<div id="dialog"></div>
<div class="row">
    <div class="col-md-12">
        <div class="portlet box blue ">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-reorder"></i> Search
                </div>
                <div class="tools">
                    <a href="" class="collapse"></a>
                </div>
            </div>
            <div class="portlet-body form" style="padding-bottom: 0px !important;">
                <form style="margin-bottom: 0" id="formSearch" action="<?php echo $view['router']->generate('gcs_admin_machine'); ?>" method="POST" class="form-horizontal" role='form'>
                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-4 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Customer</label>
                                    <div class="col-md-8">
                                        <select msgchooseone="Please choose one customer" optslClick="change_customer" optslCheckAllForSearch="true"  placeholder="-- All customers --" optsl="multiple" class="form-control2 search" name="user_name" id="user_name" >
                                            <?php foreach ($customerList as $item): ?>
                                                <option value="<?php echo $item['customer_id'] ?>"><?php echo $item['customer_name'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Location</label>
                                    <div class="col-md-8">
                                        <select msgchooseone="Please choose one location" optslClick="change_location" optslCheckAllForSearch="true" placeholder="-- All locations --" optsl="multiple" class="form-control2 search" name="location_id" id="location_id">
                                            <?php foreach ($locationList as $item): ?>
                                                <option value="<?php echo $item['location_id'] ?>"><?php echo $item['location_name']; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Machine S/N <span style="color:#F30;">(*)</span></label>
                                    <div class="col-md-8">
                                        <select msgempty="Please choose station serial" placeholder="-- All machines --" optsl="multiple" optslClick="change_machine" class="form-control2 search"  optslCheckAllForSearch="true" name="stationid" id="stationid" >
                                            <?php
                                            foreach ($stationList as $item) {
                                                if (!empty($item['location_id'])) {
                                                    ?>
                                                    <option machine_id="<?= $item['id'] ?>" value="<?= $item['station_serial'] ?>"><?= $item['station_serial'] ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div style="float:right;  margin-right:20px;" class="portlet-body form">
                                    <a  title="Search" href="javascript:void(0);" class="btn_func" id="search" style="background-image: url(/web/img/ico-search.png)"></a>
                                    <a  title="Reset" href="javascript:void(0);" class="btn_func" id="reset" style="background-image: url(/web/img/reset_v2.png)"></a>
                                    <?php if (isset($right['add'])): ?>
                                        <a href="#detail" id="addprofile" class="btn_func various fancybox" title ="Add profile" style="background-image: url(/web/img/add_v1.png)"></a>
                                    <?php endif; ?>
                                    <?php if (isset($right['edit'])): ?>
                                        <a  href="javascript:void(0);" class="btn_func" id="updateprofile" title ="Update" style="background-image: url(/web/img/update_v1.png)"></a>
                                    <?php endif; ?>
                                    <?php if (isset($right['delete'])): ?>
                                        <a  href="javascript:void(0);" class="btn_func" id="delete" title ="Delete" style="background-image: url(/web/img/delete_v1.png)"></a>
                                    <?php endif; ?>									
                                    <?php if (isset($right['add'])): ?>
                                        <a id="syncprofile" title="Save" class="btn_func" href="javascript:void(0);"style="background-image: url(/web/img/save_v1.png)"></a>
                                    <?php endif; ?>
                                    <div style="margin-left:120px;width:20px;float:left;margin-top:8px; margin-right:20px; display:none;" id="loading"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row" style="margin-top: 10px !important;">
    <div class="col-md-12">
        <div class="portlet box blue" style="margin-top: 5px;">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-reorder"></i> Functional test
                </div>
                <div class="tools">
                    <a href="" class="collapse"></a>
                </div>
            </div>
            <div class="portlet-body form" style="padding: 5px 15px 15px 15px !important;">				
                <form action="" method="POST" id="formSetting" class="form-horizontal" role='form'>	
                    <div class="row">						
                        <div class="row">						
                            <div class="col-md-5 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-4" style="white-space: nowrap">Functional test profile</label>
                                    <div class="col-md-7" style="padding-left: 30px;">
                                        <select class="form-control2" name="profile" id="profile" >
                                            <?php foreach ($arr_profile as $kprofile => $vprofile): ?>
                                                <option value="<?php echo $kprofile ?>"><?php echo $vprofile ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>							
                            <div class="col-md-offset-2 col-md-5 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-offset-2 col-md-3" style="white-space: nowrap">Running profile <span style="color:#F30;"></span></label>
                                    <div class="col-md-7" style="padding-left: 30px;">
                                        <select class="form-control2"  name="profile_running" id="profile_running">
                                            <option value="-1">None</option>
                                            <?php foreach ($arr_profile as $kprofile => $vprofile): ?>
                                                <option value="<?php echo $kprofile ?>"><?php echo $vprofile ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-100">
                            <fieldset style="padding: 15px !important;">
                                <legend style="padding: 0px 5px 4px 5px"><h4 style="margin: 0"><b>Functional test settings</b></h4></legend>
                                <div class="row">
                                    <div style="margin-left:15px">
                                        <input id="ckalfts" type="checkbox" name="ckalfts" autocomplete="off">
                                        <label style="font-size: 14px; font-weight: 700;">Select all</label>
                                    </div>
                                </div>
                                <div class="row" id="htmlsurface_testing">

                                </div>
                            </fieldset>
                        </div>
                        <div class="col-md-12 col-100">
                            <div class="row">
                                <div class="col-md-12" style="margin-bottom: 15px;">
                                    <fieldset style="padding: 15px !important;">
                                        <legend style="padding: 0px 5px 4px 5px"><h4 style="margin: 0"><b>Score settings</b></h4></legend>
                                        <div class="row">                                        
                                            <div class="col-md-12" style="margin-bottom: 15px;text-align:center;font-size:18px;">                                               
                                                <div style="display:inline-block;">
                                                    <div style="color:#127AE9;">
                                                        Score = 8000- SUM(score of Front + score of Top + score of Bottom + score of Left + score of Right + score of Back) - SUM(score of Bent + score of Lift LCD + score of LCI)
                                                    </div>
                                                    <div class="text-left">Where: 
                                                        <span style="color:#285982;">
                                                            Score of surface = Number of defect * Surface * Defect * Size
                                                        </span>												
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom: 15px;">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <fieldset class="fieldset_l2" style="height:470px">
                                                            <legend><h4><b>Surface</b></h4></legend>

                                                            <table class="table table-bordered table-striped">
                                                                <thead>
                                                                    <tr>
                                                                        <th style="text-align:center;width:15%" >No.</th>
                                                                        <th style="text-align:center;width:42%">Surface</th>
                                                                        <th style="text-align:center;width:43%">Multiplier</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="htmlsurface">


                                                                </tbody>
                                                            </table>															

                                                        </fieldset>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <fieldset class="fieldset_l2" style="height:470px">
                                                            <legend><h4><b>Defects</b></h4></legend>
                                                            <table class="table table-bordered table-striped">
                                                                <thead>
                                                                    <tr style="background-color:#F9F9F9">
                                                                        <th colspan="4" style="text-align:center;">Type 1</th>																				
                                                                    </tr>
                                                                    <tr>
                                                                        <th style="text-align:center;width:10%">No.</th>
                                                                        <th style="text-align:center;width:35%">Defects</th>
                                                                        <th style="text-align:center;width:20%">Multiplier</th>
                                                                        <th style="text-align:center;width:35%">Max minus score</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="htmldefecttype1">
                                                                    <tr>
                                                                        <td style="text-align:center">1</td>
                                                                        <td style="text-align:center">Scratches</td>																				
                                                                        <td style="text-align:center">
                                                                            <input style="width:50px" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">2</td>
                                                                        <td style="text-align:center">Chips</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">3</td>
                                                                        <td style="text-align:center">Cracks</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																				
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																				
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">4</td>
                                                                        <td style="text-align:center">Piting/Ding/Dents</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																		
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">5</td>
                                                                        <td style="text-align:center">Discoloration</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">6</td>
                                                                        <td style="text-align:center">Paint peeling</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																				
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                        </fieldset>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <fieldset class="fieldset_l2" style="height:470px">
                                                            <legend><h4><b>Minus score defects</b></h4></legend>															
                                                            <table class="table table-bordered table-striped">
                                                                <thead>
                                                                    <tr style="background-color:#F9F9F9">
                                                                        <th colspan="3" style="text-align:center;">Type 2</th>

                                                                    </tr>
                                                                    <tr>
                                                                        <th style="text-align:center;width:15%" >No.</th>
                                                                        <th style="text-align:center;width:55%">Defects</th>
                                                                        <th style="text-align:center;width:30%">Score</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="htmldefecttype2">
                                                                    <tr>
                                                                        <td style="text-align:center">1</td>
                                                                        <td style="text-align:center">Bent</td>																				
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">2</td>
                                                                        <td style="text-align:center">LCI</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">3</td>
                                                                        <td style="text-align:center">LCD damage</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																				
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">4</td>
                                                                        <td style="text-align:center">Lift screen</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">5</td>
                                                                        <td style="text-align:center">Missing Mute switch</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">6</td>
                                                                        <td style="text-align:center">Missing Volume buttons</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>	
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">7</td>
                                                                        <td style="text-align:center">Missing Power button</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">8</td>
                                                                        <td style="text-align:center">Missing Home button</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>	
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">9</td>
                                                                        <td style="text-align:center">Missing iSight camera</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>																
                                                        </fieldset>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom: 15px;">
                                                <div class="row">
                                                    <div class="col-md-5">
                                                        <fieldset class="fieldset_l2" style="height:430px">
                                                            <legend><h4><b>Bent/Lift LCD level</b></h4></legend>															
                                                            <table class="table table-bordered table-striped">
                                                                <thead>
                                                                    <tr>
                                                                        <th style="width:100px;" id="cheo">
                                                                            <div style="float:right;">Surface</div>
                                                                            <div style="float:left;">Defects</div>
                                                                        </th>
                                                                        <th style="text-align:center;">Top</th>
                                                                        <th style="text-align:center;">Bottom</th>
                                                                        <th style="text-align:center;">Left</th>
                                                                        <th style="text-align:center;">Right</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="htmlbent_lift">
                                                                    <tr>
                                                                        <td style="text-align:center">Bent (Degrees)</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																				
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">Lift (mm)</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																				
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>																
                                                        </fieldset>
                                                    </div>
                                                    <div class="col-md-7">
                                                        <fieldset class="fieldset_l2" style="height:430px">
                                                            <legend><h4><b>Size</b></h4></legend>														
                                                            <table class="table table-bordered table-striped">														
                                                                <thead>	
                                                                    <tr>
                                                                        <th style="text-align:center;width:15%" >No.</th>
                                                                        <th style="text-align:center;width:65%">Size of defects (mm)</th>
                                                                        <th style="text-align:center;width:30%">Multiplier</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="htmlsize">
                                                                    <tr>
                                                                        <td style="text-align:center">1</td>
                                                                        <td style="text-align:center">Size ≤ <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number"></td>																				
                                                                        <td style="text-align:center">
                                                                            <input style="width:124px" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">2</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            < Size ≤
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																				
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">3</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            < Size ≤ 
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:124px" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																				
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">4</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            < Size ≤ 
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">5</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            < Size ≤ 
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>																			
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">6</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            < Size ≤ 
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>	
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">7</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            < Size ≤ 
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>	
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="text-align:center">8</td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            < size
                                                                        </td>
                                                                        <td style="text-align:center">
                                                                            <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                        </td>	
                                                                    </tr>
                                                                <tbody>
                                                            </table>

                                                        </fieldset>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom: 15px;">
                                                <fieldset class="fieldset_l2">													
                                                    <legend><h4><b>Grade settings</b></h4></legend>													
                                                    <fieldset class="fieldset_l2">													
                                                        <legend><h4><b>Score</b></h4></legend>
                                                        <div class="col-md-5">
                                                            <div class="row">																			
                                                                <table class="table table-bordered table-striped">
                                                                    <thead>
                                                                        <tr>
                                                                            <th style="text-align:center;width:19%;" rowspan="2" >Grade</th>
                                                                            <th style="text-align:center;" colspan="2">Score</th>																						
                                                                            <th style="text-align:center;width:27%" rowspan="2">Constraints</th>
                                                                            <th style="text-align:center;width:27%" rowspan="2">Delete</th>

                                                                        </tr>
                                                                        <tr>																						
                                                                            <th style="text-align:center;width:27%">From</th>
                                                                            <th style="text-align:center;width:27%">To</th>																						
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody id="htmlgrade">
                                                                        <tr>
                                                                            <td style="text-align:center">A</td>
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>																				
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>
                                                                            <td style="text-align:center" >
                                                                                <a id="detail_grade_a" label_grade="A" class="various fancybox detail_grade" title="Detail" href="#stepInfoContainer">
                                                                                    Detail
                                                                                </a>
                                                                            </td>

                                                                        </tr>
                                                                        <tr>
                                                                            <td style="text-align:center">B</td>
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>																				
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>																			

                                                                            <td style="text-align:center" >
                                                                                <a id="detail_grade_b" label_grade="B" class="various fancybox detail_grade" title="Detail" href="#stepInfoContainer">
                                                                                    Detail
                                                                                </a>
                                                                            </td>

                                                                        </tr>
                                                                        <tr>
                                                                            <td style="text-align:center">C</td>
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>																				
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>
                                                                            <td style="text-align:center" >
                                                                                <a id="detail_grade_c" label_grade="C" class="various fancybox detail_grade" title="Detail" href="#stepInfoContainer">
                                                                                    Detail
                                                                                </a>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="text-align:center">D</td>
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>																				
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>
                                                                            <td style="text-align:center" >
                                                                                <a id="detail_grade_d" label_grade="D" class="various fancybox detail_grade" title="Detail" href="#stepInfoContainer">
                                                                                    Detail
                                                                                </a>
                                                                            </td>

                                                                        </tr>
                                                                        <tr>
                                                                            <td style="text-align:center">E</td>
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>																				
                                                                            <td style="text-align:center">
                                                                                <input style="width:100%" class="form-control input-sm diin" value="" autocomplete="off" min="0" max="100" type="number">
                                                                            </td>
                                                                            <td style="text-align:center" >
                                                                                <a id="detail_grade_e" label_grade="E" class="various fancybox detail_grade" title="Detail" href="#stepInfoContainer">
                                                                                    Detail
                                                                                </a>
                                                                            </td>																					
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>																		
                                                        </div>
                                                    </fieldset>

                                                </fieldset>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom: 15px;">
                                                <fieldset class="fieldset_l2">													
                                                    <legend><h4><b>Graph</b></h4></legend>
                                                    <div class="row">
                                                        <div class="col-md-6" style="padding-left:70px; padding-right:40px; padding-top:70px;">														
                                                            <div id="mychart">
                                                            </div>
                                                            <div style="margin-top: 60px;">
                                                                <style>
                                                                    .tblgrcolor {
                                                                        background-color: #F3F3F3;
                                                                    }
                                                                    .tblgrcolor tr td {
                                                                        padding: 8px 15px;
                                                                    }
                                                                    .tblchart1sub{
                                                                        width: 100%;
                                                                    }
                                                                    .tblchart1sub, .tblchart1sub td, .tblchart1sub th {
                                                                        border: 1px solid #c3c3c3;
                                                                        padding: 8px;
                                                                    }
                                                                    .tblchart1sub {
                                                                        border-collapse: collapse;
                                                                        border-color: #c3c3c3;
                                                                    }
                                                                </style>
                                                                <table class="tblchart1sub text-center">
                                                                    <thead>
                                                                        <tr>
                                                                            <td style="font-weight: bold; text-align: left; width: 16%;">Surface</td>
                                                                            <td style="width: 14%;">Front</td>
                                                                            <td style="width: 14%;">Top</td>
                                                                            <td style="width: 14%;">Bottom</td>
                                                                            <td style="width: 14%;">Left</td>
                                                                            <td style="width: 14%;">Right</td>
                                                                            <td style="width: 14%;">Back</td>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td style="font-weight: bold; text-align: left;">Multiplier</td>
                                                                            <td><span id="mulfront" class="mulsfview"></span></td>
                                                                            <td><span id="multop" class="mulsfview"></span></td>
                                                                            <td><span id="mulbottom" class="mulsfview"></span></td>
                                                                            <td><span id="mulleft" class="mulsfview"></span></td>
                                                                            <td><span id="mulright" class="mulsfview"></span></td>
                                                                            <td><span id="mulback" class="mulsfview"></span></td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">														
                                                            <div id="chart2" style="position: relative; padding-right:50px; padding-left: 40px; padding-top:70px;">
                                                                <canvas id="canvas"></canvas>
                                                                <div style="position: absolute; top: 40px; left: 10px; color:#767676; font-size: 16px; font-weight: bold;">
                                                                    Quantity
                                                                </div>
                                                                <div style="position:absolute;bottom:20px;right:12px;font-size:16px;color:#767676;font-weight: bold;">
                                                                    Score
                                                                </div>
                                                            </div>
                                                            <div style="margin-top: 37px; padding-right: 64px; padding-left: 71px; text-align: right;">                                                                
                                                                <table class="tblgrcolor text-center">
                                                                    <tr>
                                                                        <td>
                                                                            <div style="background: rgb(0, 144, 188); height:4px; padding-right: 10px; width: 50px; display: inline-block"></div>
                                                                            Grade A
                                                                        </td>
                                                                        <td>
                                                                            <div style="background: rgb(227, 0, 6); width:50px; height:4px; display:inline-block"></div>
                                                                            Grade B                                                                            
                                                                        </td>
                                                                        <td>
                                                                            <div style="background: rgb(0, 166, 81); height:4px; width: 50px; padding-right: 10px; display: inline-block"></div>
                                                                            Grade C                                                                            
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <div style="background: rgb(146, 39, 143); width:50px; height:4px; display:inline-block"></div>
                                                                            Grade D
                                                                        </td>
                                                                        <td>
                                                                            <div style="background: rgb(255, 136, 0); width: 50px; height: 4px; padding-right: 10px; display: inline-block"></div>
                                                                            Grade E
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>                                                 
                                                </fieldset>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom:5px;text-align:center">																		
                                                <button type="button" class="btn blues" style="width:110px;background-color: #467894" title="Apply" id="apply"> Apply</button>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                    </div>           
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Add new profile -->
<!-- Modal -->
<div id="detail" class="popup modal-dialog modal-fade fancyboxForm" style="display: none;">		
    <div class="title-popup">
        Create profile	
        <button type="button" style="margin-top:5px" class="close closes" data-dismiss="modal" onclick="$.fancybox.close();" >				
        </button>
    </div>
    <div class="col-md-11">
        <div class="form-body content-popup">
            <div class="row">
                <div class="form-group col-md-12">
                    <label for="profilename" class="control-label col-md-3" style="color: #000;text-align: right;padding-right:0px;">Profile name <span class="required">(*)</span></label>
                    <div class="col-md-8">
                        <input type="text" placeholder="-- Input profile name--" name="profilename" id="profilename" class="form-control" value="" />

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer col-md-12" style="padding:10px!important;text-align:center!important;border-top:0px">
        <button type="button" class="btn blues" style="width:75px;margin-right:30px;" id="save" style="background-color: #006ead" onclick="addProfile('Add profile');"> Save</button>
        <button type="button" class="btn blues" id="cancel" style="width:75px;" style="background-color: #006ead" onclick="$.fancybox.close();"> Cancel</button>
    </div>
</div>
<input type="hidden" name="hid_itemid" id="hid_itemid" value="" />
<input type="hidden" name="hid_trackingid" id="hid_trackingid" value="" />
<!--//end Add new machine -->

<!-- Add Detail -->

<!--//end Detail -->	
<div id="stepInfoContainer" class="modal-dialog modal-lg fancyboxForm" style="display: none;">
    <div class="row"  style="margin-top:0 !important; color: black;">
        <div class="col-md-12"  style="margin-top:0;">
            <div id="listData">
                <div class="portlet box blue">
                    <div class="portlet-title">
                        <div class="caption">

                            <span>
                                Constraints
                            </span>
                        </div>
                        <div class="tools">							
                            <button type="button" style="margin-top:5px" class="close closes" data-dismiss="modal" onclick="$.fancybox.close();" >				
                            </button>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <div class="scroller" style="max-height:500px;">
                            <div class="col-md-12" style="color:#000">
                                <div class="row">
                                    <div class="form-body content-popup">
                                        <fieldset class="fieldset_l2">													
                                            <legend><h4><b><span style="color:#C04C19">Grade <span id="loadlabelgrade"></span></span></b></h4></legend>										
                                            <div class="col-md-5">
                                                <div class="row">	
                                                    <table class="table table-bordered table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th style="text-align:center;width:30%">Bent</th>
                                                                <th style="text-align:center;width:30%">Lift LCD</th>																						
                                                                <th style="text-align:center;width:30%">LCI</th>
                                                            </tr>									
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <select placeholder="-- Select --" optsl="single"  class="form-control2 search" name="bent" id="bent" >											
                                                                        <option value="No">No</option>
                                                                        <option value="Yes">Yes</option>											
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select placeholder="-- Select --" optsl="single" class="form-control2 search" name="lift" id="lift" >											
                                                                        <option value="No">No</option>
                                                                        <option value="Yes">Yes</option>											
                                                                    </select>
                                                                </td>																				
                                                                <td>
                                                                    <select placeholder="-- Select --" optsl="single" class="form-control2 search" name="lci" id="lci" >
                                                                        <option value="No">No</option>
                                                                        <option value="Yes">Yes</option>
                                                                    </select>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>							
                                                </div>
                                            </div>
                                            <!--Front-->
                                            <div class="col-md-12" id="htmlsettings">
                                                <div class="row">
                                                    <label class="control-label"><b>Surface: </b>Front</label>
                                                    <table class="table table-bordered table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th style="text-align:center" rowspan="2">No.</th>
                                                                <th style="text-align:center;" colspan="2">Scratches</th>																						
                                                                <th style="text-align:center;" colspan="2">Chips</th>																						
                                                                <th style="text-align:center;" colspan="2">Cracks</th>																						
                                                                <th style="text-align:center;" colspan="2">Dents</th>																						

                                                            </tr>
                                                            <tr>
                                                                <th style="text-align:center;">Quantity</th>																						
                                                                <th style="text-align:center;">Size (mm)</th>																						
                                                                <th style="text-align:center;">Quantity</th>																						
                                                                <th style="text-align:center;">Size (mm)</th>
                                                                <th style="text-align:center;">Quantity</th>																						
                                                                <th style="text-align:center;">Size (mm)</th>																						
                                                                <th style="text-align:center;">Quantity</th>																						
                                                                <th style="text-align:center;">Size (mm)</th>
                                                            </tr>									
                                                        </thead>
                                                        <tbody id="tbody_front">
                                                            <tr class="addmorefront frontend">
                                                                <td style="text-align:center" class="indexfront">1</td>									
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="1" autocomplete="off" min="0" max="100" type="number">
                                                                </td>									
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0.2" autocomplete="off" step="0.1" min="0" max="100" type="number">
                                                                </td>							
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>								
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                            </tr>
                                                            <tr class="addmorefront">
                                                                <td style="text-align:center" class="indexfront">2</td>									
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="2" autocomplete="off" min="0" max="100" type="number">
                                                                </td>									
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0.1" autocomplete="off" step="0.1" min="0" max="100" type="number">
                                                                </td>							
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>								
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>																	
                                                            </tr>
                                                        </tbody>
                                                        <tr>
                                                            <td colspan="9">
                                                                <a id="addmorefront" ids="front" class="addmore" title="Add more" href="#">
                                                                    Add more...										
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>					
                                            <!--End Front-->
                                        </fieldset>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="col-md-12" style="text-align:center;background-color:#fff;height:10px;">
                    </div>
                    <div class="col-md-12" style="text-align:center;background-color:#fff;">
                        <button type="button" class="btn blues" style="width:75px;margin-right:65px;" id="savedetail" style="background-color: #006ead"> Save</button>
                        <button type="button" class="btn blues" id="cancel" style="width:75px;" style="background-color: #006ead" onclick="$.fancybox.close();"> Cancel</button>
                    </div>
                    <div class="col-md-12" style="text-align:center;background-color:#fff;height:25px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .fancybox-inner{
        overflow: hidden!important;
        /*width:1000px!important;*/
    }
    .fancybox-wrap.fancybox-desktop.fancybox-type-inline.fancybox-opened{
        /*width:1000px!important;*/
    }
    @media (min-width:1292px){.modal-lg{width:1200px}}
    #stepInfoContainer .portlet-body{
        overflow-y: auto;
    }
    #chartdiv {
        width	: 100%;
        height	: 500px;
    }
    #cheo {
        background-image: linear-gradient(
            to top right,
            white 48%,
            #ddd,
            white 52%
            );
    }

    /* for testing */
    #cheo {
        width: 10em;
    }
    #cheo {
        width: 20em;
    } 
    .rederror{
        background-color:yellow;
    }
</style>