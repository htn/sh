<!-- layout se duoc dua du lieu vao -->
<?php $view->extend('GcsAdminBundle::admin.layout.html.php') ?>
<!--  Title c?a Page -->
<?php $view['slots']->start('title') ?>
<?php echo $GLOBALS['prefixTitle']; ?> - Functional Test Settings
<?php $view['slots']->stop() ?>
<?php $view['slots']->start('header') ?>

<small></small>
<?php $view['slots']->stop() ?>
<!-- JS can them vao -->
<?php $view['slots']->start('js') ?>
<script type="text/javascript" src="/web/admin/assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker1.min.js"></script>
<script src="/web/admin/assets/plugins/multipleselect/optimize.select.js"></script>
<script src="/web/admin/assets/plugins/multipleselect/optimize.js"></script>
<script src="/web/admin/assets/plugins/filterbox.js"></script>
<script src="/web/admin/assets/plugins/Chart.bundle.min.js"></script>
<!--<script src="/web/admin/assets/plugins/plotly-latest.min.js"></script>-->
<script>
    var infoCusLoc = JSON.parse('<?= $infoCusLoc ?>');
    var infoLocMac = JSON.parse('<?= $infoLocMac ?>');
    var searchCookie = '';
    var gridView = 'listData';
    var formView = 'formSearch';
    var formData = 'formSetting';
    var isAdmin = '<?= $isadmin; ?>';
    var customerID = '<?= $customerid; ?>';
    var option_none = '<option value="-1">None</option>'; // option profile NONE
    var click_search_profile = false;

    var data_global = {}; // Biến chứa dữ liệu của profile
    var global_grade = {};
    var global_surface = {};
    var global_defect_type1 = {};
    var global_defect_type2 = {};
    var global_surface_testing = {};
    var global_position = ['front', 'top', 'left', 'lci', 'back', 'bottom', 'right', 'bent', 'lift'];
    var color_line = [
        'rgb(0, 144, 188)',
        'rgb(227, 0, 6)',
        'rgb(0, 166, 81)',
        'rgb(146, 39, 143)',
        'rgb(6, 202, 244)',
        'rgb(100, 100, 244)',
        'rgb(50, 202, 50)',
        'rgb(150, 202, 100)'
    ];

    $(document).ready(function () {
        Optimize.initFormControl(); // Khởi tạo form
        initFirst();
        myReset(); // Reset thông số trên form về mặc định
        // Sự kiện nhấn nút search
        $("#search").click(function () {
            if ($(this).hasClass('disabled')) {
                return false;
            }
            searchCookie = '';
            var customserid = $("#user_name").multipleSelect('getSelects');
            var stationid = $("#stationid").multipleSelect('getSelects');
            var profileid = $("#profile").multipleSelect('getSelects');
            // Nếu station được chọn thì search theo station
            if (typeof stationid !== 'object') {
                if (stationid.indexOf(',') !== -1) { // Nếu chọn nhiều máy
                    search_profile(stationid, true);
                    click_search_profile = false;
                } else { // Nếu chỉ chọn 1 máy
                    loadInfo(stationid); //search profile
                }
                return false;
            }
            // Nếu profile list được chọn thì search theo profile
            if (typeof profileid !== 'object') {
                if (profileid.indexOf(',') === -1) {
                    click_search_profile = true;
                    detail_profile(profileid);
                    filter_button();
                } else {
                    showMessage('Message', 'Please select one profile in "Profile list" to search!');
                }
                return false;
            }
            // Nếu customer được chọn thì search theo customer
            if (typeof customserid !== 'object') {
                click_search_profile = false;
                find_profile(customserid, true);
                return false;
            }
            showMessage('Message', 'Please select Customer or S/N or one profile in "Profile list" to search.');
        });
    });

    function initFirst() {
        $("#profile").multipleSelect({
            filter: true,
            single: false,
            placeholder: "-- Select profile --",
            onClick: function (view) {
                filter_button();
            },
            onCheckAll: function () {
                filter_button();
            },
            onUncheckAll: function () {
                filter_button();
            }
        });
    }

    function checkDataValid(data) {
        if (!data.hasOwnProperty('datachart')) {
            showMessage('Message', 'Profile is invalid (Can not find key "datachart")');
            return false;
        }
        if (!data.hasOwnProperty('defect')) {
            showMessage('Message', 'Profile is invalid (Can not find key "defect")');
            return false;
        }
        if (!data.hasOwnProperty('grade')) {
            showMessage('Message', 'Profile is invalid (Can not find key "grade")');
            return false;
        }
        if (!data.hasOwnProperty('model_learnt')) {
            showMessage('Message', 'Profile is invalid (Can not find key "model_learnt")');
            return false;
        }
        if (!data.hasOwnProperty('others_info')) {
            showMessage('Message', 'Profile is invalid (Can not find key "others_info")');
            return false;
        }
        if (!data.hasOwnProperty('size')) {
            showMessage('Message', 'Profile is invalid (Can not find key "size")');
            return false;
        }
        if (!data.hasOwnProperty('surface')) {
            showMessage('Message', 'Profile is invalid (Can not find key "surface")');
            return false;
        }
        if (!data.hasOwnProperty('surface_testing')) {
            showMessage('Message', 'Profile is invalid (Can not find key "surface_testing")');
            return false;
        }
        return data;
    }

    // load chi tiết thông tin của 1 máy cụ thể
    function loadInfo(machine) {//search profile
        console.log('Gọi hàm loadInfo');
        loadingForm(true);
        $.ajax({
            type: 'POST',
            url: "search",
            data: {machine: machine}
        }).done(function (r) {
            loadingForm(false);
            var data = JSON.parse(r);
            console.log(data);
            // hiển thị danh sách profile, profile running của máy này
            var arr = data.option;
            var option = '';
            if (arr !== '') {
                for (var pid in arr) {
                    option += '<option value="' + pid + '">' + arr[pid] + '</option>';
                }
            }
            $('#profile').html(option).multipleSelect('refresh').multipleSelect('uncheckAll');
            $('#profile_running').html(option_none + option).multipleSelect('refresh').multipleSelect('uncheckAll');
            // load chi tiết profile running
            if (data.profile_running !== '' && data.profile_running != 0) {
                console.log('loadInfo oad profile running');
                $('#profile_running').multipleSelect('setSelects', [data.profile_running]);
            } else {
                console.log('loadInfo load giao diện mặc định');
            }
            filter_button();
        }).fail(function (x) {
            loadingForm(false);
        });
    }
    // Hàm tìm profile theo sn
    function search_profile(stationid, showMsg) {
        loadingForm(true);
        $.ajax({
            type: "POST",
            url: 'search-profile',
            data: {
                stationIDs: stationid
            }
        }).done(function (r) {
            loadingForm(false);
            console.log(r);
            if (r === 'empty') {
                $('#profile').html('').multipleSelect('refresh').multipleSelect('uncheckAll');
                $('#profile_running').html(option_none).multipleSelect('refresh').multipleSelect('uncheckAll');
                if (showMsg) {
                    showMessage('Message', 'No matches found!');
                }
                return false;
            }
            var obj = JSON.parse(r);
            if (obj.status === 'success') {
                var arr = obj.option;
                var option = '';
                for (var pid in arr) {
                    option += '<option value="' + pid + '">' + arr[pid] + '</option>';
                }
                $('#profile').html(option).multipleSelect('refresh').multipleSelect('uncheckAll');
                $('#profile_running').html(option_none + option).multipleSelect('refresh').multipleSelect('uncheckAll');
            }
        }).fail(function (x) {
            showMessage('Message', 'Search profile failed!');
            loadingForm(false);
        });
    }
    // Hàm thêm mới profile
    function addProfile(title) {
        console.log('Gọi hàm addProfile để thêm mới profile');
        var elFS = jQuery("#formSearch");
        App.blockUI({target: elFS, iconOnly: false});
        var customserid = $("#user_name").multipleSelect('getSelects');
        var profilename = $("#profilename").val().trim();
        if (profilename === '') {
            showMessage('Message', 'Please enter profile name.');
            return false;
        }
        if (existSpecialCharacter(profilename)) {
            showMessage('Message', 'Profile name contains only letters and numbers.');
            return false;
        }
        var check1 = check_grade_from_to();
        var check2 = check_size();
        if (check1 > 0 || check2 > 0) {
            showMessage('Message', 'Invalid values. Please check again!');
            return false;
        }
        var searchs = getSearch(); //console.log(data_global);      
        searchs = searchs.replace(/'/g, '');
        functional_tests = JSON.stringify(data_global);
        $.ajax({
            type: "POST",
            url: 'add-profile',
            data: {searchs: searchs, profilename: profilename, functional_tests: functional_tests}, success: function (data) {
                loadingForm(false);
                if (data == 1) {
                    showMessage('Message', title + ' successfully.');
                    $("#profilename").val('');
                    find_profile(customserid, true);
                    $.fancybox.close();
                } else if (data == 0) {
                    showMessage('Message', title + ' failed. Profile name exist!');
                } else {
                    showMessage('Message', title + ' failed.');
                }

            },
            error: function () {
                loadingForm(false);
                showMessage('Message', title + ' failed.');
            }
        });
        return true;
    }
    // Tìm profile theo customer
    function find_profile(customerIDs, showMsg) {
        console.log('Gọi hàm find_profile để tìm profile theo customer');
        loadingForm(true);
        $.ajax({
            type: "POST",
            url: 'find-profile',
            data: {
                customerIDs: customerIDs
            }
        }).done(function (r) {
            loadingForm(false);
            if (r === 'empty') {
                $('#profile').html('').multipleSelect('refresh').multipleSelect('uncheckAll');
                $('#profile_running').html(option_none).multipleSelect('refresh').multipleSelect('uncheckAll');
                console.log(showMsg + 'showMsg find_profile');
                if (showMsg) {
                    showMessage('Message', 'No matches found');
                }
                return false;
            }
            var obj = JSON.parse(r);
            if (obj.status === 'success') {
                var arr = obj.option;
                var option = '';
                for (var pid in arr) {
                    option += '<option value="' + pid + '">' + arr[pid] + '</option>';
                }
                $('#profile').html(option).multipleSelect('refresh').multipleSelect('uncheckAll');
                $('#profile_running').html(option_none + option).multipleSelect('refresh').multipleSelect('uncheckAll');
            }
        }).fail(function (x) {
            showMessage('Message', 'Search profile failed!');
            loadingForm(false);
        });
    }
    // Load profile chi tiết
    function detail_profile(profile_id) {
        console.log('Gọi hàm profile_id để load chi tiết profile');
        var search = getSearch();
        loadingForm(true);
        $.ajax({
            type: "POST",
            url: 'detail-profile',
            data: {
                search: search,
                profile: profile_id
            }
        }).done(function (r) {
            loadingForm(false);
            var obj = IsJsonString(r);
            if (obj === false) {
                return false;
            }
            // nếu dữ liệu ko có key functional_tests
            if (!obj.hasOwnProperty('functional_tests')) {
                showMessage('Message', 'Data is invalid (Can not find key "functional_tests")');
                return false;
            }
            data_global = checkDataValid(obj.functional_tests);
            if (data_global === false) {
                return false;
            }
            parameter_initialize(data_global);
            ui_initialize();
        }).fail(function (x) {
            showMessage('Message', 'Load profile failed');
            loadingForm(false);
        });
    }

    function ui_initialize() {
        ui_surface_testing();
        ui_surface();
        ui_defect();
        ui_defect_minus_score();
        ui_bent_lift_lcd_level();
        ui_size();
        ui_grade_score();

        ui_chart2();
    }

    function ui_surface_testing() {
        if ($.isEmptyObject(global_surface_testing)) {
            showMessage('Message', 'Data is invalid (global_surface_testing is empty)');
            return false;
        }
        var html = '';
        var cka_st = true;
        $.each(global_surface_testing, function (key, item) {
            var id_name = 'is' + jsUcfirst(key);
            cka_st = (!item ? item : cka_st);
            html += '<div class="col-md-3">';
            html += '<div><input type="checkbox" ' + (item ? 'checked' : '') + ' class="surface_testing cke_st" onclick="cke_st_click()" autocomplete="off" name="' + id_name + '" id="' + id_name + '">';
            html += ' <label for="' + id_name + '">' + jsUcfirst(key) + '</label></div>';
            html += '</div>';
        });
        $('#cka_st').prop('checked', cka_st);
        $('#html_surface_testing').html(html);
    }
    function ui_surface() {
        var html = '';
        var i = 1;
        $.each(global_surface, function (key, item) {
            var id = item['id'];
            var multiplier = item['multiplier'];
            var name = item['name'];
            html += '<tr class="surface">';
            html += '<td class="key text-center" ids ="' + id + '">' + i + '</td>';
            html += '<td class="name_surface text-center">' + name + '</td>';
            html += '<td class="text-center">';
            html += '<input id="multiplier_' + id + '" class="form-control input-sm diin calgrade multiplier_surface text-center" value="' + multiplier + '"  autocomplete="off" min="0" max="100" step="0.01" type="number">';
            html += '</td>';
            html += '</tr>';
            i++;
        });
        $('#html_surface').html(html);
    }
    function ui_defect() {
        var html = '';
        var i = 1;
        $.each(global_defect_type1, function (key, item) {
            html += '<tr>';
            html += '<td class="text-center">' + (i++) + '</td>';
            html += '<td class="text-center">' + item['name'] + '</td>';
            html += '<td class="text-center">';
            html += '<input class="form-control input-sm" id="defect_mul_' + key + '" value="' + item['multiplier'] + '" autocomplete="off" min="0" max="100" type="number">';
            html += '</td>';
            html += '<td class="text-center">';
            html += '<input class="form-control input-sm" id="defect_max_' + key + '" value="' + item['max_unlimited'] + '" autocomplete="off" min="0" max="100" type="number">';
            html += '</td>';
            html += '</tr>';
        });
        $('#html_defect').html(html);
    }
    function ui_defect_minus_score() {
        var html = '';
        var i = 1;
        $.each(global_defect_type2, function (key, item) {
            html += '<tr>';
            html += '<td class="text-center">' + (i++) + '</td>';
            html += '<td class="text-center">' + item['name'] + '</td>';
            html += '<td class="text-center">';
            html += '<input style="width:100%" class="form-control input-sm" id="' + key + '" value="' + item['point'] + '" autocomplete="off" min="0" max="100" type="number">';
            html += '</td>';
            html += '</tr>';
        });
        $('#html_defect_minus_score').html(html);
    }
    function ui_bent_lift_lcd_level() {
        var html = '';
        if (data_global['defect'].hasOwnProperty('bent_lift_config')) {
            var tmp = ['bottom', 'top', 'left', 'right'];
            var config = data_global['defect']['bent_lift_config'];
            if (config.hasOwnProperty('bent_config')) {
                var item = config['bent_config'];
                html += '<tr><td class="text-center">Bent (Degrees)</td>';
                for (var i in tmp) {
                    var val = (item.hasOwnProperty('distance_' + tmp[i])) ? item['distance_' + tmp[i]] : 0;
                    html += '<td class="text-center">';
                    html += '<input class="form-control input-sm" value="' + val + '" autocomplete="off" min="0" max="100" type="number">';
                    html += '</td>';
                }
                html += '</tr>';
            }
            if (config.hasOwnProperty('lift_config')) {
                var item = config['lift_config'];
                html += '<tr><td class="text-center">Lift (mm)</td>';
                for (var i in tmp) {
                    var val = (item.hasOwnProperty('distance_' + tmp[i])) ? item['distance_' + tmp[i]] : 0;
                    html += '<td class="text-center">';
                    html += '<input class="form-control input-sm" value="' + val + '" autocomplete="off" min="0" max="100" type="number">';
                    html += '</td>';
                }
                html += '</tr>';
            }
        }
        $('#html_lcd_level').html(html);
    }
    function ui_size() {
        var html = '';
        var j = 1;
        if (data_global.hasOwnProperty('size')) {
            var obj = data_global['size'];
            for (var i in obj) {
                var item = obj[i];
                html += '<tr>';
                html += '<td class="text-center">' + (j++) + '</td>';
                html += '<td class="text-center">';
                html += '<input class="form-control input-sm score_from" value="' + item['from'] + '" autocomplete="off" min="0" max="100" type="number">';
                html += '&nbsp;&nbsp;< Size ≤&nbsp;&nbsp;';
                html += '<input class="form-control input-sm score_to" value="' + item['to'] + '" autocomplete="off" min="0" max="100" type="number">';
                html += '</td>';
                html += '<td class="text-center">';
                html += '<input class="form-control input-sm" value="' + item['multiplier'] + '" autocomplete="off" min="0" max="100" type="number">';
                html += '</td>';
                html += '</tr>';
            }
        }
        $('#html_size').html(html);
    }
    function ui_grade_score() {
        var html = '';
        if (data_global.hasOwnProperty('grade')) {
            var obj = data_global['grade'];
            for (var i in obj) {
                var item = obj[i];
                html += '<tr>';
                html += '<td class="text-center">' + item['name_grade'] + '</td>';
                html += '<td class="text-center">';
                html += '<input class="form-control input-sm" value="' + item['score_from'] + '" autocomplete="off" min="0" max="100" type="number">';
                html += '</td>';
                html += '<td class="text-center">';
                html += '<input class="form-control input-sm" value="' + item['score_to'] + '" autocomplete="off" min="0" max="100" type="number">';
                html += '</td>';
                html += '<td class="text-center">';
                html += '<a id="detail_grade_' + item['name_grade'].toLowerCase() + '" label_grade="A" class="various fancybox detail_grade" title="Detail" href="#stepInfoContainer">Detail</a>';
                html += '</td>';
                html += '<td class="text-center"><span class="remove_grade_score glyphicon glyphicon-remove"></span></td>';
                html += '</tr>';
            }
        }
        $('#html_grade').html(html);
    }

    function ui_chart1() {
        var axis_x = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000];
        var axis_y = [];
        var data_chart = data_global['grade'];
        for (var i in data_chart) {
            axis_y.push(data_chart[i]['name_grade']);
        }
        console.log(axis_y);
        var val_chart = [
            {'label': 'A', 'from': 0, 'to': 0},
            {'label': 'B', 'from': 0, 'to': 0},
            {'label': 'C', 'from': 0, 'to': 0},
            {'label': 'D', 'from': 0, 'to': 0},
            {'label': 'E', 'from': 0, 'to': 0}
        ];
        $('#chart1').html('');
        var w = $('#chart1').width(); // lấy chiều rộng của chart
        var h = $('#chart1').height(); // lấy chiều cao của chart
        console.log('w:' + w + ' h:' + h);
        var segment_x = Math.floor(w / axis_x.length); // giá trị 1 khoảng của trục x tính ra px
        w = segment_x * axis_x.length + 2; // tính lại chiều rộng + thêm 2 pixel
        $('#chart1').css('width', w + 'px'); // Set lại chiều rộng cho chart
        var segment_y = Math.floor(h / axis_y.length); //giá trị 1 khoảng của trục y tính ra px
        var scale_x = segment_x / axis_x[0]; //tỉ lệ xích

        var map_y = {};
        for (var i in axis_y) {
            var distance = (parseInt(i) + 1) * segment_y;
            map_y[axis_y[i]] = distance;
            //label y
            var tick_y_label = '<div class="tick_y_label">' + axis_y[i] + '</div>';
            var tmp = $(tick_y).css('bottom', distance + 'px');
            var tmp_label = $(tick_y_label).css('bottom', (distance - 10) + 'px');
            //duong keo dai
            var tmp_h = $(tick_y_h).css({"bottom": distance + "px", "width": w + "px"});
            $('#chart1').append(tmp).append(tmp_label).append(tmp_h);
        }

        data_chart.forEach(function (item) {
            var label = item.name_grade;
            var bottom = map_y[label] - half_width_label;
            var start = val_chart[i].from * scale_x;
            var width = (val_chart[i].to - val_chart[i].from) * scale_x;
            if (start < 0) {
                start = 0;
                width = (val_chart[i].to - 0) * scale_x;
            }
            if (width > 0) {
                if (width < 10) {
                    sub_width = Math.floor(width / 2);
                } else {
                    sub_width = 5;
                }
                obj_subwidth['cluster_' + label] = sub_width;
                var element = $('<div id="cluster_' + label + '" class="cluster"></div>').css({"left": start + "px", "bottom": bottom + "px", "width": width + "px"});
                $('#mychart').append(element);
                //Tạo hai thẻ div nhỏ 2 bên khối để mouse chuột kéo đi
                var sub_element_l = $('<div id="left_sub_cluster_' + label + '" idlabel="cluster_' + label + '" idnumber="tick_x_number_' + label + '" class="sub_cluster" ></div>').css({"left": start + "px", "bottom": bottom + "px", "width": sub_width + "px"});
                var ds = start + width - sub_width;
                var sub_element_r = $('<div id="right_sub_cluster_' + label + '" idlabel="cluster_' + label + '" idnumber="tick_x_number_' + label + '" class="sub_cluster"></div>').css({"left": ds + "px", "bottom": bottom + "px", "width": sub_width + "px"});
                $('#mychart').append(sub_element_l).append(sub_element_r);
                //Tạo số màu vàng trên khối					
                var bottoms = map_y[label] + half_width_label + 3;
                var number_label = '<div class="tick_x_number" id="tick_x_number_' + label + '"><span id="txn_left_' + label + '" style=float:left>' + (val_chart[i].from < 0 ? 0 : val_chart[i].from) + '</span><span id="txn_right_' + label + '" style=float:right>' + val_chart[i].to + '</span></div>';
                var css_number_label = $(number_label).css({"left": start + "px", "bottom": bottoms + "px", "width": width + "px"});
                $('#mychart').append(css_number_label);
                //đường phụ trục dài trục x theo label					
                var tmp_tick_x_h1 = $(tick_x_h).css({"left": start + "px", "height": bottom + "px"});
                var starts = start + width;
                var tmp_tick_x_h2 = $(tick_x_h).css({"left": starts + "px", "height": bottom + "px"});
                $('#mychart').append(tmp_tick_x_h1).append(tmp_tick_x_h2);
            }
        });

    }

    function ui_chart2() {
        // Kiểm tra 1 số điều kiện thỏa trước khi vẽ chart2
        if (!data_global.hasOwnProperty('datachart')) {
            showMessage('Message', 'Data is invalid (can not found "datachart" key)');
            return false;
        }
        if (!data_global['datachart'].hasOwnProperty('data')) {
            showMessage('Message', 'Data is invalid (can not found "data" in "datachart")');
            return false;
        }
        if (data_global['datachart']['data'] === 0) {
            showMessage('Message', 'Data invalid ([datachart][data] is empty)');
            return false;
        }
        // Lấy dữ liệu ra và sắp xếp thành tọa độ
        var data_chart = {}; // Mảng chứa dữ liệu tọa độ (x,y) để vẽ chart2
        var max_qty = 0; // Số lượng có giá trị cao nhất, để giới hạn trục y
        var tmp_grade = data_global['grade'];
        var tmp_chart = data_global['datachart']['data'];
        for (var i in tmp_grade) {
            var item = tmp_grade[i];
            var from = parseInt(item['score_from']);
            var to = parseInt(item['score_to']);
            var grade_name = item['name_grade'];
            var tmp_score = [];
            var tmp_score_qty = [];
            var score_qty = []; // Mảng chứa danh sách tọa độ
            for (var j in tmp_chart) {
                if (grade_name === tmp_chart[j]['grade']) {
                    var score = parseInt(tmp_chart[j]['score']); // Điểm theo số lượng
                    if (score <= to && score >= from) { // Điểm phải nằm trong khoảng from to
                        tmp_score.push(score);
                        tmp_score_qty[score] = parseInt(tmp_chart[j]['quantity']);
                    }
                }
            }
            // Sắp xếp lại điểm theo thứ tự tăng dần
            tmp_score.sort(function (a, b) {
                return a - b;
            });
            // Gán lại điểm và số lượng tạo thành tọa độ 2D
            $.each(tmp_score, function (i_score, v_score) {
                score_qty.push({x: v_score, y: tmp_score_qty[v_score]});
                // So sánh để tìm ra số lượng có giá trị lớn nhất
                if (max_qty < tmp_score_qty[v_score]) {
                    max_qty = tmp_score_qty[v_score];
                }
            });
            // Gán danh sách tọa độ cho 1 grade (1 line)
            data_chart[grade_name] = score_qty;
        }

        // Tính toán lại chiều cao tối đa của chart (chính là số lượng)
        if (max_qty > 0) { // Nếu số lượng lớn hơn 0
            var tmpsplit = max_qty % 5; // Chia ra làm 5 phần xem còn dư bao nhiêu
            if (tmpsplit > 0) { // Nếu dư > 0
                max_qty = Math.floor(max_qty / 5) * 5 + 5; //  Tính lại max số lượng để cho có thể chia hết cho 5
            }
        } else { // Nếu không có số lượng thì gán mặc định là 30
            max_qty = 30;
        }

        // Tạo thành dữ liệu cho chart
        var datasets = [];
        var i = 0;
        for (var key in data_chart) {
            datasets.push({
                label: 'Grade ' + key,
                fill: false,
                hidden: false,
                lineTension: 0,
                backgroundColor: color_line[i],
                borderColor: color_line[i++],
                borderWidth: 2,
                pointRadius: 2,
                pointHoverRadius: 3,
                data: data_chart[key]
            });
        }

        // Gọi hàm vẽ chart2
        var config_chart2 = {
            type: 'line',
            data: {
                datasets: datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                onAnimationComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = this.scale.font;
                    ctx.fillStyle = this.scale.textColor;
                    ctx.textAlign = "center";
                    ctx.textBaseline = "bottom";
                    this.datasets.forEach(function (dataset) {
                        dataset.bars.forEach(function (bar) {
                            ctx.fillText(JSON.stringift(bar));
                        });
                    });
                },
                legend: {
                    display: false
                },
                legendCallback: function (chart) {
                    //var ul = document.createElement('ul');
                    var table = '<table class="tblgrcolor text-center">';
                    var i = 0;
                    chart.data.datasets.forEach(function (item, index) {
                        if (i === 0) {
                            table += '<tr>';
                        }
                        table += '<td><div class="legend_custom" style="background: ' + item.borderColor + ';"></div><span class="legend_custom_txt">' + item.label + '</span></td>';
                        if (i === 2) {
                            table += '</tr>';
                            i = 0;
                        } else {
                            i++;
                        }
                        //ul.innerHTML += '<li><span style="background-color: ' + item.borderColor + '"></span>' + item.label + '</li>';
                    });
                    if (i !== 0) {
                        table += '<tr>';
                    }
                    table += '<table>';
                    return table;
                },
                scales: {
                    xAxes: [{
                            type: 'linear',
                            ticks: {
                                beginAtZero: false,
                                min: 0,
                                max: 8000,
                                fontColor: "#1d1d1d",
                                fontSize: 13,
                                fontStyle: "bold",
                                padding: 15
                            },
                            pointLabels: {
                                fontColor: "#1d1d1d",
                                fontSize: 13,
                                fontStyle: "bold"
                            },
                            gridLines: {
                                color: "#e3e3e3",
                                lineWidth: 1,
                                tickMarkLength: -7,
                                drawOnChartArea: false,
                                zeroLineColor: 'transparent'
                            }
                        }],
                    yAxes: [{
                            type: 'linear',
                            ticks: {
                                beginAtZero: true,
                                min: 0,
                                max: max_qty,
                                stepSize: 5,
                                fontColor: "#1d1d1d",
                                fontSize: 13,
                                fontStyle: "bold",
                                zeroLineColor: 'transparent',
                                callback: function (value, index) {
                                    if (value !== 0) {

                                    } else {
                                        value = '';
                                    }
                                    return value;
                                },
                                padding: 10
                            },
                            pointLabels: {
                                fontColor: "#1d1d1d",
                                fontSize: 13,
                                fontWeight: 600
                            },
                            gridLines: {
                                color: "#e3e3e3",
                                lineWidth: 1,
                                tickMarkLength: 0
                            }
                        }]
                }
            }
        };
        var ctx = document.getElementById('canvas');
        ctx.height = 423;
        var chart2 = new Chart(ctx, config_chart2);
        // Customer lại legend
        $('#legend').html(chart2.generateLegend());
        // Click lên legend để ẩn/hiện line
        $('.legend_custom').each(function (index) {
            $(this).click(function () {
                console.log(index);
                if (config_chart2.data.datasets[index].hidden === false) {
                    config_chart2.data.datasets[index].hidden = true;
                    $('.legend_custom_txt').eq(index).removeClass('legend_custom_txt_disable');
                } else {
                    config_chart2.data.datasets[index].hidden = false;
                    $('.legend_custom_txt').eq(index).addClass('legend_custom_txt_disable');
                }
                chart2.update();
            });
        });
    }

    /*
     * Tách các thông tin trong chuỗi dư liệu đưa vào các mảng để sử dụng   
     */
    function parameter_initialize(data) {
        global_grade = createGlobalGrade(data['grade']);
        global_surface = createGlobalSurface(data['surface']);
        var global_defect = createGlobalDefect(data['defect']);
        global_defect_type1 = global_defect['type1'];
        global_defect_type2 = global_defect['type2'];
        global_surface_testing = createGlobalSurfaceTesting(data['surface_testing']);
        console.log('================== VARIABLE ==================');
        console.log("global_grade");
        console.log(global_grade);
        console.log("global_surface");
        console.log(global_surface);
        console.log("global_defect_type1");
        console.log(global_defect_type1);
        console.log("global_defect_type2");
        console.log(global_defect_type2);
        console.log("global_surface_testing");
        console.log(global_surface_testing);
        console.log('================== ENDVARIABLE ==================');
    }
    function createGlobalGrade(grade) {
        var rt = {};
        if (!$.isEmptyObject(grade)) {
            grade.forEach((item) => {
                rt[filterToKey(item['name_grade'])] = item;
            });
        }
        return rt;
    }
    function createGlobalSurface(surface) {
        var rt = {};
        if (!$.isEmptyObject(surface)) {
            surface.forEach((item) => {
                rt[filterToKey(item['name'])] = item;
            });
        }
        return rt;
    }
    function createGlobalDefect(defect) {
        var rt1 = {};
        var rt2 = {};
        if (!$.isEmptyObject(defect)) {
            if (defect.hasOwnProperty('defect_type_1')) {
                if (!$.isEmptyObject(defect['defect_type_1'])) {
                    defect['defect_type_1'].forEach((item) => {
                        rt1[filterToKey(item['name'])] = item;
                    });
                }
            }
            if (defect.hasOwnProperty('defect_type_2')) {
                if (!$.isEmptyObject(defect['defect_type_2'])) {
                    defect['defect_type_2'].forEach((item) => {
                        rt2[filterToKey(item['name'])] = item;
                    });
                }
            }
        }
        return {"type1": rt1, "type2": rt2};
    }
    function filterToKey(str) {
        // xóa tất cả ký tự đặc biệt
        return str.replace(/[&\/\\#,+()$~%. '":*?<>{}]/g, '').toLowerCase();
    }
    function createGlobalSurfaceTesting(surface_testing) {
        var tmp = {};
        if (!$.isEmptyObject(surface_testing)) {
            for (var key in surface_testing) {
                tmp[filterToKey(key.substring(2))] = surface_testing[key];
            }
        }
        var rt = {};
        // Sắp xếp lại cho đúng trật tự trên giao diện
        for (var i in global_position) {
            if (tmp.hasOwnProperty(global_position[i])) {
                rt[global_position[i]] = tmp[global_position[i]];
            }
        }
        return rt;
    }
    // Check all suface testing
    var cka_st_click = function (obj) {
        $('.cke_st').prop('checked', $(obj).prop('checked'));
    };
    // Check từng phần tử suface testing
    var cke_st_click = function () {
        if ($('input.cke_st:checked').length === $('input.cke_st').length) {
            $('#cka_st').prop('checked', true);
        } else {
            $('#cka_st').prop('checked', false);
        }
    };
    /*
     * Những function dùng chung, phổ biến
     */
    function IsJsonString(str) {
        try {
            var json = JSON.parse(str);
            if (typeof json === 'object') {
                return json;
            } else {
                showMessage('Message', 'Json format invalid data');
                return false;
            }
        } catch (e) {
            showMessage('Message', 'Json format invalid data');
            return false;
        }
    }
    function jsUcfirst(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    function change_customer() {
        $.filterbox.filter_children('#user_name', '#location_id', infoCusLoc);
        $.filterbox.filter_children('#location_id', '#stationid', infoLocMac);
        filter_button();
    }
    function change_location() {
        $.filterbox.checked_parent('#location_id', '#user_name', infoCusLoc);
        $.filterbox.filter_children('#location_id', '#stationid', infoLocMac);
    }
    function change_machine() {
        $.filterbox.checked_parent('#stationid', '#location_id', infoLocMac);
        $.filterbox.checked_parent('#location_id', '#user_name', infoCusLoc);
        filter_button();
    }
    function showMessage(title, content) {
        $.msgBox({
            title: title,
            content: content,
            type: "alert",
            buttons: [{value: "OK"}],
            success: function (result) {
            }
        });
    }
    function getSearch() {
        var customer = $("#user_name").multipleSelect('getSelects');
        if (typeof customer === 'object') {
            customer = '';
        }
        var locationid = $("#location_id").multipleSelect('getSelects');
        if (typeof locationid === 'object') {
            locationid = '';
        }
        var machine = $("#stationid").multipleSelect('getSelects');
        if (typeof machine === 'object') {
            machine = '';
        }
        var search = {
            'customer': customer,
            'locationid': locationid,
            'machine': machine
        };
        var searchs = JSON.stringify(search);
        return searchs;
    }
    function loadingForm(s) {
        var el = jQuery("#" + gridView);
        var elFS = jQuery("#" + formView);
        var elDT = jQuery("#" + formData);
        if (s === true) {
            App.blockUI({target: el, iconOnly: true});
            App.blockUI({target: elFS, iconOnly: false});
            App.blockUI({target: elDT, iconOnly: false});
        } else {
            App.unblockUI($('.ccontent'));
            App.initAjax();
            App.unblockUI(el);
            App.unblockUI(elFS);
            App.unblockUI(elDT);
        }
    }
    function myReset() {
        searchCookie = '';
        // reset multiselect box
        if (isAdmin === '0') {
            $("#user_name").multipleSelect('setSelects', [customerID]);
            change_customer();
            $('#location_id').multipleSelect('uncheckAll');
            $('#stationid').multipleSelect('uncheckAll');
        } else {
            $('#user_name').multipleSelect('uncheckAll');
            change_customer();
        }
        //reset profile
        if (isAdmin === '0') {
            find_profile(customerID);
        } else {
            var option = '';
            $('#profile').html(option).multipleSelect('refresh').multipleSelect('uncheckAll');
            $('#profile_running').html(option_none + option).multipleSelect('refresh').multipleSelect('uncheckAll');
        }
        // reset value class search
        $(".search").each(function () {
            var tag = $(this).prop("tagName");
            if (tag === 'INPUT') {
                $(this).val('');
            }
        });
        // reset button
        filter_button();
    }
    // Hiện/ẩn các button theo điều kiện giao diện
    function filter_button() {
        var customer = $("#user_name").multipleSelect('getSelects');
        var station = $("#stationid").multipleSelect('getSelects');
        var profile_list = $('#profile').multipleSelect('getSelects');
        var profile_running = $('#profile_running').multipleSelect('getSelects');
        if (typeof customer === 'object') {
            $('#addprofile').addClass('disabled').css('background-image', 'url(/web/img/add_disable_v1.png)');
        } else {
            $('#addprofile').removeClass('disabled').css('background-image', 'url(/web/img/add_v1.png)');
        }
        if (typeof profile_list !== 'object') {
            $('#delete').removeClass('disabled').css('background-image', 'url(/web/img/delete_v1.png)');
            if (click_search_profile) {
                $('#updateprofile').removeClass('disabled').css('background-image', 'url(/web/img/update_v1.png)');
            } else {
                $('#updateprofile').addClass('disabled').css('background-image', 'url(/web/img/update_disable_v1.png)');
            }
        } else {
            $('#updateprofile').addClass('disabled').css('background-image', 'url(/web/img/update_disable_v1.png)');
            $('#delete').addClass('disabled').css('background-image', 'url(/web/img/delete_disable_v1.png)');
        }
        if (typeof station === 'object') {
            $('#syncprofile').addClass('disabled').css('background-image', 'url(/web/img/save_disable_v1.png)');
        } else if (typeof profile_list !== 'object' || typeof profile_running !== 'object') {
            $('#syncprofile').removeClass('disabled').css('background-image', 'url(/web/img/save_v1.png)');
        } else {
            $('#syncprofile').addClass('disabled').css('background-image', 'url(/web/img/save_disable_v1.png)');
        }
    }
    // Kiểm tra xem chuỗi có chứa ký tự đặc biệt không
    function existSpecialCharacter(string) {
        var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        if (format.test(string)) {
            return true;
        } else {
            return false;
        }
    }
</script>

<?php $view['slots']->stop() ?>
<!-- CSS can them vao -->
<?php $view['slots']->start('css') ?>


<link rel="stylesheet" type="text/css" href="/web/admin/assets/css/plugins.css"/>
<link rel="stylesheet" type="text/css" href="/web/admin/assets/plugins/uniform/css/uniform.default.css"/>
<link rel="stylesheet" type="text/css" href="/web/admin/assets/plugins/multipleselect/multiple-select.css"/>
<link rel="stylesheet" type="text/css" href="/web/admin/css/jquery-ui-1.8.22.custom.css"/>
<link rel="stylesheet" type="text/css" href="/web/admin/assets/css/style-metronic.css" />
<link rel="stylesheet" type="text/css" href="/web/admin/css/chart_ivaluategen3.css" />
<style>
    .multiple {
        width: auto;
        min-width: 100%;
    }
    .ms-drop input[type="checkbox"] {
        vertical-align: top;
    }

    .ms-parent {
        background: #fff;
        color: #000;
    }
    ::-webkit-input-placeholder {
        font-style: italic;
    }

    :-moz-placeholder { /* Firefox 18- */
        font-style: italic;
    }

    ::-moz-placeholder {  /* Firefox 19+ */
        font-style: italic;
    }

    :-ms-input-placeholder {
        font-style: italic;
    }
    .score_from, 
    .score_to {
        display: inline;
        width: 120px;
        height: 26px;
        padding: 2px;
    }
    .diin{
        display: inline;
        width: 70px;
        height: 26px;
        padding: 2px;
    }   

    /* fieldset */
    .fieldset_l2 {
        padding-top: 0px !important;
        padding-left: 15px !important;
        padding-right: 15px !important;
        padding-bottom: 15px !important;
        margin-top: -15px !important;
    }
    .fieldset_l2>legend>h4>b {
        font-size: 17px;
        padding-left: 10px;
        padding-right: 10px;
    }
    .fieldset_l2 .form-group {
        margin-bottom: 0 !important;
    }	


    .btn.blues{
        background-color:#006ead!important;
    }
    .popup {
        background-color:#F9F9F9
    }
    .popup .row {
        margin-left: -15px!important;
        margin-right: -15px!important;
    }
    .control-label{
        text-align:left!important;
    }
    .closes{
        background-image: url("/web/final/img/portlet-remove-icon.png")!important;
    }
    .btn_func {
        display: inline-block;
        height: 35px;
        margin-left: 10px;
        width: 35px;
    }
    #chart1 {
        -webkit-user-select: none !important; /* Safari 3.1+ */
        -moz-user-select: none !important; /* Firefox 2+ */
        -ms-user-select: none !important; /* IE 10+ */
        user-select: none !important; /* Standard syntax */
    }
    #chart1 div{
        -webkit-user-select: none !important; /* Safari 3.1+ */
        -moz-user-select: none !important; /* Firefox 2+ */
        -ms-user-select: none !important; /* IE 10+ */
        user-select: none !important; /* Standard syntax */
    }

    .remove_grade_score {
        color: red;
        cursor: pointer;
    }
    .legend_custom {
        height:10px;
        margin-right: 10px;
        width: 50px; 
        display: inline-block;
        cursor: pointer;
    }
    .legend_custom_txt {       
        display: inline-block;
    }
    .legend_custom_txt_disable {
        text-decoration: line-through;
    }
</style>
<?php $view['slots']->stop() ?>
<div id="dialog"></div>
<div class="row">
    <div class="col-md-12">
        <div class="portlet box blue ">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-reorder"></i> Search
                </div>
                <div class="tools">
                    <a href="" class="collapse"></a>
                </div>
            </div>
            <div class="portlet-body form" style="padding-bottom: 0px !important;">
                <form style="margin-bottom: 0" id="formSearch" action="<?php echo $view['router']->generate('gcs_admin_machine'); ?>" method="POST" class="form-horizontal" role='form'>
                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-4 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Customer</label>
                                    <div class="col-md-8">
                                        <select msgchooseone="Please choose one customer" optslClick="change_customer" optslCheckAllForSearch="true"  placeholder="-- All customers --" optsl="multiple" class="form-control2 search" name="user_name" id="user_name" >
                                            <?php foreach ($customerList as $item): ?>
                                                <option value="<?php echo $item['customer_id'] ?>"><?php echo $item['customer_name'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Location</label>
                                    <div class="col-md-8">
                                        <select msgchooseone="Please choose one location" optslClick="change_location" optslCheckAllForSearch="true" placeholder="-- All locations --" optsl="multiple" class="form-control2 search" name="location_id" id="location_id">
                                            <?php foreach ($locationList as $item): ?>
                                                <option value="<?php echo $item['location_id'] ?>"><?php echo $item['location_name']; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Machine S/N <span style="color:#F30;">(*)</span></label>
                                    <div class="col-md-8">
                                        <select msgempty="Please choose station serial" placeholder="-- All machines --" optsl="multiple" optslClick="change_machine" class="form-control2 search"  optslCheckAllForSearch="true" name="stationid" id="stationid" >
                                            <?php
                                            foreach ($stationList as $item) {
                                                if (!empty($item['location_id'])) {
                                                    ?>
                                                    <option machine_id="<?= $item['id'] ?>" value="<?= $item['station_serial'] ?>"><?= $item['station_serial'] ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div style="float:right;  margin-right:20px;" class="portlet-body form">
                                    <a  title="Search" href="javascript:void(0);" class="btn_func" id="search" style="background-image: url(/web/img/ico-search.png)"></a>
                                    <a  title="Reset" href="javascript:void(0);" class="btn_func" id="reset" style="background-image: url(/web/img/reset_v2.png)"></a>
                                    <?php if (isset($right['add'])): ?>
                                        <a href="#detail" id="addprofile" class="btn_func various fancybox" title ="Add profile" style="background-image: url(/web/img/add_v1.png)"></a>
                                    <?php endif; ?>
                                    <?php if (isset($right['edit'])): ?>
                                        <a  href="javascript:void(0);" class="btn_func" id="updateprofile" title ="Update" style="background-image: url(/web/img/update_v1.png)"></a>
                                    <?php endif; ?>
                                    <?php if (isset($right['delete'])): ?>
                                        <a  href="javascript:void(0);" class="btn_func" id="delete" title ="Delete" style="background-image: url(/web/img/delete_v1.png)"></a>
                                    <?php endif; ?>									
                                    <?php if (isset($right['add'])): ?>
                                        <a id="syncprofile" title="Save" class="btn_func" href="javascript:void(0);"style="background-image: url(/web/img/save_v1.png)"></a>
                                    <?php endif; ?>
                                    <div style="margin-left:120px;width:20px;float:left;margin-top:8px; margin-right:20px; display:none;" id="loading"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row" style="margin-top: 10px !important;">
    <div class="col-md-12">
        <div class="portlet box blue" style="margin-top: 5px;">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-reorder"></i> Functional test
                </div>
                <div class="tools">
                    <a href="" class="collapse"></a>
                </div>
            </div>
            <div class="portlet-body form" style="padding: 5px 15px 15px 15px !important;">				
                <form action="" method="POST" id="formSetting" class="form-horizontal" role='form'>	
                    <div class="row">						
                        <div class="row">						
                            <div class="col-md-5 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-4" style="white-space: nowrap">Functional test profile</label>
                                    <div class="col-md-7" style="padding-left: 30px;">
                                        <select class="form-control2" name="profile" id="profile" >
                                            <?php foreach ($arr_profile as $kprofile => $vprofile): ?>
                                                <option value="<?php echo $kprofile ?>"><?php echo $vprofile ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>							
                            <div class="col-md-offset-2 col-md-5 col-50">
                                <div class="form-group">
                                    <label class="control-label col-md-offset-2 col-md-3" style="white-space: nowrap">Running profile <span style="color:#F30;"></span></label>
                                    <div class="col-md-7" style="padding-left: 30px;">
                                        <select class="form-control2"  name="profile_running" id="profile_running">
                                            <option value="-1">None</option>
                                            <?php foreach ($arr_profile as $kprofile => $vprofile): ?>
                                                <option value="<?php echo $kprofile ?>"><?php echo $vprofile ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-100">
                            <fieldset style="padding: 15px !important;">
                                <legend style="padding: 0px 5px 4px 5px"><h4 style="margin: 0"><b>Functional test settings</b></h4></legend>
                                <div class="row">
                                    <div style="margin-left:15px">
                                        <input id="cka_st" type="checkbox" name="cka_st" onclick="cka_st_click(this)" autocomplete="off">
                                        <label style="font-size: 14px; font-weight: 700;">Select all</label>
                                    </div>
                                </div>
                                <div class="row" id="html_surface_testing">

                                </div>
                            </fieldset>
                        </div>
                        <div class="col-md-12 col-100">
                            <div class="row">
                                <div class="col-md-12" style="margin-bottom: 15px;">
                                    <fieldset style="padding: 15px !important;">
                                        <legend style="padding: 0px 5px 4px 5px"><h4 style="margin: 0"><b>Score settings</b></h4></legend>
                                        <div class="row">                                        
                                            <div class="col-md-12" style="margin-bottom: 15px;text-align:center;font-size:18px;">                                               
                                                <div style="display:inline-block;">
                                                    <div style="color:#127AE9;">
                                                        Score = 8000- SUM(score of Front + score of Top + score of Bottom + score of Left + score of Right + score of Back) - SUM(score of Bent + score of Lift LCD + score of LCI)
                                                    </div>
                                                    <div class="text-left">Where: 
                                                        <span style="color:#285982;">
                                                            Score of surface = Number of defect * Surface * Defect * Size
                                                        </span>												
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom: 15px;">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <fieldset class="fieldset_l2" style="height:470px">
                                                            <legend><h4><b>Surface</b></h4></legend>
                                                            <table class="table table-bordered table-striped">
                                                                <thead>
                                                                    <tr>
                                                                        <th style="text-align:center;width:15%" >No.</th>
                                                                        <th style="text-align:center;width:42%">Surface</th>
                                                                        <th style="text-align:center;width:43%">Multiplier</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="html_surface"></tbody>
                                                            </table>
                                                        </fieldset>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <fieldset class="fieldset_l2" style="height:470px">
                                                            <legend><h4><b>Defects</b></h4></legend>
                                                            <table class="table table-bordered table-striped">
                                                                <thead>
                                                                    <tr style="background-color:#F9F9F9">
                                                                        <th colspan="4" style="text-align:center;">Type 1</th>																				
                                                                    </tr>
                                                                    <tr>
                                                                        <th style="text-align:center;width:10%">No.</th>
                                                                        <th style="text-align:center;width:35%">Defects</th>
                                                                        <th style="text-align:center;width:20%">Multiplier</th>
                                                                        <th style="text-align:center;width:35%">Max minus score</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="html_defect"></tbody>
                                                            </table>
                                                        </fieldset>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <fieldset class="fieldset_l2" style="height:470px">
                                                            <legend><h4><b>Minus score defects</b></h4></legend>															
                                                            <table class="table table-bordered table-striped">
                                                                <thead>
                                                                    <tr style="background-color:#F9F9F9">
                                                                        <th colspan="3" style="text-align:center;">Type 2</th>
                                                                    </tr>
                                                                    <tr>
                                                                        <th style="text-align:center;width:15%" >No.</th>
                                                                        <th style="text-align:center;width:55%">Defects</th>
                                                                        <th style="text-align:center;width:30%">Score</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="html_defect_minus_score"></tbody>
                                                            </table>																
                                                        </fieldset>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom: 15px;">
                                                <div class="row">
                                                    <div class="col-md-5">
                                                        <fieldset class="fieldset_l2" style="height:430px">
                                                            <legend><h4><b>Bent/Lift LCD level</b></h4></legend>															
                                                            <table class="table table-bordered table-striped">
                                                                <thead>
                                                                    <tr>
                                                                        <th style="width:100px;" id="cheo">
                                                                            <div style="float:right;">Surface</div>
                                                                            <div style="float:left;">Defects</div>
                                                                        </th>
                                                                        <th style="text-align:center;">Top</th>
                                                                        <th style="text-align:center;">Bottom</th>
                                                                        <th style="text-align:center;">Left</th>
                                                                        <th style="text-align:center;">Right</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="html_lcd_level"></tbody>
                                                            </table>																
                                                        </fieldset>
                                                    </div>
                                                    <div class="col-md-7">
                                                        <fieldset class="fieldset_l2" style="height:430px">
                                                            <legend><h4><b>Size</b></h4></legend>														
                                                            <table class="table table-bordered table-striped">														
                                                                <thead>	
                                                                    <tr>
                                                                        <th style="text-align:center;width:15%" >No.</th>
                                                                        <th style="text-align:center;width:65%">Size of defects (mm)</th>
                                                                        <th style="text-align:center;width:30%">Multiplier</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="html_size"><tbody>
                                                            </table>

                                                        </fieldset>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom: 15px;">
                                                <fieldset class="fieldset_l2">													
                                                    <legend><h4><b>Grade settings</b></h4></legend>													
                                                    <fieldset class="fieldset_l2">													
                                                        <legend><h4><b>Score</b></h4></legend>
                                                        <div class="col-md-5">
                                                            <div class="row">																			
                                                                <table class="table table-bordered table-striped">
                                                                    <thead>
                                                                        <tr>
                                                                            <th style="text-align:center;width:19%;" rowspan="2" >Grade</th>
                                                                            <th style="text-align:center;" colspan="2">Score</th>																						
                                                                            <th style="text-align:center;width:27%" rowspan="2">Constraints</th>
                                                                            <th style="text-align:center;width:27%" rowspan="2">Delete</th>

                                                                        </tr>
                                                                        <tr>																						
                                                                            <th style="text-align:center;width:27%">From</th>
                                                                            <th style="text-align:center;width:27%">To</th>																						
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody id="html_grade"></tbody>
                                                                </table>
                                                            </div>																		
                                                        </div>
                                                    </fieldset>

                                                </fieldset>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom: 15px;">
                                                <fieldset class="fieldset_l2">													
                                                    <legend><h4><b>Graph</b></h4></legend>
                                                    <div class="row">
                                                        <div class="col-md-6" style="padding-left:70px; padding-right:40px; padding-top:70px;">														
                                                            <div id="chart1">
                                                            </div>
                                                            <div style="margin-top: 60px;">
                                                                <style>
                                                                    .tblgrcolor {
                                                                        background-color: #F3F3F3;
                                                                    }
                                                                    .tblgrcolor tr td {
                                                                        padding: 8px 15px;
                                                                    }
                                                                    .tblchart1sub{
                                                                        width: 100%;
                                                                    }
                                                                    .tblchart1sub, .tblchart1sub td, .tblchart1sub th {
                                                                        border: 1px solid #c3c3c3;
                                                                        padding: 8px;
                                                                    }
                                                                    .tblchart1sub {
                                                                        border-collapse: collapse;
                                                                        border-color: #c3c3c3;
                                                                    }
                                                                </style>
                                                                <table class="tblchart1sub text-center">
                                                                    <thead>
                                                                        <tr>
                                                                            <td style="font-weight: bold; text-align: left; width: 16%;">Surface</td>
                                                                            <td style="width: 14%;">Front</td>
                                                                            <td style="width: 14%;">Top</td>
                                                                            <td style="width: 14%;">Bottom</td>
                                                                            <td style="width: 14%;">Left</td>
                                                                            <td style="width: 14%;">Right</td>
                                                                            <td style="width: 14%;">Back</td>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td style="font-weight: bold; text-align: left;">Multiplier</td>
                                                                            <td><span id="mulfront" class="mulsfview"></span></td>
                                                                            <td><span id="multop" class="mulsfview"></span></td>
                                                                            <td><span id="mulbottom" class="mulsfview"></span></td>
                                                                            <td><span id="mulleft" class="mulsfview"></span></td>
                                                                            <td><span id="mulright" class="mulsfview"></span></td>
                                                                            <td><span id="mulback" class="mulsfview"></span></td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">														
                                                            <div id="chart2" style="position: relative; padding-right:50px; padding-left: 40px; padding-top:70px;">
                                                                <canvas id="canvas"></canvas>
                                                                <div style="position: absolute; top: 40px; left: 10px; color:#767676; font-size: 16px; font-weight: bold;">
                                                                    Quantity
                                                                </div>
                                                                <div style="position:absolute;bottom:20px;right:12px;font-size:16px;color:#767676;font-weight: bold;">
                                                                    Score
                                                                </div>
                                                            </div>
                                                            <div id="legend" style="margin-top: 37px; padding-right: 64px; padding-left: 71px; text-align: right;">                                                                
                                                                <table class="tblgrcolor text-center">
                                                                    <tr>
                                                                        <td>
                                                                            <div style="background: rgb(0, 144, 188); height:4px; padding-right: 10px; width: 50px; display: inline-block"></div>
                                                                            Grade A
                                                                        </td>
                                                                        <td>
                                                                            <div style="background: rgb(227, 0, 6); width:50px; height:4px; display:inline-block"></div>
                                                                            Grade B                                                                            
                                                                        </td>
                                                                        <td>
                                                                            <div style="background: rgb(0, 166, 81); height:4px; width: 50px; padding-right: 10px; display: inline-block"></div>
                                                                            Grade C                                                                            
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <div style="background: rgb(146, 39, 143); width:50px; height:4px; display:inline-block"></div>
                                                                            Grade D
                                                                        </td>
                                                                        <td>
                                                                            <div style="background: rgb(255, 136, 0); width: 50px; height: 4px; padding-right: 10px; display: inline-block"></div>
                                                                            Grade E
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>                                                 
                                                </fieldset>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" style="margin-bottom:5px;text-align:center">																		
                                                <button type="button" class="btn blues" style="width:110px;background-color: #467894" title="Apply" id="apply"> Apply</button>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                    </div>           
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Add new profile -->
<!-- Modal -->
<div id="detail" class="popup modal-dialog modal-fade fancyboxForm" style="display: none;">		
    <div class="title-popup">
        Create profile	
        <button type="button" style="margin-top:5px" class="close closes" data-dismiss="modal" onclick="$.fancybox.close();" >				
        </button>
    </div>
    <div class="col-md-11">
        <div class="form-body content-popup">
            <div class="row">
                <div class="form-group col-md-12">
                    <label for="profilename" class="control-label col-md-3" style="color: #000;text-align: right;padding-right:0px;">Profile name <span class="required">(*)</span></label>
                    <div class="col-md-8">
                        <input type="text" placeholder="-- Input profile name--" name="profilename" id="profilename" class="form-control" value="" />

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer col-md-12" style="padding:10px!important;text-align:center!important;border-top:0px">
        <button type="button" class="btn blues" style="width:75px;margin-right:30px;" id="save" style="background-color: #006ead" onclick="addProfile('Add profile');"> Save</button>
        <button type="button" class="btn blues" id="cancel" style="width:75px;" style="background-color: #006ead" onclick="$.fancybox.close();"> Cancel</button>
    </div>
</div>
<input type="hidden" name="hid_itemid" id="hid_itemid" value="" />
<input type="hidden" name="hid_trackingid" id="hid_trackingid" value="" />
<!--//end Add new machine -->

<!-- Add Detail -->

<!--//end Detail -->	
<div id="stepInfoContainer" class="modal-dialog modal-lg fancyboxForm" style="display: none;">
    <div class="row"  style="margin-top:0 !important; color: black;">
        <div class="col-md-12"  style="margin-top:0;">
            <div id="listData">
                <div class="portlet box blue">
                    <div class="portlet-title">
                        <div class="caption">

                            <span>
                                Constraints
                            </span>
                        </div>
                        <div class="tools">							
                            <button type="button" style="margin-top:5px" class="close closes" data-dismiss="modal" onclick="$.fancybox.close();" >				
                            </button>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <div class="scroller" style="max-height:500px;">
                            <div class="col-md-12" style="color:#000">
                                <div class="row">
                                    <div class="form-body content-popup">
                                        <fieldset class="fieldset_l2">													
                                            <legend><h4><b><span style="color:#C04C19">Grade <span id="loadlabelgrade"></span></span></b></h4></legend>										
                                            <div class="col-md-5">
                                                <div class="row">	
                                                    <table class="table table-bordered table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th style="text-align:center;width:30%">Bent</th>
                                                                <th style="text-align:center;width:30%">Lift LCD</th>																						
                                                                <th style="text-align:center;width:30%">LCI</th>
                                                            </tr>									
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <select placeholder="-- Select --" optsl="single"  class="form-control2 search" name="bent" id="bent" >											
                                                                        <option value="No">No</option>
                                                                        <option value="Yes">Yes</option>											
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select placeholder="-- Select --" optsl="single" class="form-control2 search" name="lift" id="lift" >											
                                                                        <option value="No">No</option>
                                                                        <option value="Yes">Yes</option>											
                                                                    </select>
                                                                </td>																				
                                                                <td>
                                                                    <select placeholder="-- Select --" optsl="single" class="form-control2 search" name="lci" id="lci" >
                                                                        <option value="No">No</option>
                                                                        <option value="Yes">Yes</option>
                                                                    </select>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>							
                                                </div>
                                            </div>
                                            <!--Front-->
                                            <div class="col-md-12" id="htmlsettings">
                                                <div class="row">
                                                    <label class="control-label"><b>Surface: </b>Front</label>
                                                    <table class="table table-bordered table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th style="text-align:center" rowspan="2">No.</th>
                                                                <th style="text-align:center;" colspan="2">Scratches</th>																						
                                                                <th style="text-align:center;" colspan="2">Chips</th>																						
                                                                <th style="text-align:center;" colspan="2">Cracks</th>																						
                                                                <th style="text-align:center;" colspan="2">Dents</th>																						

                                                            </tr>
                                                            <tr>
                                                                <th style="text-align:center;">Quantity</th>																						
                                                                <th style="text-align:center;">Size (mm)</th>																						
                                                                <th style="text-align:center;">Quantity</th>																						
                                                                <th style="text-align:center;">Size (mm)</th>
                                                                <th style="text-align:center;">Quantity</th>																						
                                                                <th style="text-align:center;">Size (mm)</th>																						
                                                                <th style="text-align:center;">Quantity</th>																						
                                                                <th style="text-align:center;">Size (mm)</th>
                                                            </tr>									
                                                        </thead>
                                                        <tbody id="tbody_front">
                                                            <tr class="addmorefront frontend">
                                                                <td style="text-align:center" class="indexfront">1</td>									
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="1" autocomplete="off" min="0" max="100" type="number">
                                                                </td>									
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0.2" autocomplete="off" step="0.1" min="0" max="100" type="number">
                                                                </td>							
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>								
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                            </tr>
                                                            <tr class="addmorefront">
                                                                <td style="text-align:center" class="indexfront">2</td>									
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="2" autocomplete="off" min="0" max="100" type="number">
                                                                </td>									
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0.1" autocomplete="off" step="0.1" min="0" max="100" type="number">
                                                                </td>							
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>								
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>
                                                                <td style="text-align:center">
                                                                    <input style="width:50px" class="form-control input-sm diin" value="0" autocomplete="off" min="0" max="100" type="number">
                                                                </td>																	
                                                            </tr>
                                                        </tbody>
                                                        <tr>
                                                            <td colspan="9">
                                                                <a id="addmorefront" ids="front" class="addmore" title="Add more" href="#">
                                                                    Add more...										
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>					
                                            <!--End Front-->
                                        </fieldset>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="col-md-12" style="text-align:center;background-color:#fff;height:10px;">
                    </div>
                    <div class="col-md-12" style="text-align:center;background-color:#fff;">
                        <button type="button" class="btn blues" style="width:75px;margin-right:65px;" id="savedetail" style="background-color: #006ead"> Save</button>
                        <button type="button" class="btn blues" id="cancel" style="width:75px;" style="background-color: #006ead" onclick="$.fancybox.close();"> Cancel</button>
                    </div>
                    <div class="col-md-12" style="text-align:center;background-color:#fff;height:25px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .fancybox-inner{
        overflow: hidden!important;
        /*width:1000px!important;*/
    }
    .fancybox-wrap.fancybox-desktop.fancybox-type-inline.fancybox-opened{
        /*width:1000px!important;*/
    }
    @media (min-width:1292px){.modal-lg{width:1200px}}
    #stepInfoContainer .portlet-body{
        overflow-y: auto;
    }
    #chartdiv {
        width	: 100%;
        height	: 500px;
    }
    #cheo {
        background-image: linear-gradient(
            to top right,
            white 48%,
            #ddd,
            white 52%
            );
    }

    /* for testing */
    #cheo {
        width: 10em;
    }
    #cheo {
        width: 20em;
    } 
    .rederror{
        background-color:yellow;
    }
</style>